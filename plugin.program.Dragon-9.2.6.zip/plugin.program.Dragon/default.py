# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob ,random #line:50
import shutil ,logging #line:51
import urllib2 ,urllib #line:52
import re #line:53
import zipfile #line:54
import uservar #line:55
import fnmatch #line:56
TMDB_NEW_API ='aG9qaw=='#line:57
try :from sqlite3 import dbapi2 as database #line:58
except :from pysqlite2 import dbapi2 as database #line:59
from datetime import date ,datetime ,timedelta #line:60
from urlparse import urljoin #line:61
from resources .libs import extract ,downloader ,notify ,debridit ,traktit ,allucit ,loginit ,net ,skinSwitch ,uploadLog ,yt ,speedtest ,wizard as wiz ,addonwindow as pyxbmct ,yt ,wizard as wiz #line:62
ADDON_ID =uservar .ADDON_ID #line:65
ADDONTITLE =uservar .ADDONTITLE #line:66
ADDON =wiz .addonId (ADDON_ID )#line:67
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:68
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:69
DIALOG =xbmcgui .Dialog ()#line:70
DP =xbmcgui .DialogProgress ()#line:71
HOME =xbmc .translatePath ('special://home/')#line:72
LOG =xbmc .translatePath ('special://logpath/')#line:73
PROFILE =xbmc .translatePath ('special://profile/')#line:74
TEMPDIR =xbmc .translatePath ('special://temp')#line:75
ADDONS =os .path .join (HOME ,'addons')#line:76
USERDATA =os .path .join (HOME ,'userdata')#line:77
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:78
PACKAGES =os .path .join (ADDONS ,'packages')#line:79
ADDOND =os .path .join (USERDATA ,'addon_data')#line:80
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:81
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:82
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:83
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:84
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:85
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:86
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:87
DATABASE =os .path .join (USERDATA ,'Database')#line:88
FANART =os .path .join (PLUGIN ,'fanart.jpg')#line:89
ICON =os .path .join (PLUGIN ,'icon.png')#line:90
ART =os .path .join (PLUGIN ,'resources','art')#line:91
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:92
SPEEDTESTFOLD =os .path .join (ADDONDATA ,'SpeedTest')#line:93
ARCHIVE_CACHE =os .path .join (TEMPDIR ,'archive_cache')#line:94
SKIN =xbmc .getSkinDir ()#line:95
BUILDNAME =wiz .getS ('buildname')#line:96
DEFAULTSKIN =wiz .getS ('defaultskin')#line:97
DEFAULTNAME =wiz .getS ('defaultskinname')#line:98
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:99
BUILDVERSION =wiz .getS ('buildversion')#line:100
BUILDTHEME =wiz .getS ('buildtheme')#line:101
BUILDLATEST =wiz .getS ('latestversion')#line:102
SHOW15 =wiz .getS ('show15')#line:103
SHOW16 =wiz .getS ('show16')#line:104
SHOW17 =wiz .getS ('show17')#line:105
SHOW18 =wiz .getS ('show18')#line:106
SHOWADULT =wiz .getS ('adult')#line:107
SHOWMAINT =wiz .getS ('showmaint')#line:108
AUTOCLEANUP =wiz .getS ('autoclean')#line:109
AUTOCACHE =wiz .getS ('clearcache')#line:110
AUTOPACKAGES =wiz .getS ('clearpackages')#line:111
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:112
AUTOFEQ =wiz .getS ('autocleanfeq')#line:113
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:114
INCLUDEVIDEO =wiz .getS ('includevideo')#line:115
INCLUDEALL =wiz .getS ('includeall')#line:116
INCLUDEBOB =wiz .getS ('includebob')#line:117
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:118
INCLUDESPECTO =wiz .getS ('includespecto')#line:119
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:120
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:121
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:122
INCLUDESALTS =wiz .getS ('includesalts')#line:123
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:124
SEPERATE =wiz .getS ('seperate')#line:125
NOTIFY =wiz .getS ('notify')#line:126
NOTEID =wiz .getS ('noteid')#line:127
NOTEDISMISS =wiz .getS ('notedismiss')#line:128
TRAKTSAVE =wiz .getS ('traktlastsave')#line:129
REALSAVE =wiz .getS ('debridlastsave')#line:130
ALLUCSAVE =wiz .getS ('alluclastsave')#line:131
LOGINSAVE =wiz .getS ('loginlastsave')#line:132
KEEPFAVS =wiz .getS ('keepfavourites')#line:133
FAVSsave =wiz .getS ('favouriteslastsave')#line:134
KEEPSOURCES =wiz .getS ('keepsources')#line:135
KEEPPROFILES =wiz .getS ('keepprofiles')#line:136
KEEPADVANCED =wiz .getS ('keepadvanced')#line:137
KEEPREPOS =wiz .getS ('keeprepos')#line:138
KEEPSUPER =wiz .getS ('keepsuper')#line:139
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:140
KEEPTRAKT =wiz .getS ('keeptrakt')#line:141
KEEPREAL =wiz .getS ('keepdebrid')#line:142
KEEPALLUC =wiz .getS ('keepalluc')#line:143
KEEPLOGIN =wiz .getS ('keeplogin')#line:144
DEVELOPER =wiz .getS ('developer')#line:145
THIRDPARTY =wiz .getS ('enable3rd')#line:146
THIRD1NAME =wiz .getS ('wizard1name')#line:147
THIRD1URL =wiz .getS ('wizard1url')#line:148
THIRD2NAME =wiz .getS ('wizard2name')#line:149
THIRD2URL =wiz .getS ('wizard2url')#line:150
THIRD3NAME =wiz .getS ('wizard3name')#line:151
THIRD3URL =wiz .getS ('wizard3url')#line:152
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:153
BACKUPROMS =wiz .getS ('rompath')#line:154
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:155
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 0 #line:156
TODAY =date .today ()#line:157
TOMORROW =TODAY +timedelta (days =1 )#line:158
THREEDAYS =TODAY +timedelta (days =3 )#line:159
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:160
reload(sys)  
sys.setdefaultencoding('utf8')
if KODIV >17 :#line:162
	from resources .libs import zfile as zipfile #line:163
else :#line:164
	import zipfile #line:165
MCNAME =wiz .mediaCenter ()#line:166
EXCLUDES =uservar .EXCLUDES #line:167
CACHETEXT =uservar .CACHETEXT #line:168
CACHEAGE =uservar .CACHEAGE if str (uservar .CACHEAGE ).isdigit ()else 30 #line:169
BUILDFILE =uservar .BUILDFILE #line:170
ADDONPACK =uservar .ADDONPACK #line:171
APKFILE =uservar .APKFILE #line:172
YOUTUBETITLE =uservar .YOUTUBETITLE #line:173
YOUTUBEFILE =uservar .YOUTUBEFILE #line:174
ADDONFILE =uservar .ADDONFILE #line:175
ADVANCEDFILE =uservar .ADVANCEDFILE #line:176
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:177
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:178
NOTIFICATION =uservar .NOTIFICATION #line:179
ENABLE =uservar .ENABLE #line:180
HEADERMESSAGE =uservar .HEADERMESSAGE #line:181
AUTOUPDATE =uservar .AUTOUPDATE #line:182
BUILDERNAME =uservar .BUILDERNAME #line:183
WIZARDFILE =uservar .WIZARDFILE #line:184
HIDECONTACT =uservar .HIDECONTACT #line:185
CONTACT =uservar .CONTACT #line:186
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:187
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:188
HIDESPACERS =uservar .HIDESPACERS #line:189
COLOR1 =uservar .COLOR1 #line:190
COLOR2 =uservar .COLOR2 #line:191
THEME1 =uservar .THEME1 #line:192
THEME2 =uservar .THEME2 #line:193
THEME3 =uservar .THEME3 #line:194
THEME4 =uservar .THEME4 #line:195
THEME5 =uservar .THEME5 #line:196
THEME6 =uservar .THEME6 #line:197
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:198
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:199
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:200
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:201
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:202
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:203
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:204
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:205
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:206
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:207
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:208
Images =xbmc .translatePath (os .path .join ('special://home','addons',ADDON_ID ,'resources','images/'));#line:209
LOGFILES =wiz .LOGFILES #line:210
TRAKTID =traktit .TRAKTID #line:211
DEBRIDID =debridit .DEBRIDID #line:212
LOGINID =loginit .LOGINID #line:213
ALLUCID =allucit .ALLUCID #line:214
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:215
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:216
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:217
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:218
ROMPACK =uservar .ROMPACK #line:220
EMUAPKS =uservar .EMUAPKS #line:221
ROMPATH =ADDON .getSetting ('rompath')if not ADDON .getSetting ('rompath')==''else 'special://home/'#line:222
ROMLOC =os .path .join (ROMPATH ,'Roms','')#line:223
try :#line:224
	INSTALLMETHOD =int (float (wiz .getS ('installmethod')))#line:225
except :#line:226
	INSTALLMETHOD =0 #line:227
global Bname #line:229
Bname =""#line:230
def index ():#line:239
    OOO0O00OOOOO0O000 =int (errorChecking (count =True ))#line:240
    OO0000OOOO000000O =str (OOO0O00OOOOO0O000 )#line:241
    O000000O0000O0OOO ='[COLOR red]%s[/COLOR] Error(s) נמצא/ו'%(OO0000OOOO000000O ) if OOO0O00OOOOO0O000 >0 else 'אין שגיאות'#line:242
    if AUTOUPDATE =='Yes':#line:243
        O0O0000O00OO0000O =wiz .textCache (WIZARDFILE )#line:244
        logging.warning('Ver:'+O0O0000O00OO0000O)
        
        if not O0O0000O00OO0000O ==False :#line:245
            OOO00OOO0O00OOOO0 =wiz .checkWizard ('version')#line:246
            logging.warning('Ver2:'+OOO00OOO0O00OOOO0)
            logging.warning('Ver1:'+VERSION)
            if 1 :
                wiz .wizardUpdate ()
                #addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(ADDONTITLE ,VERSION ,OOO00OOO0O00OOOO0 ),'wizardupdate',themeit =THEME2 )#line:247
            else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:248
        else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:249
    else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:250
    if len (BUILDNAME )>0 :#line:251
        OO00O0O00O0OO000O =wiz .checkBuild (BUILDNAME ,'version')#line:252
        O0OOOOO00000OO0O0 ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:253
        if OO00O0O00O0OO000O >BUILDVERSION :O0OOOOO00000OO0O0 ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O0OOOOO00000OO0O0 ,OO00O0O00O0OO000O )#line:254
        addDir (O0OOOOO00000OO0O0 ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:255
        OOO0O0O00000O0OOO =wiz .themeCount (BUILDNAME )#line:256
        if not OOO0O0O00000O0OOO ==False :#line:257
            addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:258
    else :addDir ('None','builds',themeit =THEME4 )#line:259
    if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:260
    addDir ('בילדים','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:261
    addDir ('תחזוקה','maint',icon =ICONMAINT ,themeit =THEME1 )#line:262
    addDir ('כלי אינטרנט','net',icon =ICONCONTACT ,themeit =THEME1 )#line:263
    if wiz .platform ()=='android'or DEVELOPER =='true':addDir ('Apk Installer','apk',icon =ICONAPK ,themeit =THEME1 )#line:264
    if wiz .platform ()=='android'or wiz .platform ()=='windows'or DEVELOPER =='true':addDir ('Retro Gaming Zone','retromenu',icon =ICONSAVE ,themeit =THEME1 )#line:265
    if not ADDONFILE =='http://':addDir ('Addon Installer','addons',icon =ICONADDONS ,themeit =THEME1 )#line:266
    if not YOUTUBEFILE =='http://'and not YOUTUBETITLE =='':addDir (YOUTUBETITLE ,'youtube',icon =ICONYOUTUBE ,themeit =THEME1 )#line:267
    addDir ('Save Login Data / Favs Options','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:268
    addDir ('גיבוי/שחזור Data Options','backup',icon =ICONSAVE ,themeit =THEME1 )#line:269
    if HIDECONTACT =='No':addFile ('Contact','contact',icon =ICONCONTACT ,themeit =THEME1 )#line:270
    if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:271
    addFile ('Upload Log File','uploadlog',icon =ICONMAINT ,themeit =THEME1 )#line:272
    addFile ('View Errors in Log: %s'%(O000000O0000O0OOO ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME1 )#line:273
    if OOO0O00OOOOO0O000 >0 :addFile ('View Last Error In Log','viewerrorlast',icon =ICONMAINT ,themeit =THEME1 )#line:274
    if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:275
    addFile ('Settings','settings',icon =ICONSETTINGS ,themeit =THEME1 )#line:276
    addFile ('Force Update Text Files','forcetext',icon =ICONMAINT ,themeit =THEME1 )#line:277
    if DEVELOPER =='true':addDir ('Developer Menu','developer',icon =ICON ,themeit =THEME1 )#line:278
    xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:279
    setView ('files','viewType')#line:280
def KodiVer ():#line:281
	if KODIV >=16.0 and KODIV <=16.9 :OOOO0O0000000OO0O ='Jarvis'#line:282
	elif KODIV >=17.0 and KODIV <=17.9 :OOOO0O0000000OO0O ='Krypton'#line:283
	elif KODIV >=18.0 and KODIV <=18.9 :OOOO0O0000000OO0O ='Leia'#line:284
	else :OOOO0O0000000OO0O ="Unknown"#line:285
	return OOOO0O0000000OO0O #line:286
def buildMenu ():#line:287
	O0O0OOOO0000OO00O =wiz .workingURL (BUILDFILE )#line:292
	addFile ('%s Version: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:293
	addDir ('Save Data Menu','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:294
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:295
	addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:296
	addFile ('%s'%O0O0OOOO0000OO00O ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:297
	return #line:298
	O000000000OO0OO00 ,OOO00OOO000O0OOOO ,O00OOOOOOO000OOOO ,O0OOOO00OOO000O00 ,OO0OOO00OOOO00OO0 ,O0OO0OO0000OOO000 ,O0OOO0OO0O00O0OOO =wiz .buildCount ()#line:299
	O0O0000O0OOO00O0O =False ;O0OOO0000OO0O00O0 =[]#line:300
	if THIRDPARTY =='true':#line:301
		if not THIRD1NAME ==''and not THIRD1URL =='':O0O0000O0OOO00O0O =True ;O0OOO0000OO0O00O0 .append ('1')#line:302
		if not THIRD2NAME ==''and not THIRD2URL =='':O0O0000O0OOO00O0O =True ;O0OOO0000OO0O00O0 .append ('2')#line:303
		if not THIRD3NAME ==''and not THIRD3URL =='':O0O0000O0OOO00O0O =True ;O0OOO0000OO0O00O0 .append ('3')#line:304
	OOO0OOOO0O000O0OO =bf .replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"').replace ('url2=""','url2="http://"').replace ('url3=""','url3="http://"').replace ('preview=""','preview="http://"')#line:305
	O00OOOO000OO00O0O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?rl2="(.+?)".+?rl3="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)".+?review="(.+?)"').findall (OOO0OOOO0O000O0OO )#line:306
	if O000000000OO0OO00 ==1 and O0O0000O0OOO00O0O ==False :#line:307
		for O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ,O00OO000O0O00O000 ,O00O00O00OO0OO00O ,OOO0OOO00O000O000 ,O000O0O0O0OOO0OOO ,O00OO000OO000OOOO ,OO0OOO00OOOO0O0O0 ,O0OO0O00OO0O00OOO ,OOOOO0OO0O0OOOO0O ,O0000000OO0O000OO ,O000O000OOO0000OO ,O000O0OO0OOO00OO0 in O00OOOO000OO00O0O :#line:308
			if not SHOWADULT =='true'and O0000000OO0O000OO .lower ()=='yes':continue #line:309
			if not DEVELOPER =='true'and wiz .strTest (O00OO0OOO0OO00OOO ):continue #line:310
			viewBuild (O00OOOO000OO00O0O [0 ][0 ])#line:311
			return #line:312
	addFile ('%s גרסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:313
	addDir ('Save Data Menu','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:314
	addDir ('[COLOR yellow]---[B][COLOR lime]Addon Packs [COLOR blue]/ [COLOR red]Fixes[/COLOR][/B][COLOR yellow]---[/COLOR]','viewpack',icon =ICONMAINT ,themeit =THEME1 )#line:315
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:316
	if O0O0000O0OOO00O0O ==True :#line:317
		for OO0OO00OOOO000O00 in O0OOO0000OO0O00O0 :#line:318
			O00OO0OOO0OO00OOO =eval ('THIRD%sNAME'%OO0OO00OOOO000O00 )#line:319
			addDir ("[B]%s[/B]"%O00OO0OOO0OO00OOO ,'viewthirdparty',OO0OO00OOOO000O00 ,icon =ICONBUILDS ,themeit =THEME3 )#line:320
	if len (O00OOOO000OO00O0O )>=1 :#line:321
		if SEPERATE =='true':#line:322
			for O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ,O00OO000O0O00O000 ,O00O00O00OO0OO00O ,OOO0OOO00O000O000 ,O000O0O0O0OOO0OOO ,O00OO000OO000OOOO ,OO0OOO00OOOO0O0O0 ,O0OO0O00OO0O00OOO ,OOOOO0OO0O0OOOO0O ,O0000000OO0O000OO ,O000O000OOO0000OO ,O000O0OO0OOO00OO0 in O00OOOO000OO00O0O :#line:323
				if not SHOWADULT =='true'and O0000000OO0O000OO .lower ()=='yes':continue #line:324
				if not DEVELOPER =='true'and wiz .strTest (O00OO0OOO0OO00OOO ):continue #line:325
				O000O00O00O0000OO =createMenu ('install','',O00OO0OOO0OO00OOO )#line:326
				addDir ('[%s] %s (v%s)'%(float (O00OO000OO000OOOO ),O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ),'viewbuild',O00OO0OOO0OO00OOO ,description =O000O000OOO0000OO ,fanart =OOOOO0OO0O0OOOO0O ,icon =O0OO0O00OO0O00OOO ,menu =O000O00O00O0000OO ,themeit =THEME2 )#line:327
		elif DEVELOPER =='true':#line:328
			if OOO00OOO000O0OOOO >0 :#line:329
				addFile ('[B]Test builds[/B]','togglesetting','show15',themeit =THEME3 )#line:330
				for O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ,O00OO000O0O00O000 ,O00O00O00OO0OO00O ,OOO0OOO00O000O000 ,O000O0O0O0OOO0OOO ,O00OO000OO000OOOO ,OO0OOO00OOOO0O0O0 ,O0OO0O00OO0O00OOO ,OOOOO0OO0O0OOOO0O ,O0000000OO0O000OO ,O000O000OOO0000OO ,O000O0OO0OOO00OO0 in O00OOOO000OO00O0O :#line:331
					if not SHOWADULT =='true'and O0000000OO0O000OO .lower ()=='yes':continue #line:332
					if not DEVELOPER =='true'and wiz .strTest (O00OO0OOO0OO00OOO ):continue #line:333
					O0OOO0O00OO0O0O00 =int (float (O00OO000OO000OOOO ))#line:334
					if O0OOO0O00OO0O0O00 <=15 :#line:335
						O000O00O00O0000OO =createMenu ('install','',O00OO0OOO0OO00OOO )#line:336
						addDir (' %s (v%s)'%(O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ),'viewbuild',O00OO0OOO0OO00OOO ,description =O000O000OOO0000OO ,fanart =OOOOO0OO0O0OOOO0O ,icon =O0OO0O00OO0O00OOO ,menu =O000O00O00O0000OO ,themeit =THEME2 )#line:337
			if OO0OOO00OOOO00OO0 >0 :#line:338
				OO000OO0000O00OO0 ='+'if SHOW18 =='false'else '-'#line:339
				addFile ('[B]%s Leia Builds(%s)[/B]'%(OO000OO0000O00OO0 ,OO0OOO00OOOO00OO0 ),'togglesetting','show18',themeit =THEME3 )#line:340
				if SHOW18 =='true':#line:341
					for O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ,O00OO000O0O00O000 ,O00O00O00OO0OO00O ,OOO0OOO00O000O000 ,O000O0O0O0OOO0OOO ,O00OO000OO000OOOO ,OO0OOO00OOOO0O0O0 ,O0OO0O00OO0O00OOO ,OOOOO0OO0O0OOOO0O ,O0000000OO0O000OO ,O000O000OOO0000OO ,O000O0OO0OOO00OO0 in O00OOOO000OO00O0O :#line:342
						if not SHOWADULT =='true'and O0000000OO0O000OO .lower ()=='yes':continue #line:343
						if not DEVELOPER =='true'and wiz .strTest (O00OO0OOO0OO00OOO ):continue #line:344
						O0OOO0O00OO0O0O00 =int (float (O00OO000OO000OOOO ))#line:345
						if O0OOO0O00OO0O0O00 ==18 :#line:346
							O000O00O00O0000OO =createMenu ('install','',O00OO0OOO0OO00OOO )#line:347
							addDir ('[%s] %s (v%s)'%(float (O00OO000OO000OOOO ),O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ),'viewbuild',O00OO0OOO0OO00OOO ,description =O000O000OOO0000OO ,fanart =OOOOO0OO0O0OOOO0O ,icon =O0OO0O00OO0O00OOO ,menu =O000O00O00O0000OO ,themeit =THEME2 )#line:348
			if O0OOOO00OOO000O00 >0 :#line:349
				OO000OO0000O00OO0 ='+'if SHOW17 =='false'else '-'#line:350
				addFile ('[B]%s Krypton Builds(%s)[/B]'%(OO000OO0000O00OO0 ,O0OOOO00OOO000O00 ),'togglesetting','show17',themeit =THEME3 )#line:351
				if SHOW17 =='true':#line:352
					for O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ,O00OO000O0O00O000 ,O00O00O00OO0OO00O ,OOO0OOO00O000O000 ,O000O0O0O0OOO0OOO ,O00OO000OO000OOOO ,OO0OOO00OOOO0O0O0 ,O0OO0O00OO0O00OOO ,OOOOO0OO0O0OOOO0O ,O0000000OO0O000OO ,O000O000OOO0000OO ,O000O0OO0OOO00OO0 in O00OOOO000OO00O0O :#line:353
						if not SHOWADULT =='true'and O0000000OO0O000OO .lower ()=='yes':continue #line:354
						if not DEVELOPER =='true'and wiz .strTest (O00OO0OOO0OO00OOO ):continue #line:355
						O0OOO0O00OO0O0O00 =int (float (O00OO000OO000OOOO ))#line:356
						if O0OOO0O00OO0O0O00 ==17 :#line:357
							O000O00O00O0000OO =createMenu ('install','',O00OO0OOO0OO00OOO )#line:358
							addDir ('[%s] %s (v%s)'%(float (O00OO000OO000OOOO ),O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ),'viewbuild',O00OO0OOO0OO00OOO ,description =O000O000OOO0000OO ,fanart =OOOOO0OO0O0OOOO0O ,icon =O0OO0O00OO0O00OOO ,menu =O000O00O00O0000OO ,themeit =THEME2 )#line:359
			if O00OOOOOOO000OOOO >0 :#line:360
				OO000OO0000O00OO0 ='+'if SHOW16 =='false'else '-'#line:361
				addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OO000OO0000O00OO0 ,O00OOOOOOO000OOOO ),'togglesetting','show16',themeit =THEME3 )#line:362
				if SHOW16 =='true':#line:363
					for O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ,O00OO000O0O00O000 ,O00O00O00OO0OO00O ,OOO0OOO00O000O000 ,O000O0O0O0OOO0OOO ,O00OO000OO000OOOO ,OO0OOO00OOOO0O0O0 ,O0OO0O00OO0O00OOO ,OOOOO0OO0O0OOOO0O ,O0000000OO0O000OO ,O000O000OOO0000OO ,O000O0OO0OOO00OO0 in O00OOOO000OO00O0O :#line:364
						if not SHOWADULT =='true'and O0000000OO0O000OO .lower ()=='yes':continue #line:365
						if not DEVELOPER =='true'and wiz .strTest (O00OO0OOO0OO00OOO ):continue #line:366
						O0OOO0O00OO0O0O00 =int (float (O00OO000OO000OOOO ))#line:367
						if O0OOO0O00OO0O0O00 ==16 :#line:368
							O000O00O00O0000OO =createMenu ('install','',O00OO0OOO0OO00OOO )#line:369
							addDir ('[%s] %s (v%s)'%(float (O00OO000OO000OOOO ),O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ),'viewbuild',O00OO0OOO0OO00OOO ,description =O000O000OOO0000OO ,fanart =OOOOO0OO0O0OOOO0O ,icon =O0OO0O00OO0O00OOO ,menu =O000O00O00O0000OO ,themeit =THEME2 )#line:370
		else :#line:371
			if kodi_ver =="Leia":#line:372
				OO000OO0000O00OO0 ='+'if SHOW18 =='false'else '-'#line:373
				addFile ('[B]%s Leia Builds(%s)[/B]'%(OO000OO0000O00OO0 ,OO0OOO00OOOO00OO0 ),'togglesetting','show18',themeit =THEME3 )#line:374
				if SHOW18 =='true':#line:375
					for O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ,O00OO000O0O00O000 ,O00O00O00OO0OO00O ,OOO0OOO00O000O000 ,O000O0O0O0OOO0OOO ,O00OO000OO000OOOO ,OO0OOO00OOOO0O0O0 ,O0OO0O00OO0O00OOO ,OOOOO0OO0O0OOOO0O ,O0000000OO0O000OO ,O000O000OOO0000OO ,O000O0OO0OOO00OO0 in O00OOOO000OO00O0O :#line:376
						if not SHOWADULT =='true'and O0000000OO0O000OO .lower ()=='yes':continue #line:377
						if not DEVELOPER =='true'and wiz .strTest (O00OO0OOO0OO00OOO ):continue #line:378
						O0OOO0O00OO0O0O00 =int (float (O00OO000OO000OOOO ))#line:379
						if O0OOO0O00OO0O0O00 ==18 :#line:380
							O000O00O00O0000OO =createMenu ('install','',O00OO0OOO0OO00OOO )#line:381
							addDir ('[%s] %s (v%s)'%(float (O00OO000OO000OOOO ),O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ),'viewbuild',O00OO0OOO0OO00OOO ,description =O000O000OOO0000OO ,fanart =OOOOO0OO0O0OOOO0O ,icon =O0OO0O00OO0O00OOO ,menu =O000O00O00O0000OO ,themeit =THEME2 )#line:382
			elif kodi_ver =="Krypton":#line:383
				OO000OO0000O00OO0 ='+'if SHOW17 =='false'else '-'#line:384
				addFile ('[B]%s Krypton Builds(%s)[/B]'%(OO000OO0000O00OO0 ,O0OOOO00OOO000O00 ),'togglesetting','show17',themeit =THEME3 )#line:385
				if SHOW17 =='true':#line:386
					for O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ,O00OO000O0O00O000 ,O00O00O00OO0OO00O ,OOO0OOO00O000O000 ,O000O0O0O0OOO0OOO ,O00OO000OO000OOOO ,OO0OOO00OOOO0O0O0 ,O0OO0O00OO0O00OOO ,OOOOO0OO0O0OOOO0O ,O0000000OO0O000OO ,O000O000OOO0000OO ,O000O0OO0OOO00OO0 in O00OOOO000OO00O0O :#line:387
						if not SHOWADULT =='true'and O0000000OO0O000OO .lower ()=='yes':continue #line:388
						if not DEVELOPER =='true'and wiz .strTest (O00OO0OOO0OO00OOO ):continue #line:389
						O0OOO0O00OO0O0O00 =int (float (O00OO000OO000OOOO ))#line:390
						if O0OOO0O00OO0O0O00 ==17 :#line:391
							O000O00O00O0000OO =createMenu ('install','',O00OO0OOO0OO00OOO )#line:392
							addDir ('[%s] %s (v%s)'%(float (O00OO000OO000OOOO ),O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ),'viewbuild',O00OO0OOO0OO00OOO ,description =O000O000OOO0000OO ,fanart =OOOOO0OO0O0OOOO0O ,icon =O0OO0O00OO0O00OOO ,menu =O000O00O00O0000OO ,themeit =THEME2 )#line:393
			elif kodi_ver =="Jarvis":#line:394
				OO000OO0000O00OO0 ='+'if SHOW16 =='false'else '-'#line:395
				addFile ('[B]%s Jarvis Builds(%s)[/B]'%(OO000OO0000O00OO0 ,O00OOOOOOO000OOOO ),'togglesetting','show16',themeit =THEME3 )#line:396
				if SHOW16 =='true':#line:397
					for O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ,O00OO000O0O00O000 ,O00O00O00OO0OO00O ,OOO0OOO00O000O000 ,O000O0O0O0OOO0OOO ,O00OO000OO000OOOO ,OO0OOO00OOOO0O0O0 ,O0OO0O00OO0O00OOO ,OOOOO0OO0O0OOOO0O ,O0000000OO0O000OO ,O000O000OOO0000OO ,O000O0OO0OOO00OO0 in O00OOOO000OO00O0O :#line:398
						if not SHOWADULT =='true'and O0000000OO0O000OO .lower ()=='yes':continue #line:399
						if not DEVELOPER =='true'and wiz .strTest (O00OO0OOO0OO00OOO ):continue #line:400
						O0OOO0O00OO0O0O00 =int (float (O00OO000OO000OOOO ))#line:401
						if O0OOO0O00OO0O0O00 ==16 :#line:402
							O000O00O00O0000OO =createMenu ('install','',O00OO0OOO0OO00OOO )#line:403
							addDir ('[%s] %s (v%s)'%(float (O00OO000OO000OOOO ),O00OO0OOO0OO00OOO ,O0OO00OO00O00O0O0 ),'viewbuild',O00OO0OOO0OO00OOO ,description =O000O000OOO0000OO ,fanart =OOOOO0OO0O0OOOO0O ,icon =O0OO0O00OO0O00OOO ,menu =O000O00O00O0000OO ,themeit =THEME2 )#line:404
	elif O0OOO0OO0O00O0OOO >0 :#line:405
		if O0OO0OO0000OOO000 >0 :#line:406
			addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:407
			addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:408
		else :#line:409
			addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:410
	else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:411
	setView ('files','viewType')#line:412
def viewBuild (O00OOO00O0OOOO0OO ):#line:413
	OOOOO00OO0000OO0O =wiz .textCache (BUILDFILE )#line:415
	if OOOOO00OO0000OO0O ==False :#line:416
		O0OOOO000000O0O00 =wiz .workingURL (BUILDFILE )#line:417
		addFile ('Url for txt file not valid','',themeit =THEME3 )#line:418
		addFile ('%s'%O0OOOO000000O0O00 ,'',themeit =THEME3 )#line:419
		return #line:420
	if wiz .checkBuild (O00OOO00O0OOOO0OO ,'version')==False :#line:421
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:422
		addFile ('%s was not found in the builds list.'%O00OOO00O0OOOO0OO ,'',themeit =THEME3 )#line:423
		return #line:424
	O000O0OO00OOO0000 =OOOOO00OO0000OO0O .replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('url2=""','url2="http://"').replace ('url3=""','url3="http://"').replace ('preview=""','preview="http://"').replace ('"https://"','preview="http://"')#line:425
	O000000OOO00OOO00 =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?rl2="(.+?)".+?rl3="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)".+?review="(.+?)"'%O00OOO00O0OOOO0OO ).findall (O000O0OO00OOO0000 )#line:426
	for OO0O0000OOOO0OOOO ,O00O0O0OOOO0OOO00 ,OOO00OO0OOOOOOOO0 ,O00O000O00O0O00OO ,OO0000O0O0O000OO0 ,O0O0OO00O0O0O00O0 ,O00O00O0OOO0000OO ,OOOOO00OOOOOO0O00 ,OOO0O0OOO000OO00O ,OOO00OOO00OO0OO0O ,OO0OO0OOOOOO0000O ,OOOOO000OOO0OOOO0 in O000000OOO00OOO00 :#line:427
		OOOOO00OOOOOO0O00 =OOOOO00OOOOOO0O00 #line:428
		OOO0O0OOO000OO00O =OOO0O0OOO000OO00O #line:429
		O00000OOO00O0O0OO ='%s (v%s)'%(O00OOO00O0OOOO0OO ,OO0O0000OOOO0OOOO )#line:430
		if BUILDNAME ==O00OOO00O0OOOO0OO and OO0O0000OOOO0OOOO >BUILDVERSION :#line:431
			O00000OOO00O0O0OO ='%s [COLOR red][CURRENT v%s][/COLOR]'%(O00000OOO00O0O0OO ,BUILDVERSION )#line:432
		addFile (O00000OOO00O0O0OO ,'',description =OO0OO0OOOOOO0000O ,fanart =OOO0O0OOO000OO00O ,icon =OOOOO00OOOOOO0O00 ,themeit =THEME4 )#line:433
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:434
		addDir ('Save Data Menu','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:435
		addFile ('Build Information','buildinfo',O00OOO00O0OOOO0OO ,description =OO0OO0OOOOOO0000O ,fanart =OOO0O0OOO000OO00O ,icon =OOOOO00OOOOOO0O00 ,themeit =THEME3 )#line:436
		if not OOOOO000OOO0OOOO0 =="http://":addFile ('View Video Preview','buildpreview',O00OOO00O0OOOO0OO ,description =OO0OO0OOOOOO0000O ,fanart =OOO0O0OOO000OO00O ,icon =OOOOO00OOOOOO0O00 ,themeit =THEME3 )#line:437
		O0000OO00000O0OOO =int (float (KODIV ));O0O00O00000OOOO0O =int (float (O0O0OO00O0O0O00O0 ))#line:438
		if not O0000OO00000O0OOO ==O0O00O00000OOOO0O :#line:439
			if O0000OO00000O0OOO ==16 and O0O00O00000OOOO0O <=15 :O0OOO0OOO00OOOOOO =False #line:440
			else :O0OOO0OOO00OOOOOO =True #line:441
		else :O0OOO0OOO00OOOOOO =False #line:442
		if O0OOO0OOO00OOOOOO ==True :#line:443
			addFile ('BUILD DESIGNED FOR KODI VERSION %s [COLOR yellow](INSTALLED: %s)[/COLOR]'%(str (O0O0OO00O0O0O00O0 ),str (KODIV )),'',fanart =OOO0O0OOO000OO00O ,icon =OOOOO00OOOOOO0O00 ,themeit =THEME6 )#line:444
		addFile (wiz .sep ('INSTALL'),'',fanart =OOO0O0OOO000OO00O ,icon =OOOOO00OOOOOO0O00 ,themeit =THEME3 )#line:445
		addFile ('Fresh Start then Install','install',O00OOO00O0OOOO0OO ,'fresh',description =OO0OO0OOOOOO0000O ,fanart =OOO0O0OOO000OO00O ,icon =OOOOO00OOOOOO0O00 ,themeit =THEME1 )#line:446
		addFile ('Standard Install','install',O00OOO00O0OOOO0OO ,'normal',description =OO0OO0OOOOOO0000O ,fanart =OOO0O0OOO000OO00O ,icon =OOOOO00OOOOOO0O00 ,themeit =THEME1 )#line:447
		if not OO0000O0O0O000OO0 =='http://':addFile ('עדכון מהיר','install',O00OOO00O0OOOO0OO ,'gui',description =OO0OO0OOOOOO0000O ,fanart =OOO0O0OOO000OO00O ,icon =OOOOO00OOOOOO0O00 ,themeit =THEME1 )#line:448
		if not O00O00O0OOO0000OO =='http://':#line:449
			OOO000OO0000O00O0 =wiz .textCache (O00O00O0OOO0000OO )#line:450
			if not OOO000OO0000O00O0 ==False :#line:451
				addFile (wiz .sep ('THEMES'),'',fanart =OOO0O0OOO000OO00O ,icon =OOOOO00OOOOOO0O00 ,themeit =THEME3 )#line:452
				O000O0OO00OOO0000 =OOO000OO0000O00O0 .replace ('\n','').replace ('\r','').replace ('\t','')#line:453
				O000000OOO00OOO00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O000O0OO00OOO0000 )#line:454
				for O0O0000OOO0OO0OO0 ,OO0O000OO000O0O0O ,OOO00OOOO00O0O00O ,O00OO00O0O000OOO0 ,OO0OO0OOOOOO0000O in O000000OOO00OOO00 :#line:455
					OOO00OOOO00O0O00O =OOO00OOOO00O0O00O if OOO00OOOO00O0O00O =='http://'else OOOOO00OOOOOO0O00 #line:456
					O00OO00O0O000OOO0 =O00OO00O0O000OOO0 if O00OO00O0O000OOO0 =='http://'else OOO0O0OOO000OO00O #line:457
					addFile (O0O0000OOO0OO0OO0 if not O0O0000OOO0OO0OO0 ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0O0000OOO0OO0OO0 ,'theme',O00OOO00O0OOOO0OO ,O0O0000OOO0OO0OO0 ,description =OO0OO0OOOOOO0000O ,fanart =O00OO00O0O000OOO0 ,icon =OOO00OOOO00O0O00O ,themeit =THEME3 )#line:458
	setView ('files','viewType')#line:459
def viewThirdList (OOOO00OOO000OOOO0 ):#line:460
	O0OO0O0O00O0O000O =eval ('THIRD%sNAME'%OOOO00OOO000OOOO0 )#line:461
	OOOOOO0OO0000O000 =eval ('THIRD%sURL'%OOOO00OOO000OOOO0 )#line:462
	OO0OO000O0O00O0OO =wiz .workingURL (OOOOOO0OO0000O000 )#line:463
	if not OO0OO000O0O00O0OO ==True :#line:464
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:465
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:466
	else :#line:467
		O0O0OOO0O0O0000O0 ,OO00O00O000O00O0O =wiz .thirdParty (OOOOOO0OO0000O000 )#line:468
		addFile ("[B]%s[/B]"%O0OO0O0O00O0O000O ,'',themeit =THEME3 )#line:469
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:470
		if O0O0OOO0O0O0000O0 :#line:471
			for O0OO0O0O00O0O000O ,O0O0OO0O000O0O00O ,OOOOOO0OO0000O000 ,O0OO0O000O000O000 ,O00O0000O000OO0OO ,OOOO0OO00O00OO0O0 ,OOO000O000OO0OO00 ,O0000OOOO0OOOO0O0 in OO00O00O000O00O0O :#line:472
				if not SHOWADULT =='true'and OOO000O000OO0OO00 .lower ()=='yes':continue #line:473
				addFile ("[%s] %s v%s"%(O0OO0O000O000O000 ,O0OO0O0O00O0O000O ,O0O0OO0O000O0O00O ),'installthird',O0OO0O0O00O0O000O ,OOOOOO0OO0000O000 ,icon =O00O0000O000OO0OO ,fanart =OOOO0OO00O00OO0O0 ,description =O0000OOOO0OOOO0O0 ,themeit =THEME2 )#line:474
		else :#line:475
			for O0OO0O0O00O0O000O ,OOOOOO0OO0000O000 ,O00O0000O000OO0OO ,OOOO0OO00O00OO0O0 ,O0000OOOO0OOOO0O0 in OO00O00O000O00O0O :#line:476
				addFile (O0OO0O0O00O0O000O ,'installthird',O0OO0O0O00O0O000O ,OOOOOO0OO0000O000 ,icon =O00O0000O000OO0OO ,fanart =OOOO0OO00O00OO0O0 ,description =O0000OOOO0OOOO0O0 ,themeit =THEME2 )#line:477
def editThirdParty (OOO000000O00OO000 ):#line:478
	OO0000O0O000OO0OO =eval ('THIRD%sNAME'%OOO000000O00OO000 )#line:479
	OOOO00000O00OO000 =eval ('THIRD%sURL'%OOO000000O00OO000 )#line:480
	OO00O00OO00O00O0O =wiz .getKeyboard (OO0000O0O000OO0OO ,'Enter the Name of the Wizard')#line:481
	O000O0OO0OOOOOOOO =wiz .getKeyboard (OOOO00000O00OO000 ,'Enter the URL of the Wizard Text')#line:482
	wiz .setS ('wizard%sname'%OOO000000O00OO000 ,OO00O00OO00O00O0O )#line:483
	wiz .setS ('wizard%surl'%OOO000000O00OO000 ,O000O0OO0OOOOOOOO )#line:484
def apkScraper (name =""):#line:485
	if name =='kodi':#line:486
		O0O00OO0000O0O0OO ='http://mirrors.kodi.tv/releases/android/arm/'#line:487
		O0OOOO0O000O0O000 ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:488
		OOO0OOO00O00OOOO0 =wiz .openURL (O0O00OO0000O0O0OO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:489
		O0OOOO0OO000OO000 =wiz .openURL (O0OOOO0O000O0O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:490
		OO00000OOO0O00O0O =0 #line:491
		O00O0OOOO0O0OO00O =re .compile ('<tr><td><a href="(.+?)".+?>(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOO0OOO00O00OOOO0 )#line:492
		OOO00O00000O000O0 =re .compile ('<tr><td><a href="(.+?)".+?>(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O0OOOO0OO000OO000 )#line:493
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:494
		OOOO00O0O0000O0OO =False #line:495
		for OO00OOOO00O000OO0 ,name ,O0OO0000O0OOOO0O0 ,OO00O0O0OO0OO000O in O00O0OOOO0O0OO00O :#line:496
			if OO00OOOO00O000OO0 in ['../','old/']:continue #line:497
			if not OO00OOOO00O000OO0 .endswith ('.apk'):continue #line:498
			if not OO00OOOO00O000OO0 .find ('_')==-1 and OOOO00O0O0000O0OO ==True :continue #line:499
			try :#line:500
				O0O0O0O000OOO0O00 =name .split ('-')#line:501
				if not OO00OOOO00O000OO0 .find ('_')==-1 :#line:502
					OOOO00O0O0000O0OO =True #line:503
					OOOO0OOO000O0OO00 ,O00OOO00OO000O00O =O0O0O0O000OOO0O00 [2 ].split ('_')#line:504
				else :#line:505
					OOOO0OOO000O0OO00 =O0O0O0O000OOO0O00 [2 ]#line:506
					O00OOO00OO000O00O =''#line:507
				OOOO0OOO0O0O000OO ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O0O000OOO0O00 [0 ].title (),O0O0O0O000OOO0O00 [1 ],O00OOO00OO000O00O .upper (),OOOO0OOO000O0OO00 ,COLOR2 ,O0OO0000O0OOOO0O0 .replace (' ',''),COLOR1 ,OO00O0O0OO0OO000O )#line:508
				OOO0O000O00000O0O =urljoin (O0O00OO0000O0O0OO ,OO00OOOO00O000OO0 )#line:509
				addFile (OOOO0OOO0O0O000OO ,'apkinstall',"%s v%s%s %s"%(O0O0O0O000OOO0O00 [0 ].title (),O0O0O0O000OOO0O00 [1 ],O00OOO00OO000O00O .upper (),OOOO0OOO000O0OO00 ),OOO0O000O00000O0O )#line:510
				OO00000OOO0O00O0O +=1 #line:511
			except :#line:512
				wiz .log ("Error on: %s"%name )#line:513
		for OO00OOOO00O000OO0 ,name ,O0OO0000O0OOOO0O0 ,OO00O0O0OO0OO000O in OOO00O00000O000O0 :#line:514
			if OO00OOOO00O000OO0 in ['../','old/']:continue #line:515
			if not OO00OOOO00O000OO0 .endswith ('.apk'):continue #line:516
			if not OO00OOOO00O000OO0 .find ('_')==-1 :continue #line:517
			try :#line:518
				O0O0O0O000OOO0O00 =name .split ('-')#line:519
				OOOO0OOO0O0O000OO ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O0O000OOO0O00 [0 ].title (),O0O0O0O000OOO0O00 [1 ],O0O0O0O000OOO0O00 [2 ],COLOR2 ,O0OO0000O0OOOO0O0 .replace (' ',''),COLOR1 ,OO00O0O0OO0OO000O )#line:520
				OOO0O000O00000O0O =urljoin (O0OOOO0O000O0O000 ,OO00OOOO00O000OO0 )#line:521
				addFile (OOOO0OOO0O0O000OO ,'apkinstall',"%s v%s %s"%(O0O0O0O000OOO0O00 [0 ].title (),O0O0O0O000OOO0O00 [1 ],O0O0O0O000OOO0O00 [2 ]),OOO0O000O00000O0O )#line:522
				OO00000OOO0O00O0O +=1 #line:523
			except :#line:524
				wiz .log ("Error on: %s"%name )#line:525
		if OO00000OOO0O00O0O ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:526
	elif name =='spmc':#line:527
		O000OO0O0OOOO0000 ='https://github.com/koying/SPMC/releases'#line:528
		OOO0OOO00O00OOOO0 =wiz .openURL (O000OO0O0OOOO0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:529
		OO00000OOO0O00O0O =0 #line:530
		O00O0OOOO0O0OO00O =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (OOO0OOO00O00OOOO0 )#line:531
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:532
		for name ,OO0OO0O0O00O0O00O in O00O0OOOO0O0OO00O :#line:533
			OOO0000O00O00O000 =''#line:534
			OOO00O00000O000O0 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (OO0OO0O0O00O0O00O )#line:535
			for OO0O00000000OO0OO ,OO00OOOOOO0O0O0O0 ,O0OOOOOO0OO0O0O00 in OOO00O00000O000O0 :#line:536
				if O0OOOOOO0OO0O0O00 .find ('armeabi')==-1 :continue #line:537
				if O0OOOOOO0OO0O0O00 .find ('launcher')>-1 :continue #line:538
				OOO0000O00O00O000 =urljoin ('https://github.com',OO0O00000000OO0OO )#line:539
				break #line:540
			if OOO0000O00O00O000 =='':continue #line:541
			try :#line:542
				name ="SPMC %s"%name #line:543
				OOOO0OOO0O0O000OO ="[COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,name ,COLOR2 ,OO00OOOOOO0O0O0O0 .replace (' ',''))#line:544
				OOO0O000O00000O0O =OOO0000O00O00O000 #line:545
				addFile (OOOO0OOO0O0O000OO ,'apkinstall',name ,OOO0O000O00000O0O )#line:546
				OO00000OOO0O00O0O =OO00000OOO0O00O0O +1 #line:547
			except Exception as O00OOOO00O00000O0 :#line:548
				wiz .log ("Error on: %s / %s"%(name ,str (O00OOOO00O00000O0 )))#line:549
		if OO00000OOO0O00O0O ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:550
def apkMenu (name =None ,url =None ):#line:551
	if HIDESPACERS =='No':addFile (wiz .sep ('Apps from apkfiles.com'),'',themeit =THEME3 )#line:552
	addDir ('App Lists','apkfiles',icon =ICONSAVE ,themeit =THEME1 )#line:553
	if HIDESPACERS =='No':addFile (wiz .sep ('FTG Modded Apps'),'',themeit =THEME3 )#line:554
	addDir ('App Lists','ftgmod',icon =ICONSAVE ,themeit =THEME1 )#line:555
	setView ('files','viewType')#line:556
	if url ==None :#line:557
		if HIDESPACERS =='No':addFile (wiz .sep ('Official Kodi/SPMC'),'',themeit =THEME3 )#line:558
		addDir ('Kodi Apk\'s','apkscrape','kodi',icon =ICONAPK ,themeit =THEME1 )#line:559
		addDir ('SPMC Apk\'s','apkscrape','spmc',icon =ICONAPK ,themeit =THEME1 )#line:560
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:561
	if not APKFILE =='http://':#line:562
		if url ==None :#line:563
			O00OOOO0O0OO0O00O =wiz .textCache (uservar .APKFILE )#line:564
			if O00OOOO0O0OO0O00O ==False :O00000000OO000OO0 =wiz .workingURL (uservar .APKFILE )#line:565
		else :#line:566
			O00OOOO0O0OO0O00O =wiz .textCache (url )#line:567
			if O00OOOO0O0OO0O00O ==False :O00000000OO000OO0 =wiz .workingURL (url )#line:568
		if not O00OOOO0O0OO0O00O ==False :#line:569
			O0O0O00000OOOOO00 =O00OOOO0O0OO0O00O .replace ('\n','').replace ('\r','').replace ('\t','')#line:570
			OO0OO00O00O00OO00 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O0O00000OOOOO00 )#line:571
			if len (OO0OO00O00O00OO00 )>0 :#line:572
				O0OO0OO0OOOO0O000 =0 #line:573
				for OOOO000O0OO0O0O00 ,OO0O0OOO00O0O0OO0 ,url ,OO0O00O00O0000OOO ,O0O0000000000OO00 ,OOO0O0OOO000000O0 ,O0OO0OO000000O000 in OO0OO00O00O00OO00 :#line:574
					if not SHOWADULT =='true'and OOO0O0OOO000000O0 .lower ()=='yes':continue #line:575
					if OO0O0OOO00O0O0OO0 .lower ()=='yes':#line:576
						O0OO0OO0OOOO0O000 +=1 #line:577
						addDir ("[B]%s[/B]"%OOOO000O0OO0O0O00 ,'apk',OOOO000O0OO0O0O00 ,url ,description =O0OO0OO000000O000 ,icon =OO0O00O00O0000OOO ,fanart =O0O0000000000OO00 ,themeit =THEME3 )#line:578
					elif OO0O0OOO00O0O0OO0 .lower ()=='yes':#line:579
						O0OO0OO0OOOO0O000 +=1 #line:580
						addFile (OOOO000O0OO0O0O00 ,'rominstall',OOOO000O0OO0O0O00 ,url ,description =O0OO0OO000000O000 ,icon =OO0O00O00O0000OOO ,fanart =O0O0000000000OO00 ,themeit =THEME2 )#line:581
					else :#line:582
						O0OO0OO0OOOO0O000 +=1 #line:583
						addFile (OOOO000O0OO0O0O00 ,'apkinstall',OOOO000O0OO0O0O00 ,url ,description =O0OO0OO000000O000 ,icon =OO0O00O00O0000OOO ,fanart =O0O0000000000OO00 ,themeit =THEME2 )#line:584
					if O0OO0OO0OOOO0O000 ==0 :#line:585
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:586
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:587
		else :#line:588
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:589
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:590
			addFile ('%s'%O00000000OO000OO0 ,'',themeit =THEME3 )#line:591
		return #line:592
	else :wiz .log ("[APK Menu] No APK list added.")#line:593
	setView ('files','viewType')#line:594
def ftgmod ():#line:595
	if not APKFILE =='http://':#line:596
		OO0OOO00OO0OO0O0O =wiz .workingURL (APKFILE )#line:597
		if OO0OOO00OO0OO0O0O ==True :#line:598
			OO0O00OO0OOO00O0O =wiz .openURL (APKFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:599
			O000OOOOO00OOOO00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (OO0O00OO0OOO00O0O )#line:600
			if len (O000OOOOO00OOOO00 )>0 :#line:601
				for O00OOO0000O000000 ,OOOOOO0OO0O000O0O ,O0000O000OO0OOO0O ,O0O0OO000OO0OOOO0 in O000OOOOO00OOOO00 :#line:602
					addDir (O00OOO0000O000000 ,'GetList',O00OOO0000O000000 ,OOOOOO0OO0O000O0O ,icon =O0000O000OO0OOO0O ,fanart =O0O0OO000OO0OOOO0 ,themeit =THEME1 )#line:604
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.")#line:605
		else :#line:606
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:607
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:608
			addFile ('%s'%OO0OOO00OO0OO0O0O ,'',themeit =THEME3 )#line:609
		return #line:610
	else :wiz .log ("[APK Menu] No APK list added.")#line:611
def GetList (OO0000OOOO0OO0OOO ):#line:612
	if not wiz .workingURL (OO0000OOOO0OO0OOO )==True :return False #line:613
	O00O0O000OO0O00O0 =wiz .openURL (OO0000OOOO0OO0OOO ).replace ('\n','').replace ('\r','').replace ('\t','')#line:614
	OOOOOOO0OO0O0O0OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O00O0O000OO0O00O0 )#line:615
	if len (OOOOOOO0OO0O0O0OO )>0 :#line:616
		for O000O000OO0OOOO00 ,OO0000OOOO0OO0OOO ,O0O00OOOO0O0OO000 ,OO00OO0O0O00O0OO0 in OOOOOOO0OO0O0O0OO :#line:617
			addFile (O000O000OO0OOOO00 ,'apkinstall',O000O000OO0OOOO00 ,OO0000OOOO0OO0OOO ,icon =O0O00OOOO0O0OO000 ,fanart =OO00OO0O0O00O0OO0 ,themeit =THEME1 )#line:618
		else :wiz .log ("[APK Menu] ERROR: Invalid Format.")#line:619
	else :wiz .log ("[APK Menu] ERROR: URL for emu list not working.")#line:620
def apkfiles ():#line:621
	if HIDESPACERS =='No':addFile (wiz .sep ('Apps from apkfiles.com'),'',themeit =THEME3 )#line:622
	O0O0OO0O0O0OOO0O0 =wiz .openURL ('https://www.apkfiles.com/')#line:623
	OO0OO0000OO0O0000 =re .compile ('href="([^"]*)">Applications(.+?)</a>').findall (O0O0OO0O0O0OOO0O0 )#line:624
	O0O0OO0O00O0OO0O0 =re .compile ('href="([^"]*)">Games(.+?)</a>').findall (O0O0OO0O0O0OOO0O0 )#line:625
	for OO0O0O00O000OO000 ,OO00OO000O00000O0 in OO0OO0000OO0O0000 :#line:626
		addDir2 ('[COLOR blue]Android Apps[/COLOR]','https://www.apkfiles.com'+OO0O0O00O000OO000 ,'apkgame',ICONAPK ,FANART )#line:627
	for OO0O0O00O000OO000 ,OO00OO000O00000O0 in O0O0OO0O00O0OO0O0 :#line:628
		addDir2 ('[COLOR blue]Android Games[/COLOR]','https://www.apkfiles.com'+OO0O0O00O000OO000 ,'apkgame',ICONAPK ,FANART )#line:629
	setView ('movies','MAIN')#line:630
def apkshowMenu (O0OOOO0OO0O0O0000 ):#line:631
	if not wiz .workingURL (O0OOOO0OO0O0O0000 )==True :return False #line:632
	OOO0OOO000OOO000O =wiz .openURL (O0OOOO0OO0O0O0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:633
	O00O0OO0OO0O0OO00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (OOO0OOO000OOO000O )#line:634
	if len (O00O0OO0OO0O0OO00 )>0 :#line:635
		for OO0OOOO0OOOOO000O ,O0OOOO0OO0O0O0000 ,O0O000OOOO00OOO00 ,O000O00O000OO0O00 in O00O0OO0OO0O0OO00 :#line:636
			addFile (OO0OOOO0OOOOO000O ,'apkinstall',OO0OOOO0OOOOO000O ,O0OOOO0OO0O0O0000 ,icon =O0O000OOOO00OOO00 ,fanart =O000O00O000OO0O00 ,themeit =THEME1 )#line:637
		else :wiz .log ("[APK Menu] ERROR: Invalid Format.")#line:638
	else :wiz .log ("[APK Menu] ERROR: URL for emu list not working.")#line:639
def APKGAME (O0OO00OOO00OO0O00 ):#line:640
	OO0O0OO0OO0OO000O =wiz .openURL (O0OO00OOO00OO0O00 )#line:641
	O0OO0O0O0OOOOOOO0 =re .compile ('<a href="([^"]*)" >(.+?)</a>').findall (OO0O0OO0OO0OO000O )#line:642
	for O0OO00OOO00OO0O00 ,O0O0O0OO0OO0O0OO0 in O0OO0O0O0OOOOOOO0 :#line:643
		if '/cat'in O0OO00OOO00OO0O00 :#line:644
			addDir2 ((O0O0O0OO0OO0O0OO0 ).replace ('&amp;',' - '),'https://www.apkfiles.com'+O0OO00OOO00OO0O00 ,'select',ART +'APK.png',FANART )#line:645
def APKSELECT2 (O000000O00OOOO0O0 ):#line:646
	OO0OOOO000O0O0O00 =wiz .openURL (O000000O00OOOO0O0 )#line:647
	O0OO000OO00O0O0O0 =O000000O00OOOO0O0 #line:648
	if "page="in str (O000000O00OOOO0O0 ):#line:649
		O0OO000OO00O0O0O0 =O000000O00OOOO0O0 .split ('?')[0 ]#line:650
	OO00OO00O00O000O0 =re .compile ('<a href="([^"]*)".+?<img src="([^"]*)" class="file_list_icon".+?alt="([^"]*)"',re .DOTALL ).findall (OO0OOOO000O0O0O00 )#line:651
	OOOOOO0OO0OOO00O0 =re .compile ('class="[^"]*".+?ref="([^"]*)".+?yle=.+?</a>').findall (OO0OOOO000O0O0O00 )#line:652
	for O000000O00OOOO0O0 ,OO00000OOOO000OOO ,O000O00O00O00000O in OO00OO00O00O000O0 :#line:653
		if 'apk'in O000000O00OOOO0O0 :#line:654
			addDir2 ((O000O00O00O00000O ).replace ('&#39;','').replace ('&amp;',' - ').replace ('&#174;:',': ').replace ('&#174;',' '),'https://www.apkfiles.com'+O000000O00OOOO0O0 ,'grab','http:'+OO00000OOOO000OOO ,FANART )#line:655
	if len (OOOOOO0OO0OOO00O0 )>1 :#line:656
		OOOOOO0OO0OOO00O0 =str (OOOOOO0OO0OOO00O0 [len (OOOOOO0OO0OOO00O0 )-1 ])#line:657
	addDir2 ('Next Page',O0OO000OO00O0O0O0 +str (OOOOOO0OO0OOO00O0 ),'select',ART +'Next.png',FANART )#line:658
def APKGRAB (O000OOOO00O000000 ,OOO000OOO0O0O000O ):#line:659
	O000O0O0O00OO0O00 =wiz .openURL (OOO000OOO0O0O000O )#line:660
	O000OOOO00O000000 =O000OOOO00O000000 #line:661
	O0O0OOOOOO0OOO00O =re .compile ('href="([^"]*)".+?lass="yellow_button".+?itle=').findall (O000O0O0O00OO0O00 )#line:662
	for OOO000OOO0O0O000O in O0O0OOOOOO0OOO00O :#line:663
		OOO000OOO0O0O000O ='https://www.apkfiles.com'+OOO000OOO0O0O000O #line:664
		apkInstaller1 (O000OOOO00O000000 ,OOO000OOO0O0O000O )#line:665
def retromenu ():#line:668
	MKDIRS ()#line:669
	if HIDESPACERS =='No':addFile (wiz .sep ('Emulators'),'',themeit =THEME3 )#line:670
	if wiz .platform ()=='android'or DEVELOPER =='true':addDir ('Emulator APKs','emumenu',icon =ICONSAVE ,themeit =THEME1 )#line:671
	if wiz .platform ()=='windows'or DEVELOPER =='true':addDir ('Emulator APPs','emumenu',icon =ICONSAVE ,themeit =THEME1 )#line:672
	if HIDESPACERS =='No':addFile (wiz .sep ('Rom Packs'),'',themeit =THEME3 )#line:673
	addDir ('Rom Pack Zips','rompackmenu',icon =ICONSAVE ,themeit =THEME1 )#line:674
def emumenu ():#line:675
	O00O000OO000OO0OO =wiz .openURL (EMUAPKS ).replace ('\n','').replace ('\r','').replace ('\t','')#line:676
	O00O0O000OO000O00 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O00O000OO000OO0OO )#line:677
	if len (O00O0O000OO000O00 )>0 :#line:678
		if wiz .platform ()=='android':#line:679
			for OO0OO00OO0O0O000O ,O00O00OO00OO0OO00 ,O00OO0OO0O0O0OO0O ,OO00000000OOOOOO0 in O00O0O000OO000O00 :#line:680
				addFile (OO0OO00OO0O0O000O ,'apkinstall',OO0OO00OO0O0O000O ,O00O00OO00OO0OO00 ,icon =O00OO0OO0O0O0OO0O ,fanart =OO00000000OOOOOO0 ,themeit =THEME1 )#line:681
		elif wiz .platform ()=='windows':#line:682
			DIALOG .ok (ADDONTITLE ,"[COLOR yellow]Please go download RetroArch for PC[/COLOR]"," Goto http://tinyurl.com/RetroFTG for a full tutorial")#line:683
		elif wiz .platform ()=='linux':#line:684
			DIALOG .ok (ADDONTITLE ,"[COLOR yellow]Please go download RetroArch for PC[/COLOR]"," Goto http://tinyurl.com/RetroFTG for a full tutorial")#line:685
def rompackmenu ():#line:686
	O00O000O00OO00O00 =wiz .openURL (ROMPACK ).replace ('\n','').replace ('\r','').replace ('\t','')#line:687
	O0OOO0O000O0OO0OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O00O000O00OO00O00 )#line:688
	if len (O0OOO0O000O0OO0OO )>0 :#line:689
		for O00O00OO0OO0O0OO0 ,OO00O00OO0OOOOOO0 ,OO00OO000O00O0O00 ,OO0OOO0OOOO0OO0O0 in O0OOO0O000O0OO0OO :#line:690
			addFile (O00O00OO0OO0O0OO0 ,'UNZIPROM',O00O00OO0OO0O0OO0 ,OO00O00OO0OOOOOO0 ,icon =OO00OO000O00O0O00 ,fanart =OO0OOO0OOOO0OO0O0 ,themeit =THEME1 )#line:691
def UNZIPROM ():#line:692
	O00O0O0OO0O000O00 =xbmc .translatePath (BACKUPROMS )#line:693
	if O00O0O0OO0O000O00 =='':#line:694
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that you do not have an extract location setup for Rom Packs"%COLOR2 ,"Would you like to set one?[/COLOR]",yeslabel ="[COLOR green][B]Set Location[/B][/COLOR]",nolabel ="[COLOR red][B]Cancel Download[/B][/COLOR]"):#line:695
			wiz .openS ('rompath')#line:696
			O00O0O0OO0O000O00 =wiz .getS ('rompath')#line:697
			if O00O0O0OO0O000O00 =='':return #line:698
	O00O0OO000O000OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Are you sure you would like to download and extract [COLOR %s]%s[/COLOR] to:"%(COLOR2 ,COLOR1 ,name ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0O0OO0O000O00 ),yeslabel ="[B][COLOR green]Download[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:699
	if not O00O0OO000O000OOO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:700
	OOOOO00O0000OO000 =name #line:701
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:702
	if not wiz .workingURL (url )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Rom Installer: Invalid Rom Url![/COLOR]'%COLOR2 );return #line:703
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO00O0000OO000 ),'','Please Wait')#line:704
	OO0O000O00OOOO0OO =os .path .join (PACKAGES ,"%s.zip"%name .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:705
	try :os .remove (OO0O000O00OOOO0OO )#line:706
	except :pass #line:707
	downloader .download (url ,OO0O000O00OOOO0OO ,DP )#line:708
	xbmc .sleep (100 )#line:709
	O00OO000O0OOOOO0O ,OO0O000OO00OOOO00 ,O0O0O000OO000O0OO =extract .all (OO0O000O00OOOO0OO ,O00O0O0OO0O000O00 ,DP ,title =OOOOO00O0000OO000 )#line:710
	try :os .remove (OO0O000O00OOOO0OO )#line:711
	except :pass #line:712
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Rom Pack Installed[/COLOR]'%COLOR2 )#line:713
	DP .close ()#line:714
def MKDIRS ():#line:715
	if not os .path .exists (ROMLOC ):os .makedirs (ROMLOC )#line:716
def buildVideo (OOO00OO0000OOOOO0 ):#line:720
	if wiz .workingURL (BUILDFILE )==True :#line:721
		OOOO000O00O0OOO0O =wiz .checkBuild (OOO00OO0000OOOOO0 ,'preview')#line:722
		wiz .FTGlog ('Name %s'%OOO00OO0000OOOOO0 )#line:723
		wiz .FTGlog ('URL %s'%OOOO000O00O0OOO0O )#line:724
		if OOOO000O00O0OOO0O and not OOOO000O00O0OOO0O =='http://':playVideoB (OOOO000O00O0OOO0O )#line:725
		else :wiz .log ("[%s]Unable to find url for video preview"%OOO00OO0000OOOOO0 )#line:726
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:727
def playVideo (O00OO0OOOO0O0OO00 ):#line:730
	if 'watch?v='in O00OO0OOOO0O0OO00 :#line:731
		O0OOO0O00O0O0000O ,OO0OOO000000000O0 =O00OO0OOOO0O0OO00 .split ('?')#line:732
		OO0OOO0OO00O0O0O0 =OO0OOO000000000O0 .split ('&')#line:733
		for OO00OOOO00O0OOOOO in OO0OOO0OO00O0O0O0 :#line:734
			if OO00OOOO00O0OOOOO .startswith ('v='):#line:735
				O00OO0OOOO0O0OO00 =OO00OOOO00O0OOOOO [2 :]#line:736
				break #line:737
			else :continue #line:738
	elif 'embed'in O00OO0OOOO0O0OO00 or 'youtu.be'in O00OO0OOOO0O0OO00 :#line:739
		O0OOO0O00O0O0000O =O00OO0OOOO0O0OO00 .split ('/')#line:740
		if len (O0OOO0O00O0O0000O [-1 ])>5 :#line:741
			O00OO0OOOO0O0OO00 =O0OOO0O00O0O0000O [-1 ]#line:742
		elif len (O0OOO0O00O0O0000O [-2 ])>5 :#line:743
			O00OO0OOOO0O0OO00 =O0OOO0O00O0O0000O [-2 ]#line:744
	wiz .log ("YouTube URL: %s"%O00OO0OOOO0O0OO00 )#line:745
	if wiz .getCond ('System.HasAddon(plugin.video.youtube)')==1 :#line:746
		O00OO0OOOO0O0OO00 ='plugin://plugin.video.youtube/play/?video_id=%s'%O00OO0OOOO0O0OO00 #line:747
		xbmc .Player ().play (O00OO0OOOO0O0OO00 )#line:748
	xbmc .sleep (2000 )#line:749
	if xbmc .Player ().isPlayingVideo ()==0 :#line:750
		 yt .PlayVideo (O00OO0OOOO0O0OO00 )#line:751
def addonMenu (name =None ,url =None ):#line:753
	if not ADDONFILE =='http://':#line:754
		if url ==None :#line:755
			OOOOO0OO0OOOO0O0O =wiz .textCache (uservar .ADDONFILE )#line:756
			if OOOOO0OO0OOOO0O0O ==False :OO000OO00O0OO0000 =wiz .workingURL (uservar .ADDONFILE )#line:757
		else :#line:758
			OOOOO0OO0OOOO0O0O =wiz .textCache (url )#line:759
			if OOOOO0OO0OOOO0O0O ==False :OO000OO00O0OO0000 =wiz .workingURL (url )#line:760
		if not OOOOO0OO0OOOO0O0O ==False :#line:761
			OOOO00OO0O000OOO0 =OOOOO0OO0OOOO0O0O .replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:762
			O00O0O0O000O0O000 =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOO00OO0O000OOO0 )#line:763
			if len (O00O0O0O000O0O000 )>0 :#line:764
				O0O0OO0O0O00OO0O0 =0 #line:765
				for O0O00O0OO00O0O00O ,OOO00O0OO00OOO0O0 ,OO0OOO0O0000O000O ,O0O00O0O0OOO00O0O ,OOOOOO000OO0000OO ,OO0O0O0O0O00O0OO0 ,OO00OO00OO0O0OOOO ,OOO0000O0OO0OO00O ,O0O00OO00OOOOOOOO ,OO00000OOOOO000O0 in O00O0O0O000O0O000 :#line:766
					if OOO00O0OO00OOO0O0 .lower ()=='section':#line:767
						addonMenu (name ,url )#line:768
					elif OOO00O0OO00OOO0O0 .lower ()=='skin':#line:769
						skinInstaller (name ,url )#line:770
					elif OOO00O0OO00OOO0O0 .lower ()=='pack':#line:771
						packInstaller (name ,url )#line:772
					else :#line:773
						if not SHOWADULT =='true'and O0O00OO00OOOOOOOO .lower ()=='yes':continue #line:774
						try :#line:775
							OOO0O00O0OOOO0OOO =xbmcaddon .Addon (id =OOO00O0OO00OOO0O0 ).getAddonInfo ('path')#line:776
							if os .path .exists (OOO0O00O0OOOO0OOO ):#line:777
								O0O00O0OO00O0O00O ="[COLOR green][מותקן][/COLOR] %s"%O0O00O0OO00O0O00O #line:778
						except :#line:779
							pass #line:780
						addonInstaller (OOO00O0OO00OOO0O0 ,url )#line:781
					if O0O0OO0O0O00OO0O0 <1 :#line:782
						wiz .LogNotify ("[COLOR %s]אין הרחבות[/COLOR]"%COLOR1 )#line:783
			else :#line:784
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:785
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:786
		else :#line:787
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:788
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:789
			addFile ('%s'%OO000OO00O0OO0000 ,'',themeit =THEME3 )#line:790
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:791
def packInstaller (OO0O00000000OOO0O ,OO0OO0O00000OOOOO ):#line:795
	if not wiz .workingURL (OO0OO0O00000OOOOO )==True :wiz .LogNotify ("[COLOR %s]התקנת הרחבה [/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]כתובת זיפ שגויה[/COLOR]'%(COLOR1 ,OO0O00000000OOO0O ,COLOR2 ));return #line:796
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:797
	DP .create (ADDONTITLE ,'[COLOR %s][B]הורדה מתבצעת [/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O00000000OOO0O ),'','[COLOR %s] אנא המתן [/COLOR]'%COLOR2 )#line:798
	O00O00OOOO0OO000O =OO0OO0O00000OOOOO .split ('/')#line:799
	O0OO0000OO0OO0000 =xbmc .makeLegalFilename (os .path .join (PACKAGES ,O00O00OOOO0OO000O [-1 ]))#line:800
	try :os .remove (O0OO0000OO0OO0000 )#line:801
	except :pass #line:802
	downloader .download (OO0OO0O00000OOOOO ,O0OO0000OO0OO0000 ,DP )#line:803
	OOOO0000O0OO00O0O ='[COLOR %s][B] מתקין: [/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O00000000OOO0O )#line:804
	DP .update (0 ,OOOO0000O0OO00O0O ,'','[COLOR %s]אנא המתן [/COLOR]'%COLOR2 )#line:805
	OO0O0000OO0O00O00 ,OO0O0O00OOOO0OOO0 ,O00000OOO000O0OOO =extract .all (O0OO0000OO0OO0000 ,ADDONS ,DP ,title =OOOO0000O0OO00O0O )#line:806
	OO0O000OOOOOO0O0O =grabAddons (O0OO0000OO0OO0000 )#line:807
	if KODIV >=17 :wiz .addonDatabase (OO0O000OOOOOO0O0O ,1 ,True )#line:808
	DP .close ()#line:809
	wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s: Installed![/COLOR]'%(COLOR2 ,OO0O00000000OOO0O ))#line:810
	wiz .ebi ('UpdateAddonRepos()')#line:811
	wiz .ebi ('UpdateLocalAddons()')#line:812
	wiz .refresh ()#line:813
def skinInstaller (OOO00000O00O0O0O0 ,OO0O0O0OOOO0OOO00 ):#line:814
	if not wiz .workingURL (OO0O0O0OOOO0OOO00 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]Invalid Zip Url![/COLOR]'%(COLOR1 ,OOO00000O00O0O0O0 ,COLOR2 ));return #line:815
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:816
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00000O00O0O0O0 ),'','[COLOR %s]Please Wait[/COLOR]'%COLOR2 )#line:817
	OOOOOOOOO00000OO0 =OO0O0O0OOOO0OOO00 .split ('/')#line:818
	OOO0O0000OO0OO00O =xbmc .makeLegalFilename (os .path .join (PACKAGES ,OOOOOOOOO00000OO0 [-1 ]))#line:819
	try :os .remove (OOO0O0000OO0OO00O )#line:820
	except :pass #line:821
	downloader .download (OO0O0O0OOOO0OOO00 ,OOO0O0000OO0OO00O ,DP )#line:822
	OO0OOO0O0O00OOO00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00000O00O0O0O0 )#line:823
	DP .update (0 ,OO0OOO0O0O00OOO00 ,'','[COLOR %s]Please Wait[/COLOR]'%COLOR2 )#line:824
	OO0O00OOOOOO0000O ,OO00OOOO0O00000O0 ,OO0O00O000000000O =extract .all (OOO0O0000OO0OO00O ,HOME ,DP ,title =OO0OOO0O0O00OOO00 )#line:825
	O0OOO0O00OO0OO000 =grabAddons (OOO0O0000OO0OO00O )#line:826
	if KODIV >=17 :wiz .addonDatabase (O0OOO0O00OO0OO000 ,1 ,True )#line:827
	DP .close ()#line:828
	wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s: Installed![/COLOR]'%(COLOR2 ,OOO00000O00O0O0O0 ))#line:829
	wiz .ebi ('UpdateAddonRepos()')#line:830
	wiz .ebi ('UpdateLocalAddons()')#line:831
	for O0OO0O00000O0OOOO in O0OOO0O00OO0OO000 :#line:832
		if O0OO0O00000O0OOOO .startswith ('skin.')==True and not O0OO0O00000O0OOOO =='skin.shortcuts':#line:833
			if not BUILDNAME ==''and DEFAULTIGNORE =='true':wiz .setS ('defaultskinignore','true')#line:834
			wiz .swapSkins (O0OO0O00000O0OOOO ,'Skin Installer')#line:835
	wiz .refresh ()#line:836
def download (OOO0OO0O000OOO00O ,O0O0000O00O0OO00O ):#line:838
  OO0O0O0O00O00O000 =xbmc .translatePath (os .path .join ('special://home/addons','packages'))#line:839
  OOOO0O00O000OOO00 =xbmcgui .DialogProgress ()#line:840
  OOOO0O00O000OOO00 .create ("XBMC ISRAEL","Downloading "+name ,'','Please Wait')#line:841
  O0OOOO0OOOO0O0O0O =os .path .join (OO0O0O0O00O00O000 ,'isr.zip')#line:842
  O000000OOO00O000O =urllib2 .Request (OOO0OO0O000OOO00O )#line:843
  O0OOO0000OOO00000 =urllib2 .urlopen (O000000OOO00O000O )#line:844
  O000OO0OO00O0OO00 =xbmcgui .DialogProgress ()#line:846
  O000OO0OO00O0OO00 .create ("Downloading","Downloading "+name )#line:847
  O000OO0OO00O0OO00 .update (0 )#line:848
  O0O0O00OOOO0O0OO0 =O0O0000O00O0OO00O #line:849
  OOOOO0O0000O00O0O =open (O0OOOO0OOOO0O0O0O ,'wb')#line:850
  try :#line:852
    O0O000OOOO0OOOO00 =O0OOO0000OOO00000 .info ().getheader ('Content-Length').strip ()#line:853
    O0O00OO00O0OO00O0 =True #line:854
  except AttributeError :#line:855
        O0O00OO00O0OO00O0 =False #line:856
  if O0O00OO00O0OO00O0 :#line:858
        O0O000OOOO0OOOO00 =int (O0O000OOOO0OOOO00 )#line:859
  O0O0000OO00OO000O =0 #line:861
  O00O000OOO00OOOOO =time .time ()#line:862
  while True :#line:863
        OO00OO0O0OO000O00 =O0OOO0000OOO00000 .read (8192 )#line:864
        if not OO00OO0O0OO000O00 :#line:865
            sys .stdout .write ('\n')#line:866
            break #line:867
        O0O0000OO00OO000O +=len (OO00OO0O0OO000O00 )#line:869
        OOOOO0O0000O00O0O .write (OO00OO0O0OO000O00 )#line:870
        if not O0O00OO00O0OO00O0 :#line:872
            O0O000OOOO0OOOO00 =O0O0000OO00OO000O #line:873
        if O000OO0OO00O0OO00 .iscanceled ():#line:874
           O000OO0OO00O0OO00 .close ()#line:875
           try :#line:876
            os .remove (O0OOOO0OOOO0O0O0O )#line:877
           except :#line:878
            pass #line:879
           break #line:880
        OOO0OO00OOO0000OO =float (O0O0000OO00OO000O )/O0O000OOOO0OOOO00 #line:881
        OOO0OO00OOO0000OO =round (OOO0OO00OOO0000OO *100 ,2 )#line:882
        OO00OOO00OOOOO00O =O0O0000OO00OO000O /(1024 *1024 )#line:883
        OOOO0OO0OO0OOOO0O =O0O000OOOO0OOOO00 /(1024 *1024 )#line:884
        OOOO0000OOO000O0O ='[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]'%('teal','skyblue',OO00OOO00OOOOO00O ,'teal',OOOO0OO0OO0OOOO0O )#line:885
        if (time .time ()-O00O000OOO00OOOOO )>0 :#line:886
          OOO000O0O00O0O0O0 =O0O0000OO00OO000O /(time .time ()-O00O000OOO00OOOOO )#line:887
          OOO000O0O00O0O0O0 =OOO000O0O00O0O0O0 /1024 #line:888
        else :#line:889
         OOO000O0O00O0O0O0 =0 #line:890
        O0OOO0OO00O00O0O0 ='KB'#line:891
        if OOO000O0O00O0O0O0 >=1024 :#line:892
           OOO000O0O00O0O0O0 =OOO000O0O00O0O0O0 /1024 #line:893
           O0OOO0OO00O00O0O0 ='MB'#line:894
        if OOO000O0O00O0O0O0 >0 and not OOO0OO00OOO0000OO ==100 :#line:895
            OO0OO00O0OO00O0O0 =(O0O000OOOO0OOOO00 -O0O0000OO00OO000O )/OOO000O0O00O0O0O0 #line:896
        else :#line:897
            OO0OO00O0OO00O0O0 =0 #line:898
        OO000O0O0O0OOO0OO ='[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s '%('teal','skyblue',OOO000O0O00O0O0O0 ,O0OOO0OO00O00O0O0 )#line:899
        O000OO0OO00O0OO00 .update (int (OOO0OO00OOO0000OO ),"Downloading "+name ,OOOO0000OOO000O0O ,OO000O0O0O0OOO0OO )#line:901
  OO0000O00OOOOO00O =xbmc .translatePath (os .path .join ('special://home','addons'))#line:904
  OOOOO0O0000O00O0O .close ()#line:906
  extract (O0OOOO0OOOO0O0O0O ,OO0000O00OOOOO00O ,O000OO0OO00O0OO00 )#line:908
  if os .path .exists (OO0000O00OOOOO00O +'/scakemyer-script.quasar.burst'):#line:909
    if os .path .exists (OO0000O00OOOOO00O +'/script.quasar.burst'):#line:910
     shutil .rmtree (OO0000O00OOOOO00O +'/script.quasar.burst',ignore_errors =False )#line:911
    os .rename (OO0000O00OOOOO00O +'/scakemyer-script.quasar.burst',OO0000O00OOOOO00O +'/script.quasar.burst')#line:912
  if os .path .exists (OO0000O00OOOOO00O +'/plugin.video.kmediatorrent-master'):#line:914
    if os .path .exists (OO0000O00OOOOO00O +'/plugin.video.kmediatorrent'):#line:915
     shutil .rmtree (OO0000O00OOOOO00O +'/plugin.video.kmediatorrent',ignore_errors =False )#line:916
    os .rename (OO0000O00OOOOO00O +'/plugin.video.kmediatorrent-master',OO0000O00OOOOO00O +'/plugin.video.kmediatorrent')#line:917
  xbmc .executebuiltin ('UpdateLocalAddons ')#line:918
  xbmc .executebuiltin ("UpdateAddonRepos")#line:919
  try :#line:920
    os .remove (O0OOOO0OOOO0O0O0O )#line:921
  except :#line:922
    pass #line:923
  O000OO0OO00O0OO00 .close ()#line:924
def dis_or_enable_addon (O00OOO00OO00OOOO0 ,OO0O0OO00O0OOO00O ,enable ="true"):#line:925
    import json #line:926
    O00O00000O0OOO00O ='"%s"'%O00OOO00OO00OOOO0 #line:927
    if xbmc .getCondVisibility ("System.HasAddon(%s)"%O00OOO00OO00OOOO0 )and enable =="true":#line:928
        logging .warning ('already Enabled')#line:929
        return xbmc .log ("### Skipped %s, reason = allready enabled"%O00OOO00OO00OOOO0 )#line:930
    elif not xbmc .getCondVisibility ("System.HasAddon(%s)"%O00OOO00OO00OOOO0 )and enable =="false":#line:931
        return xbmc .log ("### Skipped %s, reason = not installed"%O00OOO00OO00OOOO0 )#line:932
    else :#line:933
        OO000O00000OOO0OO ='{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}'%(O00O00000O0OOO00O ,enable )#line:934
        O000OO00OO0O0O0O0 =xbmc .executeJSONRPC (OO000O00000OOO0OO )#line:935
        OOO0O0000O0000O0O =json .loads (O000OO00OO0O0O0O0 )#line:936
        if enable =="true":#line:937
            xbmc .log ("### Enabled %s, response = %s"%(O00OOO00OO00OOOO0 ,OOO0O0000O0000O0O ))#line:938
        else :#line:939
            xbmc .log ("### Disabled %s, response = %s"%(O00OOO00OO00OOOO0 ,OOO0O0000O0000O0O ))#line:940
    if OO0O0OO00O0OOO00O =='auto':#line:941
     return True #line:942
    return xbmc .executebuiltin ('Container.Update(%s)'%xbmc .getInfoLabel ('Container.FolderPath'))#line:943
def chunk_report (O00O00OO00O0O00O0 ,OOOO0OOO00OO0O000 ,O0O0O0O00O00O0OO0 ):#line:944
   OOO0OOO00O0O00OOO =float (O00O00OO00O0O00O0 )/O0O0O0O00O00O0OO0 #line:945
   OOO0OOO00O0O00OOO =round (OOO0OOO00O0O00OOO *100 ,2 )#line:946
   if O00O00OO00O0O00O0 >=O0O0O0O00O00O0OO0 :#line:948
      sys .stdout .write ('\n')#line:949
def chunk_read (O0O0OO00OO00OOO00 ,chunk_size =8192 ,report_hook =None ,dp =None ,destination ='',filesize =1000000 ):#line:951
   import time #line:952
   O0000OOO00OO00000 =int (filesize )*1000000 #line:953
   O0O0OO0OOO00000OO =0 #line:955
   O00O00OOOOOOOOOOO =time .time ()#line:956
   OOOO000O00OOOO00O =0 #line:957
   logging .warning ('Downloading')#line:959
   with open (destination ,"wb")as O00000OOOO00OOO0O :#line:960
    while 1 :#line:961
      O0O0OO0OOO0O0O00O =time .time ()-O00O00OOOOOOOOOOO #line:962
      OOOO0OO00OOO0000O =int (OOOO000O00OOOO00O *chunk_size )#line:963
      O000OOO000000O000 =O0O0OO00OO00OOO00 .read (chunk_size )#line:964
      O00000OOOO00OOO0O .write (O000OOO000000O000 )#line:965
      O00000OOOO00OOO0O .flush ()#line:966
      O0O0OO0OOO00000OO +=len (O000OOO000000O000 )#line:967
      OOOOO00O00OO0O000 =float (O0O0OO0OOO00000OO )/O0000OOO00OO00000 #line:968
      OOOOO00O00OO0O000 =round (OOOOO00O00OO0O000 *100 ,2 )#line:969
      if int (O0O0OO0OOO0O0O00O )>0 :#line:970
        OO0O00000OOO0O00O =int (OOOO0OO00OOO0000O /(1024 *O0O0OO0OOO0O0O00O ))#line:971
      else :#line:972
         OO0O00000OOO0O00O =0 #line:973
      if OO0O00000OOO0O00O >1024 and not OOOOO00O00OO0O000 ==100 :#line:974
          O000O00000O0O0O00 =int (((O0000OOO00OO00000 -OOOO0OO00OOO0000O )/1024 )/(OO0O00000OOO0O00O ))#line:975
      else :#line:976
          O000O00000O0O0O00 =0 #line:977
      if O000O00000O0O0O00 <0 :#line:978
        O000O00000O0O0O00 =0 #line:979
      dp .update (int (OOOOO00O00OO0O000 ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOOOO00O00OO0O000 ,OOOO0OO00OOO0000O /(1024 *1024 ),O0000OOO00OO00000 /(1000 *1000 ),OO0O00000OOO0O00O ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O000O00000O0O0O00 ,60 ))#line:980
      if dp .iscanceled ():#line:981
         dp .close ()#line:982
         break #line:983
      if not O000OOO000000O000 :#line:984
         break #line:985
      if report_hook :#line:987
         report_hook (O0O0OO0OOO00000OO ,chunk_size ,O0000OOO00OO00000 )#line:988
      OOOO000O00OOOO00O +=1 #line:989
   logging .warning ('END Downloading')#line:990
   return O0O0OO0OOO00000OO #line:991
def googledrive_download (OO0OO0OOO0O00OO00 ,O000O0OOO00OO00O0 ,OO00O00000OOOO00O ,O0O0OO0O000OOO000 ):#line:993
    O0O0O0OO0OO000000 =[]#line:997
    OO0O000O0O000OOOO =OO0OO0OOO0O00OO00 .split ('=')#line:998
    OO0OO0OOO0O00OO00 =OO0O000O0O000OOOO [len (OO0O000O0O000OOOO )-1 ]#line:999
    def OO0000OOOO000O000 (O00O0O0OOO00O00O0 ):#line:1001
        for O0O00O000OO0OOOOO in O00O0O0OOO00O00O0 :#line:1003
            logging .warning ('cookie.name')#line:1004
            logging .warning (O0O00O000OO0OOOOO .name )#line:1005
            OOO000O000O00OO0O =O0O00O000OO0OOOOO .value #line:1006
            if 'download_warning'in O0O00O000OO0OOOOO .name :#line:1007
                logging .warning (O0O00O000OO0OOOOO .value )#line:1008
                logging .warning ('cookie.value')#line:1009
                return O0O00O000OO0OOOOO .value #line:1010
            return OOO000O000O00OO0O #line:1011
        return None #line:1013
    def O00O000OOOO0OOOOO (OOO000O0OO0O00OOO ,OOOO000O0000000OO ):#line:1015
        OO0OO00OO00OO0O00 =32768 #line:1017
        O000OO000O000O0O0 =time .time ()#line:1018
        with open (OOOO000O0000000OO ,"wb")as O00OO0OOOO000000O :#line:1020
            O00OO0OO0O0OOOOOO =1 #line:1021
            OO0O000OOO0O00000 =32768 #line:1022
            try :#line:1023
                OO0OO000OOOOOO0OO =int (OOO000O0OO0O00OOO .headers .get ('content-length'))#line:1024
                print ('file total size :',OO0OO000OOOOOO0OO )#line:1025
            except TypeError :#line:1026
                print ('using dummy length !!!')#line:1027
                OO0OO000OOOOOO0OO =int (O0O0OO0O000OOO000 )*1000000 #line:1028
            for OOOOO0OO0O00OOOO0 in OOO000O0OO0O00OOO .iter_content (OO0OO00OO00OO0O00 ):#line:1029
                if OOOOO0OO0O00OOOO0 :#line:1030
                    O00OO0OOOO000000O .write (OOOOO0OO0O00OOOO0 )#line:1031
                    O00OO0OOOO000000O .flush ()#line:1032
                    O0O0OOOO00000O00O =time .time ()-O000OO000O000O0O0 #line:1033
                    OOOO000OOOOO0000O =int (O00OO0OO0O0OOOOOO *OO0O000OOO0O00000 )#line:1034
                    if O0O0OOOO00000O00O ==0 :#line:1035
                        O0O0OOOO00000O00O =0.1 #line:1036
                    O0O0O00O0OOOO0O00 =int (OOOO000OOOOO0000O /(1024 *O0O0OOOO00000O00O ))#line:1037
                    OOOO000O0OO0OOO0O =int (O00OO0OO0O0OOOOOO *OO0O000OOO0O00000 *100 /OO0OO000OOOOOO0OO )#line:1038
                    if O0O0O00O0OOOO0O00 >1024 and not OOOO000O0OO0OOO0O ==100 :#line:1039
                      O0OOO0OOOOO00O0O0 =int (((OO0OO000OOOOOO0OO -OOOO000OOOOO0000O )/1024 )/(O0O0O00O0OOOO0O00 ))#line:1040
                    else :#line:1041
                      O0OOO0OOOOO00O0O0 =0 #line:1042
                    OO00O00000OOOO00O .update (int (OOOO000O0OO0OOO0O ),name ,"\r%d%%,[COLOR aqua] %d MB / %d MB [/COLOR], %d KB/s "%(OOOO000O0OO0OOO0O ,OOOO000OOOOO0000O /(1024 *1024 ),OO0OO000OOOOOO0OO /(1000 *1000 ),O0O0O00O0OOOO0O00 ),'[B]ETA:[/B] [COLOR aqua]%02d:%02d[/COLOR]'%divmod (O0OOO0OOOOO00O0O0 ,60 ))#line:1044
                    O00OO0OO0O0OOOOOO +=1 #line:1045
                    if OO00O00000OOOO00O .iscanceled ():#line:1046
                     OO00O00000OOOO00O .close ()#line:1047
                     break #line:1048
    O0O00000O0OO00O00 ="https://docs.google.com/uc?export=download"#line:1049
    import urllib2 #line:1054
    import cookielib #line:1055
    from cookielib import CookieJar #line:1057
    OOO0O0000OO000000 =CookieJar ()#line:1059
    OOO0O0OOOOO0OO000 =urllib2 .build_opener (urllib2 .HTTPCookieProcessor (OOO0O0000OO000000 ))#line:1060
    O0OO00O00OO0O00O0 ={'id':OO0OO0OOO0O00OO00 }#line:1062
    O00000OOOO0OOOO0O =urllib .urlencode (O0OO00O00OO0O00O0 )#line:1063
    logging .warning (O0O00000O0OO00O00 +'&'+O00000OOOO0OOOO0O )#line:1064
    O0O000OO0OOO0O00O =OOO0O0OOOOO0OO000 .open (O0O00000O0OO00O00 +'&'+O00000OOOO0OOOO0O )#line:1065
    OO000O0OO00OO0OO0 =O0O000OO0OOO0O00O .read ()#line:1066
    for O0O0000000000O0OO in OOO0O0000OO000000 :#line:1068
         logging .warning (O0O0000000000O0OO )#line:1069
    O000O0O0OO0O0OOO0 =OO0000OOOO000O000 (OOO0O0000OO000000 )#line:1070
    logging .warning (O000O0O0OO0O0OOO0 )#line:1071
    if O000O0O0OO0O0OOO0 :#line:1072
        O000OOOO0O0OO0O0O ={'id':OO0OO0OOO0O00OO00 ,'confirm':O000O0O0OO0O0OOO0 }#line:1073
        OOOO0O0OO00O0O0OO ={'Access-Control-Allow-Headers':'Content-Length'}#line:1074
        O00000OOOO0OOOO0O =urllib .urlencode (O000OOOO0O0OO0O0O )#line:1075
        O0O000OO0OOO0O00O =OOO0O0OOOOO0OO000 .open (O0O00000O0OO00O00 +'&'+O00000OOOO0OOOO0O )#line:1076
        chunk_read (O0O000OO0OOO0O00O ,report_hook =chunk_report ,dp =OO00O00000OOOO00O ,destination =O000O0OOO00OO00O0 ,filesize =O0O0OO0O000OOO000 )#line:1077
    return (O0O0O0OO0OO000000 )#line:1081
def addonInstaller (O000000O00O00O0OO ,O00O00OOOOOO0OOO0 ):#line:1083
	if not ADDONFILE =='http://'or '':#line:1084
		O00O00OOOOOO0OOO0 =ADDONFILE #line:1085
		O00OO0OO0OOOOOOO0 =wiz .workingURL (O00O00OOOOOO0OOO0 )#line:1086
		if O00OO0OO0OOOOOOO0 ==True :#line:1087
			OO0OO00O00O0O00OO =wiz .textCache (O00O00OOOOOO0OOO0 ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:1088
			OO000OOO000O0OO0O =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O000000O00O00O0OO ).findall (OO0OO00O00O0O00OO )#line:1089
			if len (OO000OOO000O0OO0O )>0 :#line:1090
				for O0O000O00OOOOOOOO ,O00O00OOOOOO0OOO0 ,OO0OOO00O0OO00OO0 ,OOOO0O0000000OOOO ,O00O0OO0O00OO0OOO ,O00OOOO000OOOOO0O ,O000O0OOOO0OO00OO ,OO0O00OO00O00000O ,OOOOO0O00O00O0000 in OO000OOO000O0OO0O :#line:1091
					if os .path .exists (os .path .join (ADDONS ,O000000O00O00O0OO )):#line:1092
						OOOOOO000OO0O00O0 =['Launch Addon','Remove Addon']#line:1093
						OOOO000O0OOOO00O0 =DIALOG .select ("[COLOR %s] נראה  שההרחבה מותקנת, מה ברצונך לעשות?[/COLOR]"%COLOR2 ,OOOOOO000OO0O00O0 )#line:1094
						if OOOO000O0OOOO00O0 ==0 :#line:1095
							wiz .ebi ('RunAddon(%s)'%O000000O00O00O0OO )#line:1096
							xbmc .sleep (500 )#line:1097
							return True #line:1098
						elif OOOO000O0OOOO00O0 ==1 :#line:1099
							wiz .cleanHouse (os .path .join (ADDONS ,O000000O00O00O0OO ))#line:1100
							try :wiz .removeFolder (os .path .join (ADDONS ,O000000O00O00O0OO ))#line:1101
							except :pass #line:1102
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O000000O00O00O0OO ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:1103
								removeAddonData (O000000O00O00O0OO )#line:1104
							wiz .refresh ()#line:1105
							return True #line:1106
						else :#line:1107
							return False #line:1108
					O0O0OO00OOOO0OO0O =os .path .join (ADDONS ,OO0OOO00O0OO00OO0 )#line:1109
					if not OO0OOO00O0OO00OO0 .lower ()=='none'and not os .path .exists (O0O0OO00OOOO0OO0O ):#line:1110
						wiz .log ("Repository not installed, installing it")#line:1111
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם ברצונך להתקין את מקור ההרחבה עובר הרחבה זו?  [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O000000O00O00O0OO ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OO0OOO00O0OO00OO0 ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:1112
							OO00O00O0OO0OOO0O =wiz .parseDOM (wiz .openURL (OOOO0O0000000OOOO ),'addon',ret ='version',attrs ={'id':OO0OOO00O0OO00OO0 })#line:1113
							if len (OO00O00O0OO0OOO0O )>0 :#line:1114
								OO00O00O000OOO0O0 ='%s%s-%s.zip'%(O00O0OO0O00OO0OOO ,OO0OOO00O0OO00OO0 ,OO00O00O0OO0OOO0O [0 ])#line:1115
								wiz .log (OO00O00O000OOO0O0 )#line:1116
								if KODIV >=17 :wiz .addonDatabase (OO0OOO00O0OO00OO0 ,1 )#line:1117
								installAddon (OO0OOO00O0OO00OO0 ,OO00O00O000OOO0O0 )#line:1118
								wiz .ebi ('UpdateAddonRepos()')#line:1119
								wiz .log ("Installing Addon from Kodi")#line:1121
								O0O00O0OO0OO00O0O =installFromKodi (O000000O00O00O0OO )#line:1122
								wiz .log ("Install from Kodi: %s"%O0O00O0OO0OO00O0O )#line:1123
								if O0O00O0OO0OO00O0O :#line:1124
									wiz .refresh ()#line:1125
									return True #line:1126
							else :#line:1127
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OO0OOO00O0OO00OO0 )#line:1128
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O000000O00O00O0OO ,OO0OOO00O0OO00OO0 ))#line:1129
					elif OO0OOO00O0OO00OO0 .lower ()=='none':#line:1130
						wiz .log ("No repository, installing addon")#line:1131
						O0O0O0OO0OO0O0000 =O000000O00O00O0OO #line:1132
						OO00OO000O0O0OOOO =O00O00OOOOOO0OOO0 #line:1133
						installAddon (O000000O00O00O0OO ,O00O00OOOOOO0OOO0 )#line:1134
						wiz .refresh ()#line:1135
						return True #line:1136
					else :#line:1137
						wiz .log ("Repository installed, installing addon")#line:1138
						O0O00O0OO0OO00O0O =installFromKodi (O000000O00O00O0OO ,False )#line:1139
						if O0O00O0OO0OO00O0O :#line:1140
							wiz .refresh ()#line:1141
							return True #line:1142
					if os .path .exists (os .path .join (ADDONS ,O000000O00O00O0OO )):return True #line:1143
					O0000O000000OOOOO =wiz .parseDOM (wiz .openURL (OOOO0O0000000OOOO ),'addon',ret ='version',attrs ={'id':O000000O00O00O0OO })#line:1144
					if len (O0000O000000OOOOO )>0 :#line:1145
						O00O00OOOOOO0OOO0 ="%s%s-%s.zip"%(O00O00OOOOOO0OOO0 ,O000000O00O00O0OO ,O0000O000000OOOOO [0 ])#line:1146
						wiz .log (str (O00O00OOOOOO0OOO0 ))#line:1147
						if KODIV >=17 :wiz .addonDatabase (O000000O00O00O0OO ,1 )#line:1148
						installAddon (O000000O00O00O0OO ,O00O00OOOOOO0OOO0 )#line:1149
						wiz .refresh ()#line:1150
					else :#line:1151
						wiz .log ("no match");return False #line:1152
			else :wiz .log ("[Addon Installer] Invalid Format")#line:1153
		else :wiz .log ("[Addon Installer] Text File: %s"%O00OO0OO0OOOOOOO0 )#line:1154
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:1155
def installFromKodi (O00O0O000O0OOOOOO ,over =True ):#line:1156
	if over ==True :#line:1157
		xbmc .sleep (2000 )#line:1158
	wiz .ebi ('RunPlugin(plugin://%s)'%O00O0O000O0OOOOOO )#line:1160
	if not wiz .whileWindow ('yesnodialog'):#line:1161
		return False #line:1162
	xbmc .sleep (500 )#line:1163
	if wiz .whileWindow ('okdialog'):#line:1164
		return False #line:1165
	wiz .whileWindow ('progressdialog')#line:1166
	if os .path .exists (os .path .join (ADDONS ,O00O0O000O0OOOOOO )):return True #line:1167
	else :return False #line:1168
def installAddon (O0O000OOO0OOO00O0 ,OOO0O0OOO0O00O00O ):#line:1169
	if not wiz .workingURL (OOO0O0OOO0O00O00O )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]Invalid Zip Url![/COLOR]'%(COLOR1 ,O0O000OOO0OOO00O0 ,COLOR2 ));return #line:1170
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:1171
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000OOO0OOO00O0 ),'','[COLOR %s]Please Wait[/COLOR]'%COLOR2 )#line:1172
	OOO00OO00OOO00OOO =OOO0O0OOO0O00O00O .split ('/')#line:1173
	OOO0OO000OO00OO0O =os .path .join (PACKAGES ,OOO00OO00OOO00OOO [-1 ])#line:1174
	try :os .remove (OOO0OO000OO00OO0O )#line:1175
	except :pass #line:1176
	downloader .download (OOO0O0OOO0O00O00O ,OOO0OO000OO00OO0O ,DP )#line:1177
	OOO000O0O00OO000O ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O000OOO0OOO00O0 )#line:1178
	DP .update (0 ,OOO000O0O00OO000O ,'','[COLOR %s]Please Wait[/COLOR]'%COLOR2 )#line:1179
	OO0000O0O00O00OO0 ,OO0O0O000OO0000O0 ,O000000000O000000 =extract .all (OOO0OO000OO00OO0O ,ADDONS ,DP ,title =OOO000O0O00OO000O )#line:1180
	DP .update (0 ,OOO000O0O00OO000O ,'','[COLOR %s]Installing Dependencies[/COLOR]'%COLOR2 )#line:1181
	installed (O0O000OOO0OOO00O0 )#line:1182
	OOO0O000OOOOO0OO0 =grabAddons (OOO0OO000OO00OO0O )#line:1183
	wiz .log (str (OOO0O000OOOOO0OO0 ))#line:1184
	if KODIV >=17 :wiz .addonDatabase (OOO0O000OOOOO0OO0 ,1 ,True )#line:1185
	installDep (O0O000OOO0OOO00O0 ,DP )#line:1186
	DP .close ()#line:1187
	wiz .ebi ('UpdateAddonRepos()')#line:1188
	wiz .ebi ('UpdateLocalAddons()')#line:1189
	wiz .refresh ()#line:1190
	for O0000OOOO000000OO in OOO0O000OOOOO0OO0 :#line:1191
		if O0000OOOO000000OO .startswith ('skin.')==True and not O0000OOOO000000OO =='skin.shortcuts':#line:1192
			if not BUILDNAME ==''and DEFAULTIGNORE =='true':wiz .setS ('defaultskinignore','true')#line:1193
			wiz .swapSkins (O0000OOOO000000OO ,'Skin Installer')#line:1194
def installDep (OOO0O00OOO0000OO0 ,DP =None ):#line:1195
	OOO0OOO0OOOOOOOOO =os .path .join (ADDONS ,OOO0O00OOO0000OO0 ,'addon.xml')#line:1196
	if os .path .exists (OOO0OOO0OOOOOOOOO ):#line:1197
		O0000OO000O00O0O0 =open (OOO0OOO0OOOOOOOOO ,mode ='r');O0O000O0O0OO0O00O =O0000OO000O00O0O0 .read ();O0000OO000O00O0O0 .close ();#line:1198
		OOO00OOOOO000OO0O =wiz .parseDOM (O0O000O0O0OO0O00O ,'import',ret ='addon')#line:1199
		for OOOOO0OO0O0O00O00 in OOO00OOOOO000OO0O :#line:1200
			if not 'xbmc.python'in OOOOO0OO0O0O00O00 :#line:1201
				if not DP ==None :#line:1202
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOOO0OO0O0O00O00 ))#line:1203
				try :#line:1204
					OOOO0OOO0O0O00000 =xbmcaddon .Addon (id =OOOOO0OO0O0O00O00 )#line:1205
					OO0OO0O00000O0O0O =OOOO0OOO0O0O00000 .getAddonInfo ('name')#line:1206
				except :#line:1207
					wiz .createTemp (OOOOO0OO0O0O00O00 )#line:1208
					if KODIV >=17 :wiz .addonDatabase (OOOOO0OO0O0O00O00 ,1 )#line:1209
def installed (OO00OOOOO0O0O000O ):#line:1210
	O000OOOOO0O00OO0O =os .path .join (ADDONS ,OO00OOOOO0O0O000O ,'addon.xml')#line:1211
	if os .path .exists (O000OOOOO0O00OO0O ):#line:1212
		try :#line:1213
			OO000O0OO00OO0O00 =open (O000OOOOO0O00OO0O ,mode ='r');O0OOOO000O000O000 =OO000O0OO00OO0O00 .read ();OO000O0OO00OO0O00 .close ()#line:1214
			O0O0OO00000O00OOO =wiz .parseDOM (O0OOOO000O000O000 ,'addon',ret ='name',attrs ={'id':OO00OOOOO0O0O000O })#line:1215
			OOO0O0000O000O0O0 =os .path .join (ADDONS ,OO00OOOOO0O0O000O ,'icon.png')#line:1216
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O0OO00000O00OOO [0 ]),'[COLOR %s]Addon Enabled[/COLOR]'%COLOR2 ,'2000',OOO0O0000O000O0O0 )#line:1217
		except :pass #line:1218
def youtubeMenu (name =None ,url =None ):#line:1219
	if not YOUTUBEFILE =='http://':#line:1220
		if url ==None :#line:1221
			OO0O0OOOOO0000OOO =wiz .textCache (uservar .YOUTUBEFILE )#line:1222
			if OO0O0OOOOO0000OOO ==False :O00O0O000OO0O0000 =wiz .workingURL (uservar .YOUTUBEFILE )#line:1223
		else :#line:1224
			OO0O0OOOOO0000OOO =wiz .textCache (url )#line:1225
			if OO0O0OOOOO0000OOO ==False :O00O0O000OO0O0000 =wiz .workingURL (url )#line:1226
		if not OO0O0OOOOO0000OOO ==False :#line:1227
			OO00O0O00O0OO0O0O =OO0O0OOOOO0000OOO .replace ('\n','').replace ('\r','').replace ('\t','')#line:1228
			OOOO0O0000OO000O0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO00O0O00O0OO0O0O )#line:1229
			if len (OOOO0O0000OO000O0 )>0 :#line:1230
				for name ,url ,O00O0O00OO00O00O0 ,O0OO00O0O00O0OOOO ,OO00O0O00OOO0O00O in OOOO0O0000OO000O0 :#line:1231
					addFile (name ,'viewVideo',url =url ,description =OO00O0O00OOO0O00O ,icon =O00O0O00OO00O00O0 ,fanart =O0OO00O0O00O0OOOO ,themeit =THEME2 )#line:1232
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:1233
		else :#line:1234
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:1235
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:1236
			addFile ('%s'%O00O0O000OO0O0000 ,'',themeit =THEME3 )#line:1237
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:1238
	setView ('files','viewType')#line:1239
def maintMenu (view =None ):#line:1240
	O0O000O0OO0O000O0 ='[B][COLOR green]ON[/COLOR][/B]';OOO0O0O00OO0O0OOO ='[B][COLOR red]OFF[/COLOR][/B]'#line:1241
	if wiz .Grab_Log (True )==False :OOOOOOOO000O0O000 =0 #line:1242
	else :OOOOOOOO000O0O000 =errorChecking (wiz .Grab_Log (True ),True )#line:1243
	if wiz .Grab_Log (True ,True )==False :OO0OO0O0OOOOOO000 =0 #line:1244
	else :OO0OO0O0OOOOOO000 =errorChecking (wiz .Grab_Log (True ,True ),True )#line:1245
	O0OOOOO00OO0OO000 =int (OOOOOOOO000O0O000 )+int (OO0OO0O0OOOOOO000 )#line:1246
	O00OO0OOO0OOO0OO0 =': [COLOR red]לא נמצא[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:1247
	OO000000OO00O0O0O =wiz .getSize (PACKAGES )#line:1248
	O0OOOO0O00O0O0OOO =wiz .getSize (THUMBS )#line:1249
	OOO0O0OOO000000OO =wiz .getCacheSize ()#line:1250
	OO0O00O000O00O0OO =OO000000OO00O0O0O +O0OOOO0O00O0O0OOO +OOO0O0OOO000000OO #line:1251
	addFile ('Total Clean Up: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO0O00O000O00O0OO ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:1252
	addFile ('Clear Cache: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO0O0OOO000000OO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:1253
	addFile ('Clear Packages: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OO000000OO00O0O0O ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:1254
	addFile ('Clear Thumbnails: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0OOOO0O00O0O0OOO ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:1255
	addFile ('Clear Old Thumbnails','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:1256
	addFile ('Clear Crash Logs','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:1257
	addFile ('Purge Databases','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:1258
	addDir ('[B]Back up/Restore[/B]','backup',icon =ICONMAINT ,themeit =THEME1 )#line:1259
	addDir ('[B]Advanced Settings Tool[/B]','autoconfig',icon =ICONMAINT ,themeit =THEME1 )#line:1260
	addDir ('[B]Addon Tools[/B]','addon',icon =ICONMAINT ,themeit =THEME1 )#line:1261
	addDir ('[B]Misc Maintenance[/B]','misc',icon =ICONMAINT ,themeit =THEME1 )#line:1262
	addDir ('[B]System Tweaks/Fixes[/B]','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:1263
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1264
	addFile ('!!!>>Fresh Start<<!!!','freshstart',icon =ICONMAINT ,themeit =THEME6 )#line:1265
def backup ():#line:1266
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','בדיקת מהירןת',icon =ICONMAINT ,themeit =THEME3 )#line:1267
		if HIDESPACERS =='No':addFile (wiz .sep ('Backup'),'',themeit =THEME1 )#line:1268
		addFile ('[Back Up]: Build','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:1269
		addFile ('[Back Up]: GuiFix','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:1270
		addFile ('[Back Up]: Theme','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:1271
		addFile ('[Back Up]: Addon Pack','backupaddonpack',icon =ICONMAINT ,themeit =THEME3 )#line:1272
		addFile ('[Back Up]: Addon_data','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:1273
		if HIDESPACERS =='No':addFile (wiz .sep ('Restore'),'',themeit =THEME1 )#line:1274
		addFile ('[Restore]: Local Build','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:1275
		addFile ('[Restore]: Local GuiFix','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:1276
		addFile ('[Restore]: Local Addon_data','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:1277
		addFile ('[Restore]: External Build','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:1278
		addFile ('[Restore]: External GuiFix','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:1279
		addFile ('[Restore]: External Addon_data','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:1280
		if HIDESPACERS =='No':addFile (wiz .sep ('Delete All Backups'),'',themeit =THEME1 )#line:1281
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:1282
def addon ():#line:1283
		addFile ('Remove Addons','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:1284
		addDir ('Remove Addon Data','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:1285
		addDir ('Enable/Disable Addons','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:1286
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:1287
		addFile ('Force Update Addons','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:1288
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:1289
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:1290
def misc ():#line:1291
		O0OOO000000O0O00O =int (errorChecking (count =True ))#line:1292
		O000O00000OOO0OO0 =str (O0OOO000000O0O00O )#line:1293
		O0O00O0O0OOO0OO0O ='[COLOR red]%s[/COLOR] Error(s) נמצא/ו'%(O000O00000OOO0OO0 )if O0OOO000000O0O00O >0 else 'אין שגיאות'#line:1294
		OO000000O000OO0O0 =': [COLOR red]לא נמצא[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:1295
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:1296
		addDir ('Speed Test','speedtest',icon =ICONMAINT ,themeit =THEME3 )#line:1297
		addFile ('Enable Unknown Sources','unknownsources',icon =ICONMAINT ,themeit =THEME3 )#line:1298
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:1299
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:1300
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:1301
		addFile ('Upload Log File','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:1302
		addFile ('View Errors in Log: %s'%(O0O00O0O0OOO0OO0O ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:1303
		if O0OOO000000O0O00O >0 :addFile ('View Last Error In Log','viewerrorlast',icon =ICONMAINT ,themeit =THEME3 )#line:1304
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:1305
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:1306
		addFile ('Clear Wizard Log File%s'%OO000000O000OO0O0 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:1307
def autoconfig ():#line:1308
	return 
	if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:1309
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:1310
	else :#line:1311
		if os .path .exists (ADVANCED ):#line:1312
			addFile ('View Current AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:1313
			addFile ('Remove Current AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:1314
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:1315
		addFile ('Full Configure AdvancedSettings.xml','autoadvanced1',icon =ICONMAINT ,themeit =THEME3 )#line:1316
def tweaks ():#line:1317
	O00O0000O00O00OOO ='[B][COLOR green]ON[/COLOR][/B]';OOOOO0000OO0OO0OO ='[B][COLOR red]OFF[/COLOR][/B]'#line:1318
	OOOO000O0OO000000 ='true'if AUTOCLEANUP =='true'else 'false'#line:1319
	O00O0OOOOOOO0O00O ='true'if AUTOCACHE =='true'else 'false'#line:1320
	O0OOOO0O0O0O0000O ='true'if AUTOPACKAGES =='true'else 'false'#line:1321
	OOO0O0O000OOOOOOO ='true'if AUTOTHUMBS =='true'else 'false'#line:1322
	OOO000OOO00OOO000 ='true'if SHOWMAINT =='true'else 'false'#line:1323
	O0O00OOO00OO000OO ='true'if INCLUDEVIDEO =='true'else 'false'#line:1324
	OO0OOOOO0O0O0OOO0 ='true'if INCLUDEALL =='true'else 'false'#line:1325
	OO0OOOOOOO0OO000O ='true'if THIRDPARTY =='true'else 'false'#line:1326
	addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME1 )#line:1327
	addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:1328
	addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:1329
	addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:1330
	addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:1331
	addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:1332
	addFile ('Third Party Wizards: %s'%OO0OOOOOOO0OO000O .replace ('true',O00O0000O00O00OOO ).replace ('false',OOOOO0000OO0OO0OO ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:1333
	if OO0OOOOOOO0OO000O =='true':#line:1334
		O0O0OO0O0O0OO0O00 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:1335
		O0OO00OO00000O00O =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:1336
		OO0OOO0OO0OO0000O =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:1337
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0O0OO0O0O0OO0O00 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:1338
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O0OO00OO00000O00O ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:1339
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OO0OOO0OO0OO0000O ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:1340
def net_tools (view =None ):#line:1341
	addDir ('Speed Tester','speedtest',icon =ICONAPK ,themeit =THEME1 )#line:1342
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1343
	addDir ('View IP Address & MAC Address','viewIP',icon =ICONMAINT ,themeit =THEME1 )#line:1344
	setView ('files','viewType')#line:1345
def viewIP ():#line:1346
	OO0O00O00O000OO0O =['Network.IPAddress','Network.MacAddress',]#line:1348
	O0O000O0OOO0OOOO0 =[];OOO0O0O00OO0OOOO0 =0 #line:1349
	for OO00OO00O000000O0 in OO0O00O00O000OO0O :#line:1350
		O000000O0O0OOO0O0 =wiz .getInfo (OO00OO00O000000O0 )#line:1351
		OO000OOOOOO0000O0 =0 #line:1352
		while O000000O0O0OOO0O0 =="Busy"and OO000OOOOOO0000O0 <10 :#line:1353
			O000000O0O0OOO0O0 =wiz .getInfo (OO00OO00O000000O0 );OO000OOOOOO0000O0 +=1 ;wiz .log ("%s sleep %s"%(OO00OO00O000000O0 ,str (OO000OOOOOO0000O0 )));xbmc .sleep (200 )#line:1354
		O0O000O0OOO0OOOO0 .append (O000000O0O0OOO0O0 )#line:1355
		OOO0O0O00OO0OOOO0 +=1 #line:1356
		OOOO0OOOO00OO0000 =wiz .getConfig ()#line:1357
		OO0O00OOO0OO0O0OO ='%(ip)s'%OOOO0OOOO00OO0000 ['client']#line:1358
		O000OOO00OOOOOO0O ='%(isp)s'%OOOO0OOOO00OO0000 ['client']#line:1359
		OO00OO000OOOO0000 ='%(country)s'%OOOO0OOOO00OO0000 ['client']#line:1360
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O0OOO0OOOO0 [0 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1361
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O00OOO0OO0O0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1362
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOO00OOOOOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1363
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO000OOOO0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1364
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O000O0OOO0OOOO0 [1 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1365
def speedTest ():#line:1366
	addFile ('Run Speed Test','speed',icon =ICONMAINT ,themeit =THEME3 )#line:1367
	if os .path .exists (SPEEDTESTFOLD ):#line:1368
		OOO00O0O000000OO0 =glob .glob (os .path .join (SPEEDTESTFOLD ,'*.png'))#line:1369
		OOO00O0O000000OO0 .sort (key =lambda O0OOOOO000OO0OOO0 :os .path .getmtime (O0OOOOO000OO0OOO0 ),reverse =True )#line:1370
		if len (OOO00O0O000000OO0 )>0 :#line:1371
			addFile ('Clear Results','clearspeedtest',icon =ICONMAINT ,themeit =THEME3 )#line:1372
			addFile (wiz .sep ('Previous Runs'),'',icon =ICONMAINT ,themeit =THEME3 )#line:1373
			for O0000OOOOOO0000O0 in OOO00O0O000000OO0 :#line:1374
				O000O0OO000OOOO00 =datetime .fromtimestamp (os .path .getmtime (O0000OOOOOO0000O0 )).strftime ('%m/%d/%Y %H:%M:%S')#line:1375
				O0O0O0000OO0O000O =O0000OOOOOO0000O0 .replace (os .path .join (SPEEDTESTFOLD ,''),'')#line:1376
				addFile ('[B]%s[/B]: [I]Ran %s[/I]'%(O0O0O0000OO0O000O ,O000O0OO000OOOO00 ),'viewspeedtest',O0O0O0000OO0O000O ,icon =ICONMAINT ,themeit =THEME3 )#line:1377
def clearSpeedTest ():#line:1378
	OOOOO0O000O0O0OOO =glob .glob (os .path .join (SPEEDTESTFOLD ,'*.png'))#line:1379
	for O00O0OOOO0000OO0O in OOOOO0O000O0O0OOO :#line:1380
		wiz .removeFile (O00O0OOOO0000OO0O )#line:1381
def viewSpeedTest (img =None ):#line:1382
	img =os .path .join (SPEEDTESTFOLD ,img )#line:1383
	notify .speedTest (img )#line:1384
def speed ():#line:1385
	try :#line:1386
		OOO00O0OO0O000O0O =speedtest .speedtest ()#line:1387
		if not os .path .exists (SPEEDTESTFOLD ):os .makedirs (SPEEDTESTFOLD )#line:1388
		O0OOO0OO00O0OO0OO =OOO00O0OO0O000O0O [0 ].split ('/')#line:1389
		O0OOO0000OO00O0O0 =os .path .join (SPEEDTESTFOLD ,O0OOO0OO00O0OO0OO [-1 ])#line:1390
		urllib .urlretrieve (OOO00O0OO0O000O0O [0 ],O0OOO0000OO00O0O0 )#line:1391
		viewSpeedTest (O0OOO0OO00O0OO0OO [-1 ])#line:1392
	except :#line:1393
		wiz .log ("[Speed Test] Error Running Speed Test")#line:1394
		pass #line:1395
def advancedWindow (url =None ):#line:1396
	if not ADVANCEDFILE =='http://':#line:1397
		if url ==None :#line:1398
			O0OO0O00O0OOOOO0O =wiz .textCache (uservar .ADVANCEDFILE )#line:1399
			if O0OO0O00O0OOOOO0O ==False :OOOO000O00O00OOOO =wiz .workingURL (uservar .ADVANCEDFILE )#line:1400
		else :#line:1401
			O0OO0O00O0OOOOO0O =wiz .textCache (url )#line:1402
			if O0OO0O00O0OOOOO0O ==False :OOOO000O00O00OOOO =wiz .workingURL (url )#line:1403
		addFile ('Configure AdvancedSettings.xml','autoadvanced1',icon =ICONMAINT ,themeit =THEME3 )#line:1404
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:1405
		if os .path .exists (ADVANCED ):#line:1406
			addFile ('View Current AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:1407
			addFile ('Remove Current AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:1408
		if not O0OO0O00O0OOOOO0O ==False :#line:1409
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:1410
			O0OOOO0O0O00OO00O =O0OO0O00O0OOOOO0O .replace ('\n','').replace ('\r','').replace ('\t','')#line:1411
			O0OOOOO0OO0O0O0O0 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OOOO0O0O00OO00O )#line:1412
			if len (O0OOOOO0OO0O0O0O0 )>0 :#line:1413
				for O0O0OO00OO0000OOO ,O00OOOOOOOO0O0OOO ,url ,OOO0OOO0OOOO0000O ,OOOOOO0O0OO00O0OO ,OO0OO0OO00OO00O00 in O0OOOOO0OO0O0O0O0 :#line:1414
					if O00OOOOOOOO0O0OOO .lower ()=="yes":#line:1415
						addDir ("[B]%s[/B]"%O0O0OO00OO0000OOO ,'advancedsetting',url ,description =OO0OO0OO00OO00O00 ,icon =OOO0OOO0OOOO0000O ,fanart =OOOOOO0O0OO00O0OO ,themeit =THEME3 )#line:1416
					else :#line:1417
						addFile (O0O0OO00OO0000OOO ,'writeadvanced',O0O0OO00OO0000OOO ,url ,description =OO0OO0OO00OO00O00 ,icon =OOO0OOO0OOOO0000O ,fanart =OOOOOO0O0OO00O0OO ,themeit =THEME2 )#line:1418
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:1419
		else :wiz .log ("[Advanced Settings] URL not working: %s"%OOOO000O00O00OOOO )#line:1420
	else :wiz .log ("[Advanced Settings] not Enabled")#line:1421
def writeAdvanced (O0OO0O000O0OOO0OO ,O000000OOOO0000O0 ):#line:1422
	O0O0OOOO000O0OO0O =wiz .workingURL (O000000OOOO0000O0 )#line:1423
	if O0O0OOOO000O0OO0O ==True :#line:1424
		if os .path .exists (ADVANCED ):O00OO0OO000000OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם ברצונך לשכתב הגדרות אלו במקום אלו הקיימות?  [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0OO0O000O0OOO0OO ),yeslabel ="[B][COLOR green]שכתב[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:1425
		else :O00OO0OO000000OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to download and install [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O0OO0O000O0OOO0OO ),yeslabel ="[B][COLOR green]Install[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:1426
		if O00OO0OO000000OOO ==1 :#line:1427
			O00000OOOOO0OOOOO =wiz .openURL (O000000OOOO0000O0 )#line:1428
			OO000OOOOO0O000O0 =open (ADVANCED ,'w');#line:1429
			OO000OOOOO0O000O0 .write (O00000OOOOO0OOOOO )#line:1430
			OO000OOOOO0O000O0 .close ()#line:1431
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml הקובת שוכתב בהצלחה, לאחר שתאשר תוכנת הקודי תסגר[/COLOR]'%COLOR2 )#line:1432
			wiz .killxbmc (True )#line:1433
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]כתיבה בוטלה![/COLOR]"%COLOR2 );return #line:1434
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0O0OOOO000O0OO0O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]הקישור אינו תקין[/COLOR]"%COLOR2 )#line:1435
def viewAdvanced ():#line:1436
	if os .path .exists (ADVANCED ):#line:1437
		O0O0OO0O00OOOO0O0 =open (ADVANCED )#line:1438
		O0O0OOOO00O0OOOOO =O0O0OO0O00OOOO0O0 .read ().replace ('\t','    ')#line:1439
		wiz .TextBox (ADDONTITLE ,O0O0OOOO00O0OOOOO )#line:1440
		O0O0OO0O00OOOO0O0 .close ()#line:1441
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml לא נמצא[/COLOR]")#line:1442
def removeAdvanced ():#line:1443
	if os .path .exists (ADVANCED ):#line:1444
		wiz .removeFile (ADVANCED )#line:1445
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml לא נמצא[/COLOR]")#line:1446
def showAutoAdvanced ():#line:1447
	notify .autoConfig2 ()#line:1448
def showAutoAdvanced1 ():#line:1449
	notify .autoConfig ()#line:1450
def getIP ():#line:1451
		OO00OO000000OO0OO =wiz .getConfig ()#line:1452
		OOO0000O00000O0O0 ='%(ip)s'%OO00OO000000OO0OO ['client']#line:1453
		OOO000OOO0OOOO0O0 ='%(isp)s'%OO00OO000000OO0OO ['client']#line:1454
		O0000OOOO0O000O00 ='%(country)s]'%OO00OO000000OO0OO ['client']#line:1455
		return OOO0000O00000O0O0 ,OOO000OOO0OOOO0O0 ,O0000OOOO0O000O00 #line:1456
def systemInfo ():#line:1457
	OO000O0OOO0O00O0O =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1471
	OO0O0000OO000O000 =[];OO00000O00OO000O0 =0 #line:1472
	for OO00OO00OO0OO0O0O in OO000O0OOO0O00O0O :#line:1473
		O0000OO0O000O0O00 =wiz .getInfo (OO00OO00OO0OO0O0O )#line:1474
		O0OOOOOO00O00OO00 =0 #line:1475
		while O0000OO0O000O0O00 =="Busy"and O0OOOOOO00O00OO00 <10 :#line:1476
			O0000OO0O000O0O00 =wiz .getInfo (OO00OO00OO0OO0O0O );O0OOOOOO00O00OO00 +=1 ;wiz .log ("%s sleep %s"%(OO00OO00OO0OO0O0O ,str (O0OOOOOO00O00OO00 )));xbmc .sleep (200 )#line:1477
		OO0O0000OO000O000 .append (O0000OO0O000O0O00 )#line:1478
		OO00000O00OO000O0 +=1 #line:1479
	O00OOO0O00OO0O000 =OO0O0000OO000O000 [8 ]if 'Una'in OO0O0000OO000O000 [8 ]else wiz .convertSize (int (float (OO0O0000OO000O000 [8 ][:-8 ]))*1024 *1024 )#line:1480
	O0000OOO00000O0O0 =OO0O0000OO000O000 [9 ]if 'Una'in OO0O0000OO000O000 [9 ]else wiz .convertSize (int (float (OO0O0000OO000O000 [9 ][:-8 ]))*1024 *1024 )#line:1481
	OOO0OOO0O000O0OOO =OO0O0000OO000O000 [10 ]if 'Una'in OO0O0000OO000O000 [10 ]else wiz .convertSize (int (float (OO0O0000OO000O000 [10 ][:-8 ]))*1024 *1024 )#line:1482
	OOO00OOOOO00O0000 =wiz .convertSize (int (float (OO0O0000OO000O000 [11 ][:-2 ]))*1024 *1024 )#line:1483
	OOO00OO0000OOO000 =wiz .convertSize (int (float (OO0O0000OO000O000 [12 ][:-2 ]))*1024 *1024 )#line:1484
	OOO0OO00O0OO00OOO =wiz .convertSize (int (float (OO0O0000OO000O000 [13 ][:-2 ]))*1024 *1024 )#line:1485
	O0OO0OOOOOOOO0O00 ,OOO0O00O0O0OO0OOO ,OO0000OOO00O0OOOO =getIP ()#line:1486
	O00O00O000O0O0000 =[];OOO0000O0O0OO0O0O =[];O0OOOOO0O00O0O000 =[];O00OO00OOOOO0000O =[];O00OOOO000O00OO00 =[];O000000O0O0O000O0 =[];O0O0O00OO00000O00 =[]#line:1487
	O00O00O0O00O00OO0 =glob .glob (os .path .join (ADDONS ,'*/'))#line:1488
	for O000000O0O000OOO0 in sorted (O00O00O0O00O00OO0 ,key =lambda OOOOOO000OOOO0OO0 :OOOOOO000OOOO0OO0 ):#line:1489
		O0OOOOO000O000O00 =os .path .split (O000000O0O000OOO0 [:-1 ])[1 ]#line:1490
		if O0OOOOO000O000O00 =='packages':continue #line:1491
		O0OO0O000000OO0O0 =os .path .join (O000000O0O000OOO0 ,'addon.xml')#line:1492
		if os .path .exists (O0OO0O000000OO0O0 ):#line:1493
			O000OO0O000OO000O =open (O0OO0O000000OO0O0 )#line:1494
			OO00OO0OO00O0OOOO =O000OO0O000OO000O .read ()#line:1495
			OOOO0000OO00O0OO0 =re .compile ("<provides>(.+?)</provides>").findall (OO00OO0OO00O0OOOO )#line:1496
			if len (OOOO0000OO00O0OO0 )==0 :#line:1497
				if O0OOOOO000O000O00 .startswith ('skin'):O0O0O00OO00000O00 .append (O0OOOOO000O000O00 )#line:1498
				elif O0OOOOO000O000O00 .startswith ('repo'):O00OOOO000O00OO00 .append (O0OOOOO000O000O00 )#line:1499
				else :O000000O0O0O000O0 .append (O0OOOOO000O000O00 )#line:1500
			elif not (OOOO0000OO00O0OO0 [0 ]).find ('executable')==-1 :O00OO00OOOOO0000O .append (O0OOOOO000O000O00 )#line:1501
			elif not (OOOO0000OO00O0OO0 [0 ]).find ('video')==-1 :O0OOOOO0O00O0O000 .append (O0OOOOO000O000O00 )#line:1502
			elif not (OOOO0000OO00O0OO0 [0 ]).find ('audio')==-1 :OOO0000O0O0OO0O0O .append (O0OOOOO000O000O00 )#line:1503
			elif not (OOOO0000OO00O0OO0 [0 ]).find ('image')==-1 :O00O00O000O0O0000 .append (O0OOOOO000O000O00 )#line:1504
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1505
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0000OO000O000 [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:1506
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0000OO000O000 [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:1507
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:1508
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0000OO000O000 [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:1509
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0000OO000O000 [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:1510
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1511
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0000OO000O000 [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1512
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0000OO000O000 [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1513
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1514
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOO0O00OO0O000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1515
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0000OOO00000O0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1516
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OOO0O000O0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1517
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1518
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OOOOO00O0000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1519
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO00OO0000OOO000 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1520
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0OO00O0OO00OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1521
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1522
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0000OO000O000 [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1523
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OO0OOOOOOOO0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1524
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0O00O0O0OO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1525
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0000OOO00O0OOOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1526
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0O0000OO000O000 [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1527
	O0O0O0O0OOO000O00 =len (O00O00O000O0O0000 )+len (OOO0000O0O0OO0O0O )+len (O0OOOOO0O00O0O000 )+len (O00OO00OOOOO0000O )+len (O000000O0O0O000O0 )+len (O0O0O00OO00000O00 )+len (O00OOOO000O00OO00 )#line:1528
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,O0O0O0O0OOO000O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1529
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0OOOOO0O00O0O000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1530
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OO00OOOOO0000O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1531
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OOO0000O0O0OO0O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1532
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00O00O000O0O0000 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1533
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O00OOOO000O00OO00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1534
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O0O0O00OO00000O00 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1535
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000000O0O0O000O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1536
def saveMenu ():#line:1537
	O0OO0OOOO00OOOO00 ='[COLOR green]ON[/COLOR]';O0O00000OO0OO00O0 ='[COLOR red]OFF[/COLOR]'#line:1538
	O0000O0OOO0OOOO0O ='true'if KEEPTRAKT =='true'else 'false'#line:1539
	OO0OOO0O00O00OOOO ='true'if KEEPALLUC =='true'else 'false'#line:1540
	O0OO000O0000OO0OO ='true'if KEEPREAL =='true'else 'false'#line:1541
	O0O00000OO0O0OO0O ='true'if KEEPLOGIN =='true'else 'false'#line:1542
	OOOO0000O0O0OO0O0 ='true'if KEEPSOURCES =='true'else 'false'#line:1543
	O0O0OO0O0000O00O0 ='true'if KEEPADVANCED =='true'else 'false'#line:1544
	OO0O0O000OOO0O00O ='true'if KEEPPROFILES =='true'else 'false'#line:1545
	O0OOOOOO0OOOOO0OO ='true'if KEEPFAVS =='true'else 'false'#line:1546
	O0OOO0OOOOO00OOO0 ='true'if KEEPREPOS =='true'else 'false'#line:1547
	OO0O0000OO00O0O0O ='true'if KEEPSUPER =='true'else 'false'#line:1548
	O0OOO0O0OO0O0O000 ='true'if KEEPWHITELIST =='true'else 'false'#line:1549
	addFile ('Keep My \'WhiteList\': %s'%O0OOO0O0OO0O0O000 .replace ('true',O0OO0OOOO00OOOO00 ).replace ('false',O0O00000OO0OO00O0 ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:1550
	if O0OOO0O0OO0O0O000 =='true':#line:1551
		addFile ('    Edit My Whitelist','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:1552
		addFile ('    View My Whitelist','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:1553
		addFile ('    Clear My Whitelist','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:1554
		addFile ('    Import My Whitelist','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:1555
		addFile ('    Export My Whitelist','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:1556
	addDir ('Keep Favourites','FavsMenu',icon =ICONREAL ,themeit =THEME1 )#line:1557
	addDir ('Keep Trakt Data','trakt',icon =ICONTRAKT ,themeit =THEME1 )#line:1558
	addDir ('Keep Real Debrid','realdebrid',icon =ICONREAL ,themeit =THEME1 )#line:1559
	addDir ('Keep Alluc Login','alluc',icon =ICONLOGIN ,themeit =THEME1 )#line:1560
	addDir ('Keep Login Info','login',icon =ICONLOGIN ,themeit =THEME1 )#line:1561
	addFile ('Import Save Data','managedata','import',icon =ICONSAVE ,themeit =THEME1 )#line:1562
	addFile ('Export Save Data','managedata','export',icon =ICONSAVE ,themeit =THEME1 )#line:1563
	addFile ('- Click to toggle settings -','',themeit =THEME3 )#line:1564
	addFile ('Save Trakt: %s'%O0000O0OOO0OOOO0O .replace ('true',O0OO0OOOO00OOOO00 ).replace ('false',O0O00000OO0OO00O0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:1565
	addFile ('Save Real Debrid: %s'%O0OO000O0000OO0OO .replace ('true',O0OO0OOOO00OOOO00 ).replace ('false',O0O00000OO0OO00O0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:1566
	addFile ('Save Alluc Login: %s'%OO0OOO0O00O00OOOO .replace ('true',O0OO0OOOO00OOOO00 ).replace ('false',O0O00000OO0OO00O0 ),'togglesetting','keepalluc',icon =ICONREAL ,themeit =THEME1 )#line:1567
	addFile ('Save Login Info: %s'%O0O00000OO0O0OO0O .replace ('true',O0OO0OOOO00OOOO00 ).replace ('false',O0O00000OO0OO00O0 ),'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME1 )#line:1568
	addFile ('Keep \'Profiles.xml\': %s'%OO0O0O000OOO0O00O .replace ('true',O0OO0OOOO00OOOO00 ).replace ('false',O0O00000OO0OO00O0 ),'togglesetting','keepprofiles',icon =ICONSAVE ,themeit =THEME1 )#line:1570
	addFile ('Keep \'Advancedsettings.xml\': %s'%O0O0OO0O0000O00O0 .replace ('true',O0OO0OOOO00OOOO00 ).replace ('false',O0O00000OO0OO00O0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:1571
	addFile ('Keep \'Favourites.xml\': %s'%O0OOOOOO0OOOOO0OO .replace ('true',O0OO0OOOO00OOOO00 ).replace ('false',O0O00000OO0OO00O0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:1572
	addFile ('Keep Super Favourites: %s'%OO0O0000OO00O0O0O .replace ('true',O0OO0OOOO00OOOO00 ).replace ('false',O0O00000OO0OO00O0 ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:1573
	addFile ('Keep Installed Repo\'s: %s'%O0OOO0OOOOO00OOO0 .replace ('true',O0OO0OOOO00OOOO00 ).replace ('false',O0O00000OO0OO00O0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:1574
	setView ('files','viewType')#line:1575
def FavsMenu ():#line:1576
	O0O0OO0O000O000O0 ='[COLOR green]ON[/COLOR]';O0O0000O00OO00OOO ='[COLOR red]OFF[/COLOR]'#line:1577
	O0O000O0O0OO0O0O0 ='[COLOR green]ON[/COLOR]'if KEEPFAVS =='true'else '[COLOR red]OFF[/COLOR]'#line:1578
	OOO0000000O0OOO00 =str (FAVSsave )if not FAVSsave ==''else 'Favourites hasnt been saved yet.'#line:1579
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1580
	addFile ('Save Favourites: %s'%O0O000O0O0OO0O0O0 ,'togglesetting','keepfavourites',icon =ICONTRAKT ,themeit =THEME3 )#line:1581
	if KEEPFAVS =='true':addFile ('Last Save: %s'%str (OOO0000000O0OOO00 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:1582
	if HIDESPACERS =='No':addFile (wiz .sep ('Backs up a copy'),'',themeit =THEME3 )#line:1583
	addFile ('Save Favourites','savefav',icon =ICONTRAKT ,themeit =THEME1 )#line:1584
	addFile ('Recover Favourites','restorefav',icon =ICONTRAKT ,themeit =THEME1 )#line:1585
	addFile ('Clear Favourite Backup','clearfav',icon =ICONTRAKT ,themeit =THEME1 )#line:1586
	setView ('files','viewType')#line:1587
def traktMenu ():#line:1588
	O0OO00000OOO0000O ='[COLOR green]ON[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]OFF[/COLOR]'#line:1589
	OO0O0000000O00OO0 =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:1590
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:1591
	addFile ('Save Trakt Data: %s'%O0OO00000OOO0000O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:1592
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO0O0000000O00OO0 ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:1593
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:1594
	for O0OO00000OOO0000O in traktit .ORDER :#line:1595
		O00OO00OOOOOO0000 =TRAKTID [O0OO00000OOO0000O ]['name']#line:1596
		OO0000OO0O00OO0OO =TRAKTID [O0OO00000OOO0000O ]['path']#line:1597
		OOO00OOO00OOO0OOO =TRAKTID [O0OO00000OOO0000O ]['saved']#line:1598
		O000O00OOOO0OOO00 =TRAKTID [O0OO00000OOO0000O ]['file']#line:1599
		OO0OOOOOOOO00OO00 =wiz .getS (OOO00OOO00OOO0OOO )#line:1600
		O00OOO00OOO0OOO00 =traktit .traktUser (O0OO00000OOO0000O )#line:1601
		OOOOO0O0O0OO0OOO0 =TRAKTID [O0OO00000OOO0000O ]['icon']if os .path .exists (OO0000OO0O00OO0OO )else ICONTRAKT #line:1602
		OOO0O0O0O0O000OOO =TRAKTID [O0OO00000OOO0000O ]['fanart']if os .path .exists (OO0000OO0O00OO0OO )else FANART #line:1603
		O00O000OO00000000 =createMenu ('saveaddon','Trakt',O0OO00000OOO0000O )#line:1604
		O000O0OO00000OO00 =createMenu ('save','Trakt',O0OO00000OOO0000O )#line:1605
		O00O000OO00000000 .append ((THEME2 %'%s Settings'%O00OO00OOOOOO0000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0OO00000OOO0000O )))#line:1606
		addFile ('[+]-> %s'%O00OO00OOOOOO0000 ,'',icon =OOOOO0O0O0OO0OOO0 ,fanart =OOO0O0O0O0O000OOO ,themeit =THEME3 )#line:1607
		if not os .path .exists (OO0000OO0O00OO0OO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOO0O0O0OO0OOO0 ,fanart =OOO0O0O0O0O000OOO ,menu =O00O000OO00000000 )#line:1608
		elif not O00OOO00OOO0OOO00 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0OO00000OOO0000O ,icon =OOOOO0O0O0OO0OOO0 ,fanart =OOO0O0O0O0O000OOO ,menu =O00O000OO00000000 )#line:1609
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O00OOO00OOO0OOO00 ,'authtrakt',O0OO00000OOO0000O ,icon =OOOOO0O0O0OO0OOO0 ,fanart =OOO0O0O0O0O000OOO ,menu =O00O000OO00000000 )#line:1610
		if OO0OOOOOOOO00OO00 =="":#line:1611
			if os .path .exists (O000O00OOOO0OOO00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0OO00000OOO0000O ,icon =OOOOO0O0O0OO0OOO0 ,fanart =OOO0O0O0O0O000OOO ,menu =O000O0OO00000OO00 )#line:1612
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0OO00000OOO0000O ,icon =OOOOO0O0O0OO0OOO0 ,fanart =OOO0O0O0O0O000OOO ,menu =O000O0OO00000OO00 )#line:1613
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO0OOOOOOOO00OO00 ,'',icon =OOOOO0O0O0OO0OOO0 ,fanart =OOO0O0O0O0O000OOO ,menu =O000O0OO00000OO00 )#line:1614
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1615
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1616
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1617
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1618
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1619
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1620
	setView ('files','viewType')#line:1621
def realMenu ():#line:1622
	OOOO0O0OO00OO0O0O ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:1623
	O00O0OO0OOOOOO0OO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:1624
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:1625
	addFile ('Save Real Debrid Data: %s'%OOOO0O0OO00OO0O0O ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:1626
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O00O0OO0OOOOOO0OO ),'',icon =ICONREAL ,themeit =THEME3 )#line:1627
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:1628
	for O0OOOO0O0O00O0OO0 in debridit .ORDER :#line:1629
		OO0OO0O00OOO0O000 =DEBRIDID [O0OOOO0O0O00O0OO0 ]['name']#line:1630
		OO0O00O00OO0000O0 =DEBRIDID [O0OOOO0O0O00O0OO0 ]['path']#line:1631
		O000OO0O0O0O0O000 =DEBRIDID [O0OOOO0O0O00O0OO0 ]['saved']#line:1632
		O00O0OOOO0000OO00 =DEBRIDID [O0OOOO0O0O00O0OO0 ]['file']#line:1633
		O0OOOO00O00000O0O =wiz .getS (O000OO0O0O0O0O000 )#line:1634
		OO00OO0OOO0OO00O0 =debridit .debridUser (O0OOOO0O0O00O0OO0 )#line:1635
		OOOOOOO00O00O0OO0 =DEBRIDID [O0OOOO0O0O00O0OO0 ]['icon']if os .path .exists (OO0O00O00OO0000O0 )else ICONREAL #line:1636
		O000O0O0OOOO0O00O =DEBRIDID [O0OOOO0O0O00O0OO0 ]['fanart']if os .path .exists (OO0O00O00OO0000O0 )else FANART #line:1637
		O00O00O0OOO0O00OO =createMenu ('saveaddon','Debrid',O0OOOO0O0O00O0OO0 )#line:1638
		O00O0O00O00OO0O00 =createMenu ('save','Debrid',O0OOOO0O0O00O0OO0 )#line:1639
		O00O00O0OOO0O00OO .append ((THEME2 %'%s Settings'%OO0OO0O00OOO0O000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0OOOO0O0O00O0OO0 )))#line:1640
		addFile ('[+]-> %s'%OO0OO0O00OOO0O000 ,'',icon =OOOOOOO00O00O0OO0 ,fanart =O000O0O0OOOO0O00O ,themeit =THEME3 )#line:1641
		if not os .path .exists (OO0O00O00OO0000O0 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOOOOOO00O00O0OO0 ,fanart =O000O0O0OOOO0O00O ,menu =O00O00O0OOO0O00OO )#line:1642
		elif not OO00OO0OOO0OO00O0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0OOOO0O0O00O0OO0 ,icon =OOOOOOO00O00O0OO0 ,fanart =O000O0O0OOOO0O00O ,menu =O00O00O0OOO0O00OO )#line:1643
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OO00OO0OOO0OO00O0 ,'authdebrid',O0OOOO0O0O00O0OO0 ,icon =OOOOOOO00O00O0OO0 ,fanart =O000O0O0OOOO0O00O ,menu =O00O00O0OOO0O00OO )#line:1644
		if O0OOOO00O00000O0O =="":#line:1645
			if os .path .exists (O00O0OOOO0000OO00 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0OOOO0O0O00O0OO0 ,icon =OOOOOOO00O00O0OO0 ,fanart =O000O0O0OOOO0O00O ,menu =O00O0O00O00OO0O00 )#line:1646
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0OOOO0O0O00O0OO0 ,icon =OOOOOOO00O00O0OO0 ,fanart =O000O0O0OOOO0O00O ,menu =O00O0O00O00OO0O00 )#line:1647
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0OOOO00O00000O0O ,'',icon =OOOOOOO00O00O0OO0 ,fanart =O000O0O0OOOO0O00O ,menu =O00O0O00O00OO0O00 )#line:1648
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1649
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1650
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1651
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1652
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1653
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1654
	setView ('files','viewType')#line:1655
def allucMenu ():#line:1656
	OO0000O0OO0O0O000 ='[COLOR green]ON[/COLOR]'if KEEPALLUC =='true'else '[COLOR red]OFF[/COLOR]'#line:1657
	OO00OO00OO0O0OOO0 =str (ALLUCSAVE )if not ALLUCSAVE ==''else 'Alluc Login hasnt been saved yet.'#line:1658
	addFile ('[I]http://accounts.alluc.com/ is a Free service.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:1659
	addFile ('Save Alluc Login Data: %s'%OO0000O0OO0O0O000 ,'togglesetting','keepalluc',icon =ICONLOGIN ,themeit =THEME3 )#line:1660
	if KEEPALLUC =='true':addFile ('Last Save: %s'%str (OO00OO00OO0O0OOO0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:1661
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:1662
	for OO0000O0OO0O0O000 in allucit .ORDER :#line:1663
		OOO00O0OOO0OOO000 =ALLUCID [OO0000O0OO0O0O000 ]['name']#line:1664
		O0000000O0O0O0000 =ALLUCID [OO0000O0OO0O0O000 ]['path']#line:1665
		O0OO00O000O0O00O0 =ALLUCID [OO0000O0OO0O0O000 ]['saved']#line:1666
		O000O000000OOOO0O =ALLUCID [OO0000O0OO0O0O000 ]['file']#line:1667
		OOOOO00O00O0OOOOO =wiz .getS (O0OO00O000O0O00O0 )#line:1668
		O0OOOO0O000OOOOO0 =allucit .allucUser (OO0000O0OO0O0O000 )#line:1669
		OO0OO00OO0O0O0OOO =ALLUCID [OO0000O0OO0O0O000 ]['icon']if os .path .exists (O0000000O0O0O0000 )else ICONLOGIN #line:1670
		OO0OOO0O0O00OO000 =ALLUCID [OO0000O0OO0O0O000 ]['fanart']if os .path .exists (O0000000O0O0O0000 )else FANART #line:1671
		O0OO000000OOOO0O0 =createMenu ('saveaddon','ALLUC',OO0000O0OO0O0O000 )#line:1672
		OOOO0O0O0000O0O00 =createMenu ('save','Alluc',OO0000O0OO0O0O000 )#line:1673
		O0OO000000OOOO0O0 .append ((THEME2 %'%s Settings'%OOO00O0OOO0OOO000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=alluc)'%(ADDON_ID ,OO0000O0OO0O0O000 )))#line:1674
		addFile ('[+]-> %s'%OOO00O0OOO0OOO000 ,'',icon =OO0OO00OO0O0O0OOO ,fanart =OO0OOO0O0O00OO000 ,themeit =THEME3 )#line:1675
		if not os .path .exists (O0000000O0O0O0000 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO0OO00OO0O0O0OOO ,fanart =OO0OOO0O0O00OO000 ,menu =O0OO000000OOOO0O0 )#line:1676
		elif not O0OOOO0O000OOOOO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authalluc',OO0000O0OO0O0O000 ,icon =OO0OO00OO0O0O0OOO ,fanart =OO0OOO0O0O00OO000 ,menu =O0OO000000OOOO0O0 )#line:1677
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OOOO0O000OOOOO0 ,'authalluc',OO0000O0OO0O0O000 ,icon =OO0OO00OO0O0O0OOO ,fanart =OO0OOO0O0O00OO000 ,menu =O0OO000000OOOO0O0 )#line:1678
		if OOOOO00O00O0OOOOO =="":#line:1679
			if os .path .exists (O000O000000OOOO0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importalluc',OO0000O0OO0O0O000 ,icon =OO0OO00OO0O0O0OOO ,fanart =OO0OOO0O0O00OO000 ,menu =OOOO0O0O0000O0O00 )#line:1680
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savealluc',OO0000O0OO0O0O000 ,icon =OO0OO00OO0O0O0OOO ,fanart =OO0OOO0O0O00OO000 ,menu =OOOO0O0O0000O0O00 )#line:1681
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OOOOO00O00O0OOOOO ,'',icon =OO0OO00OO0O0O0OOO ,fanart =OO0OOO0O0O00OO000 ,menu =OOOO0O0O0000O0O00 )#line:1682
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1683
	addFile ('Save All Alluc Login Data','savealluc','all',icon =ICONREAL ,themeit =THEME3 )#line:1684
	addFile ('Recover All Saved Alluc Login Data','restorealluc','all',icon =ICONREAL ,themeit =THEME3 )#line:1685
	addFile ('Import Alluc Login Data','importalluc','all',icon =ICONREAL ,themeit =THEME3 )#line:1686
	addFile ('Clear All Saved Alluc Login Data','clearalluc','all',icon =ICONREAL ,themeit =THEME3 )#line:1687
	addFile ('Clear All Addon Data','addonalluc','all',icon =ICONREAL ,themeit =THEME3 )#line:1688
	setView ('files','viewType')#line:1689
def loginMenu ():#line:1690
	OOOO00O000O000OO0 ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:1691
	O000O0OOO000OO0O0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:1692
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:1693
	addFile ('Save Login Data: %s'%OOOO00O000O000OO0 ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:1694
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (O000O0OOO000OO0O0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:1695
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:1696
	for OOOO00O000O000OO0 in loginit .ORDER :#line:1697
		O0O0OOOOOOOO0O000 =LOGINID [OOOO00O000O000OO0 ]['name']#line:1698
		O0O000OOOOO000O0O =LOGINID [OOOO00O000O000OO0 ]['path']#line:1699
		OOO0OO00OOO00OOO0 =LOGINID [OOOO00O000O000OO0 ]['saved']#line:1700
		O0O0O0O000O0O00O0 =LOGINID [OOOO00O000O000OO0 ]['file']#line:1701
		OO000O00O0OO000O0 =wiz .getS (OOO0OO00OOO00OOO0 )#line:1702
		O0O0OOO000OO0OO0O =loginit .loginUser (OOOO00O000O000OO0 )#line:1703
		O00O000O00OOO0OOO =LOGINID [OOOO00O000O000OO0 ]['icon']if os .path .exists (O0O000OOOOO000O0O )else ICONLOGIN #line:1704
		OOO0OO0O000O00O00 =LOGINID [OOOO00O000O000OO0 ]['fanart']if os .path .exists (O0O000OOOOO000O0O )else FANART #line:1705
		OOO00O0000O00O00O =createMenu ('saveaddon','Login',OOOO00O000O000OO0 )#line:1706
		OOOOO0OO0O00OOOOO =createMenu ('save','Login',OOOO00O000O000OO0 )#line:1707
		OOO00O0000O00O00O .append ((THEME2 %'%s Settings'%O0O0OOOOOOOO0O000 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOOO00O000O000OO0 )))#line:1708
		addFile ('[+]-> %s'%O0O0OOOOOOOO0O000 ,'',icon =O00O000O00OOO0OOO ,fanart =OOO0OO0O000O00O00 ,themeit =THEME3 )#line:1709
		if not os .path .exists (O0O000OOOOO000O0O ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00O000O00OOO0OOO ,fanart =OOO0OO0O000O00O00 ,menu =OOO00O0000O00O00O )#line:1710
		elif not O0O0OOO000OO0OO0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOOO00O000O000OO0 ,icon =O00O000O00OOO0OOO ,fanart =OOO0OO0O000O00O00 ,menu =OOO00O0000O00O00O )#line:1711
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0O0OOO000OO0OO0O ,'authlogin',OOOO00O000O000OO0 ,icon =O00O000O00OOO0OOO ,fanart =OOO0OO0O000O00O00 ,menu =OOO00O0000O00O00O )#line:1712
		if OO000O00O0OO000O0 =="":#line:1713
			if os .path .exists (O0O0O0O000O0O00O0 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOOO00O000O000OO0 ,icon =O00O000O00OOO0OOO ,fanart =OOO0OO0O000O00O00 ,menu =OOOOO0OO0O00OOOOO )#line:1714
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOOO00O000O000OO0 ,icon =O00O000O00OOO0OOO ,fanart =OOO0OO0O000O00O00 ,menu =OOOOO0OO0O00OOOOO )#line:1715
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%OO000O00O0OO000O0 ,'',icon =O00O000O00OOO0OOO ,fanart =OOO0OO0O000O00O00 ,menu =OOOOO0OO0O00OOOOO )#line:1716
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1717
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1718
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1719
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1720
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1721
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1722
	setView ('files','viewType')#line:1723
def fixUpdate ():#line:1724
	if KODIV <17 :#line:1725
		OO0O0O00O00O0OO0O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:1726
		try :#line:1727
			os .remove (OO0O0O00O00O0OO0O )#line:1728
		except Exception as O00000OOO0O000000 :#line:1729
			wiz .log ("Unable to remove %s, Purging DB"%OO0O0O00O00O0OO0O )#line:1730
			wiz .purgeDb (OO0O0O00O00O0OO0O )#line:1731
	else :#line:1732
		if os .path .exists (os .path .join (USERDATA ,'autoexec.py')):#line:1733
			O0OO00O00O00OOO0O =os .path .join (USERDATA ,'autoexec_temp.py')#line:1734
			if os .path .exists (O0OO00O00O00OOO0O ):xbmcvfs .delete (O0OO00O00O00OOO0O )#line:1735
			xbmcvfs .rename (os .path .join (USERDATA ,'autoexec.py'),O0OO00O00O00OOO0O )#line:1736
		xbmcvfs .copy (os .path .join (PLUGIN ,'resources','libs','autoexec.py'),os .path .join (USERDATA ,'autoexec.py'))#line:1737
		OO0O0O00O00O0OO0O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:1738
		try :#line:1739
			os .remove (OO0O0O00O00O0OO0O )#line:1740
		except Exception as O00000OOO0O000000 :#line:1741
			wiz .log ("Unable to remove %s, Purging DB"%OO0O0O00O00O0OO0O )#line:1742
			wiz .purgeDb (OO0O0O00O00O0OO0O )#line:1743
		wiz .killxbmc (True )#line:1744
def removeAddonMenu ():#line:1745
	OOO0O00000O00O0OO =glob .glob (os .path .join (ADDONS ,'*/'))#line:1746
	O00O0OO00OOO0OO0O =[];OO0OO0O00OO0000OO =[]#line:1747
	for O0OOO0O00OO0OOO0O in sorted (OOO0O00000O00O0OO ,key =lambda O0000OO0OO00OO0OO :O0000OO0OO00OO0OO ):#line:1748
		OOOOO000O00OOO0OO =os .path .split (O0OOO0O00OO0OOO0O [:-1 ])[1 ]#line:1749
		if OOOOO000O00OOO0OO in EXCLUDES :continue #line:1750
		elif OOOOO000O00OOO0OO in DEFAULTPLUGINS :continue #line:1751
		elif OOOOO000O00OOO0OO =='packages':continue #line:1752
		OOO00O00OOOOO0O00 =os .path .join (O0OOO0O00OO0OOO0O ,'addon.xml')#line:1753
		if os .path .exists (OOO00O00OOOOO0O00 ):#line:1754
			O0O0OOO00OO0OO0O0 =open (OOO00O00OOOOO0O00 )#line:1755
			OOO00O0O00OO00OO0 =O0O0OOO00OO0OO0O0 .read ()#line:1756
			O0OOOOOOOO0O0O0O0 =wiz .parseDOM (OOO00O0O00OO00OO0 ,'addon',ret ='id')#line:1757
			O0000O000O00OO0O0 =OOOOO000O00OOO0OO if len (O0OOOOOOOO0O0O0O0 )==0 else O0OOOOOOOO0O0O0O0 [0 ]#line:1758
			try :#line:1759
				OOOOO0OOO0OO0O0OO =xbmcaddon .Addon (id =O0000O000O00OO0O0 )#line:1760
				O00O0OO00OOO0OO0O .append (OOOOO0OOO0OO0O0OO .getAddonInfo ('name'))#line:1761
				OO0OO0O00OO0000OO .append (O0000O000O00OO0O0 )#line:1762
			except :#line:1763
				pass #line:1764
	if len (O00O0OO00OOO0OO0O )==0 :#line:1765
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין הרחבות להסרה[/COLOR]"%COLOR2 )#line:1766
		return #line:1767
	if KODIV >16 :#line:1768
		O000OOOOO00OO0O00 =DIALOG .multiselect ("%s: בחר את ההרחבות שברצונך להוריד"%ADDONTITLE ,O00O0OO00OOO0OO0O )#line:1769
	else :#line:1770
		O000OOOOO00OO0O00 =[];OO00OO00O00O0OOOO =0 #line:1771
		OOOO00O000O0O0000 =["-- לחץ כאן להמשך --"]+O00O0OO00OOO0OO0O #line:1772
		while not OO00OO00O00O0OOOO ==-1 :#line:1773
			OO00OO00O00O0OOOO =DIALOG .select ("%s: בחר את ההרחבות שברצונך להסיר"%ADDONTITLE ,OOOO00O000O0O0000 )#line:1774
			if OO00OO00O00O0OOOO ==-1 :break #line:1775
			elif OO00OO00O00O0OOOO ==0 :break #line:1776
			else :#line:1777
				OO0O00OO000O0OO00 =(OO00OO00O00O0OOOO -1 )#line:1778
				if OO0O00OO000O0OO00 in O000OOOOO00OO0O00 :#line:1779
					O000OOOOO00OO0O00 .remove (OO0O00OO000O0OO00 )#line:1780
					OOOO00O000O0O0000 [OO00OO00O00O0OOOO ]=O00O0OO00OOO0OO0O [OO0O00OO000O0OO00 ]#line:1781
				else :#line:1782
					O000OOOOO00OO0O00 .append (OO0O00OO000O0OO00 )#line:1783
					OOOO00O000O0O0000 [OO00OO00O00O0OOOO ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,O00O0OO00OOO0OO0O [OO0O00OO000O0OO00 ])#line:1784
	if O000OOOOO00OO0O00 ==None :return #line:1785
	if len (O000OOOOO00OO0O00 )>0 :#line:1786
		wiz .addonUpdates ('set')#line:1787
		for OOOOOO0000OOOO0OO in O000OOOOO00OO0O00 :#line:1788
			removeAddon (OO0OO0O00OO0000OO [OOOOOO0000OOOO0OO ],O00O0OO00OOO0OO0O [OOOOOO0000OOOO0OO ],True )#line:1789
		xbmc .sleep (500 )#line:1790
		if INSTALLMETHOD ==1 :O0O00OOOO00O0O0OO =1 #line:1791
		elif INSTALLMETHOD ==2 :O0O00OOOO00O0O0OO =0 #line:1792
		else :O0O00OOOO00O0O0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]פרופיל מחדש? [COLOR %s]לטעון [/COLOR] לסגור את הקודי או  [COLOR %s]האם ברצונך [/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),nolabel ="[B][COLOR red]סגור קודי[/COLOR][/B]")#line:1793
		if O0O00OOOO00O0O0OO ==1 :wiz .reloadFix ('remove addon')#line:1794
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:1795
def removeAddonDataMenu ():#line:1796
	if os .path .exists (ADDOND ):#line:1797
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:1798
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:1799
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:1800
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:1801
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1802
		O000OOO00000O00O0 =glob .glob (os .path .join (ADDOND ,'*/'))#line:1803
		for O0O00OOO0OO0O00OO in sorted (O000OOO00000O00O0 ,key =lambda O0O0O0O0O0O0OO0O0 :O0O0O0O0O0O0OO0O0 ):#line:1804
			OOO00OOO0000000OO =O0O00OOO0OO0O00OO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:1805
			OOOOO0O0OOO0OOOOO =os .path .join (O0O00OOO0OO0O00OO .replace (ADDOND ,ADDONS ),'icon.png')#line:1806
			O00OO0O00O00O0000 =os .path .join (O0O00OOO0OO0O00OO .replace (ADDOND ,ADDONS ),'fanart.png')#line:1807
			OO00OOOO000O0OOO0 =OOO00OOO0000000OO #line:1808
			O0OOO00000OO0OO0O ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:1809
			for O0OO00OO00OOO0O00 in O0OOO00000OO0OO0O :#line:1810
				OO00OOOO000O0OOO0 =OO00OOOO000O0OOO0 .replace (O0OO00OO00OOO0O00 ,O0OOO00000OO0OO0O [O0OO00OO00OOO0O00 ])#line:1811
			if OOO00OOO0000000OO in EXCLUDES :OO00OOOO000O0OOO0 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO00OOOO000O0OOO0 #line:1812
			else :OO00OOOO000O0OOO0 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO00OOOO000O0OOO0 #line:1813
			addFile (' %s'%OO00OOOO000O0OOO0 ,'removedata',OOO00OOO0000000OO ,icon =OOOOO0O0OOO0OOOOO ,fanart =O00OO0O00O00O0000 ,themeit =THEME2 )#line:1814
	else :#line:1815
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:1816
	setView ('files','viewType')#line:1817
def enableAddons ():#line:1818
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:1819
	O0O0OOO000OOOOO0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:1820
	O000O00000OOOO0O0 =0 #line:1821
	for O0OOOO0OO0000O000 in sorted (O0O0OOO000OOOOO0O ,key =lambda O000O000O000OO0O0 :O000O000O000OO0O0 ):#line:1822
		O000OOOO0O0O00O00 =os .path .split (O0OOOO0OO0000O000 [:-1 ])[1 ]#line:1823
		if O000OOOO0O0O00O00 in EXCLUDES :continue #line:1824
		if O000OOOO0O0O00O00 in DEFAULTPLUGINS :continue #line:1825
		O00O000OO0OO0OOOO =os .path .join (O0OOOO0OO0000O000 ,'addon.xml')#line:1826
		if os .path .exists (O00O000OO0OO0OOOO ):#line:1827
			O000O00000OOOO0O0 +=1 #line:1828
			O0O0OOO000OOOOO0O =O0OOOO0OO0000O000 .replace (ADDONS ,'')[1 :-1 ]#line:1829
			OO00O0000000O00O0 =open (O00O000OO0OO0OOOO )#line:1830
			OOO0O0O00O00000OO =OO00O0000000O00O0 .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:1831
			O000O0OO000OOO0O0 =wiz .parseDOM (OOO0O0O00O00000OO ,'addon',ret ='id')#line:1832
			OOOOOO00OO0000OO0 =wiz .parseDOM (OOO0O0O00O00000OO ,'addon',ret ='name')#line:1833
			try :#line:1834
				OO00O0O0OOOOO0O00 =O000O0OO000OOO0O0 [0 ]#line:1835
				O0OO000OO0000OOO0 =OOOOOO00OO0000OO0 [0 ]#line:1836
			except :#line:1837
				continue #line:1838
			try :#line:1839
				O0OO0OO00O0000O0O =xbmcaddon .Addon (id =OO00O0O0OOOOO0O00 )#line:1840
				OOO000O000O00OOOO ="[COLOR green][Enabled][/COLOR]"#line:1841
				OO00O00O0OOOOO00O ="false"#line:1842
			except :#line:1843
				OOO000O000O00OOOO ="[COLOR red][Disabled][/COLOR]"#line:1844
				OO00O00O0OOOOO00O ="true"#line:1845
				pass #line:1846
			OO00OO000OO0OO00O =os .path .join (O0OOOO0OO0000O000 ,'icon.png')if os .path .exists (os .path .join (O0OOOO0OO0000O000 ,'icon.png'))else ICON #line:1847
			O000OOO00OO0000OO =os .path .join (O0OOOO0OO0000O000 ,'fanart.jpg')if os .path .exists (os .path .join (O0OOOO0OO0000O000 ,'fanart.jpg'))else FANART #line:1848
			addFile ("%s %s"%(OOO000O000O00OOOO ,O0OO000OO0000OOO0 ),'toggleaddon',O0O0OOO000OOOOO0O ,OO00O00O0OOOOO00O ,icon =OO00OO000OO0OO00O ,fanart =O000OOO00OO0000OO )#line:1849
			OO00O0000000O00O0 .close ()#line:1850
	if O000O00000OOOO0O0 ==0 :#line:1851
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:1852
	setView ('files','viewType')#line:1853
def changeFeq ():#line:1854
	OO000O0OO00OOOOO0 =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:1855
	O0OO00O0O00000OOO =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,OO000O0OO00OOOOO0 )#line:1856
	if not O0OO00O0O00000OOO ==-1 :#line:1857
		wiz .setS ('autocleanfeq',str (O0OO00O0O00000OOO ))#line:1858
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,OO000O0OO00OOOOO0 [O0OO00O0O00000OOO ]))#line:1859
def developer ():#line:1860
	addFile ('Skin Swap Popup','sswap',themeit =THEME1 )#line:1861
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:1862
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:1863
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:1864
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:1865
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:1866
	addFile ('Test Auto ADV Settings','autoadvanced',themeit =THEME1 )#line:1867
	setView ('files','viewType')#line:1868
def decode (OOOO0OOOO0O0000O0 ,O00O0OOO0O0OO0O0O ):#line:1872
    import base64 #line:1873
    O0O000OO0O0O00OO0 =[]#line:1874
    if (len (OOOO0OOOO0O0000O0 ))!=4 :#line:1876
     return 10 #line:1877
    O00O0OOO0O0OO0O0O =base64 .urlsafe_b64decode (O00O0OOO0O0OO0O0O )#line:1878
    for OO00OO0O00OO0O0O0 in range (len (O00O0OOO0O0OO0O0O )):#line:1880
        O00OO0OO00O0O00OO =OOOO0OOOO0O0000O0 [OO00OO0O00OO0O0O0 %len (OOOO0OOOO0O0000O0 )]#line:1881
        O0OO0O00OO00OOO00 =chr ((256 +ord (O00O0OOO0O0OO0O0O [OO00OO0O00OO0O0O0 ])-ord (O00OO0OO00O0O00OO ))%256 )#line:1882
        O0O000OO0O0O00OO0 .append (O0OO0O00OO00OOO00 )#line:1883
    return "".join (O0O000OO0O0O00OO0 )#line:1884
def tmdb_list (OOO00OO000OOOOO00 ):#line:1885
    O00OOO0O00O000O0O =decode ("7643",OOO00OO000OOOOO00 )#line:1888
    return int (O00OOO0O00O000O0O )#line:1891
def u_list (O0O00OOOOOO00O0O0 ):#line:1892
    from math import sqrt #line:1894
    O00OOO0OO000O000O =tmdb_list (TMDB_NEW_API )#line:1895
    O00O0OOOOOO000OO0 =str ((getHwAddr ('eth0'))*O00OOO0OO000O000O )#line:1897
    O00000OO0OO00O0O0 =int (O00O0OOOOOO000OO0 [1 ]+O00O0OOOOOO000OO0 [2 ]+O00O0OOOOOO000OO0 [5 ]+O00O0OOOOOO000OO0 [7 ])#line:1899
    OO0OO0OO00O000O0O =(ADDON .getSetting ("pass"))#line:1901
    OOOOOOOO0O0O0OO0O =(str (round (sqrt ((O00000OO0OO00O0O0 *700 )+50 )+50 ,4 ))[-4 :]).replace ('.','')#line:1906
    if '.'in OOOOOOOO0O0O0OO0O :#line:1907
     OOOOOOOO0O0O0OO0O =(str (round (sqrt ((O00000OO0OO00O0O0 *700 )+50 )+50 ,4 ))[-5 :]).replace ('.','')#line:1908
    if OO0OO0OO00O000O0O ==OOOOOOOO0O0O0OO0O :#line:1910
        OOOOOO0O0OOOOO0O0 =O0O00OOOOOO00O0O0 #line:1912
       
        return OOOOOO0O0OOOOO0O0,O00000OO0OO00O0O0 #line:1913
    else :#line:1914
       OOOOOO0O0OOOOO0O0 ='https://www.google.com/search?&q=don%27t+take+my+money&oq=dont+take+my+moniey'#line:1916
       xbmcgui .Dialog ().ok ('הקוד שלך',' סיסמה שגויה')#line:1917
    
    return 'aa',O00000OO0OO00O0O0#line:1919
def disply_hwr ():#line:1921
   O0O0OO0OO0OO0000O =tmdb_list (TMDB_NEW_API )#line:1922
   OOO0O00OOOOOOO0OO =str ((getHwAddr ('eth0'))*O0O0OO0OO0OO0000O )#line:1923
   OOO000OO000OO0OOO =(OOO0O00OOOOOOO0OO [1 ]+OOO0O00OOOOOOO0OO [2 ]+OOO0O00OOOOOOO0OO [5 ]+OOO0O00OOOOOOO0OO [7 ])#line:1927
   O00OOOO0O0OO0OOO0 =(ADDON .getSetting ("action"))#line:1928
   wiz .setS ('action',str (OOO000OO000OO0OOO ))#line:1930
def disply_hwr2 ():#line:1931
   O0OO0OO00OOOOO00O =tmdb_list (TMDB_NEW_API )#line:1932
   OO000O0O00OOOOO0O =str ((getHwAddr ('eth0'))*O0OO0OO00OOOOO00O )#line:1933
   OO00O0O0O0OOOO000 =(OO000O0O00OOOOO0O [1 ]+OO000O0O00OOOOO0O [2 ]+OO000O0O00OOOOO0O [5 ]+OO000O0O00OOOOO0O [7 ])#line:1937
   OOOO00OO00O00O000 =(ADDON .getSetting ("action"))#line:1938
   xbmcgui .Dialog ().ok ("[COLOR yellow] לשלוח את הקוד למנהלים [/COLOR]",OO00O0O0O0OOOO000 )#line:1941
def getHwAddr (OO0OO000O0O0OOO00 ):#line:1943
   import subprocess ,time #line:1944
   OO0OO0OOOO000000O ='windows'#line:1945
   if xbmc .getCondVisibility ('system.platform.android'):#line:1946
       OO0OO0OOOO000000O ='android'#line:1947
   if xbmc .getCondVisibility ('system.platform.android'):#line:1948
     O0OOO000O000O0O0O =subprocess .Popen (["exec ''ip link''"],executable ='/system/bin/sh',shell =True ,stdout =subprocess .PIPE ,stderr =subprocess .STDOUT ).communicate ()[0 ].splitlines ()#line:1949
     O0O00OO000O0OOOOO =re .compile ('link/ether (.+?) brd').findall (str (O0OOO000O000O0O0O ))#line:1951
     OO0000OO00O00O000 =0 #line:1952
     for OO000OO00O000O0O0 in O0O00OO000O0OOOOO :#line:1953
      if O0O00OO000O0OOOOO !='00:00:00:00:00:00':#line:1954
          OOO00OOO0OOO0000O =OO000OO00O000O0O0 #line:1955
          OO0000OO00O00O000 =OO0000OO00O00O000 +int (OOO00OOO0OOO0000O .replace (':',''),16 )#line:1956
   elif xbmc .getCondVisibility ('system.platform.windows'):#line:1958
       O0O0O0O0000O00OO0 =0 #line:1959
       OO0000OO00O00O000 =0 #line:1960
       OO0OO0OOOOOOOO0OO =[]#line:1961
       OOOO0OO0O00O0OO0O =os .popen ("getmac").read ()#line:1962
       OOOO0OO0O00O0OO0O =OOOO0OO0O00O0OO0O .split ("\n")#line:1963
       for O00O0OOOOO0OO00OO in OOOO0OO0O00O0OO0O :#line:1965
            OOO000O0OOO000OOO =re .search (r'([0-9A-F]{2}[:-]){5}([0-9A-F]{2})',O00O0OOOOO0OO00OO ,re .I )#line:1966
            if OOO000O0OOO000OOO :#line:1967
                O0O00OO000O0OOOOO =OOO000O0OOO000OOO .group ().replace ('-',':')#line:1968
                OO0OO0OOOOOOOO0OO .append (O0O00OO000O0OOOOO )#line:1969
                OO0000OO00O00O000 =OO0000OO00O00O000 +int (O0O00OO000O0OOOOO .replace (':',''),16 )#line:1972
   else :#line:1974
       O0O0O0O0000O00OO0 =0 #line:1975
       OO0000OO00O00O000 =0 #line:1976
       while (1 ):#line:1977
         OOO00OOO0OOO0000O =xbmc .getInfoLabel ("network.macaddress")#line:1978
         logging .warning (OOO00OOO0OOO0000O )#line:1979
         if OOO00OOO0OOO0000O !="Busy"and OOO00OOO0OOO0000O !=' עסוק':#line:1980
            break #line:1982
         else :#line:1983
           O0O0O0O0000O00OO0 =O0O0O0O0000O00OO0 +1 #line:1984
           time .sleep (1 )#line:1985
           if O0O0O0O0000O00OO0 >30 :#line:1986
            break #line:1987
       OO0000OO00O00O000 =OO0000OO00O00O000 +int (OOO00OOO0OOO0000O .replace (':',''),16 )#line:1988
       logging .warning ('n:'+str (OO0000OO00O00O000 ))#line:1989
   return OO0000OO00O00O000 #line:1990
def buildWizard (OOO0OOOOOOO00OO00 ,O00OOO0O000OO0000 ,theme =None ,over =False ):#line:1992
    OOOOO000OO00OO000,O00000OO0OO00O0O0 =u_list ('urg')#line:1994
    if OOOOO000OO00OO000 =='aa':#line:1995
       search_entered=''
       
       jump=0
       keyboard = xbmc.Keyboard(search_entered, 'קוד החומרה הוא: '+str(O00000OO0OO00O0O0))
       keyboard.doModal()
       if keyboard.isConfirmed():
               search_entered = keyboard.getText()
               ADDON .setSetting ("pass",search_entered)
               OOOOO000OO00OO000,O00000OO0OO00O0O0 =u_list ('urg')#line:1994
               if OOOOO000OO00OO000 =='aa':#line:1995
                  return
               else:
                jump=1
       if jump==0:
       
            return #line:1996
    if over ==False :#line:1997
        logging.warning(OOO0OOOOOOO00OO00)
        logging.warning('build')
        OO0OOO00OO0000000 =wiz .checkBuild (OOO0OOOOOOO00OO00 ,'url')#line:1998
        OOO00000O0OO00O0O =wiz .workingURL (OO0OOO00OO0000000 )#line:2002
        if OOO00000O0OO00O0O ==False :#line:2003
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OOO00000O0OO00O0O ))#line:2004
            return #line:2005
    if O00OOO0O000OO0000 =='gui':#line:2006
        if OOO0OOOOOOO00OO00 ==BUILDNAME :#line:2007
            if over ==True :OO0OOO00OO00O0000 =1 #line:2008
            else :OO0OOO00OO00O0000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s] האם לבצע תהליך עדכון מהיר עבור: '%COLOR2 ,'[COLOR %s]%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOO0OOOOOOO00OO00 ),nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]בצע עדכון[/COLOR][/B]')#line:2009
        else :#line:2010
            OO0OOO00OO00O0000 =DIALOG .yesno ("%s - [COLOR red]WARNING!![/COLOR]"%ADDONTITLE ,"[COLOR %s][COLOR %s]%s[/COLOR] community build is not currently installed."%(COLOR2 ,COLOR1 ,OOO0OOOOOOO00OO00 ),"האם לאשר למרות זאת שינוי הממשק?[/COLOR]",nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]Apply Fix[/COLOR][/B]')#line:2011
        if OO0OOO00OO00O0000 :#line:2012
            OOOOO0OOO0O000OO0 =wiz .checkBuild (OOO0OOOOOOO00OO00 ,'gui')#line:2013
            O000000O00O00O0O0 =OOO0OOOOOOO00OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:2014
            if not wiz .workingURL (OOOOO0OOO0O000OO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:2015
            if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2016
            DP .create (ADDONTITLE ,'[COLOR %s][B] הורדת עדכון [/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOOOOOO00OO00 ),'','Please Wait')#line:2017
            O0000OOO000O0O00O =os .path .join (PACKAGES ,'%s_guisettings.zip'%O000000O00O00O0O0 )#line:2018
            try :os .remove (O0000OOO000O0O00O )#line:2019
            except :pass #line:2020
            logging .warning (OOOOO0OOO0O000OO0 )#line:2021
            if 'google'in OOOOO0OOO0O000OO0 :#line:2022
               O0O0O00O000OO0OOO =googledrive_download (OOOOO0OOO0O000OO0 ,O0000OOO000O0O00O ,DP ,wiz .checkBuild (OOO0OOOOOOO00OO00 ,'filesize'))#line:2023
            else :#line:2026
              downloader .download (OOOOO0OOO0O000OO0 ,O0000OOO000O0O00O ,DP )#line:2027
            downloader .download (OOOOO0OOO0O000OO0 ,O0000OOO000O0O00O ,DP )#line:2028
            xbmc .sleep (500 )#line:2029
            O0OOO0O00000O0000 ='[COLOR %s][B] התקנה [/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOOOOOO00OO00 )#line:2030
            DP .update (0 ,O0OOO0O00000O0000 ,'','אנא המתן')#line:2031
            extract .all (O0000OOO000O0O00O ,USERDATA ,DP ,title =O0OOO0O00000O0000 )#line:2032
            DP .update (0 ,O0OOO0O00000O0000 ,'','אנא המתן')#line:2033
            extract .all (O0000OOO000O0O00O ,HOME ,DP ,title =O0OOO0O00000O0000 )#line:2034
            DP .close ()#line:2035
            wiz .defaultSkin ()#line:2036
            wiz .lookandFeelData ('save')#line:2037
            wiz .kodi17Fix ()#line:2039
            if INSTALLMETHOD ==1 :OOO00000O0OO000O0 =1 #line:2040
            elif INSTALLMETHOD ==2 :OOO00000O0OO000O0 =0 #line:2041
            else :DP .close ()#line:2042
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]עדכון מהיר בוצע בהצלחה![/COLOR]'%COLOR2 )#line:2043
        else :#line:2044
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:2045
    elif O00OOO0O000OO0000 =='fresh':#line:2046
        freshStart (OOO0OOOOOOO00OO00 )#line:2047
    elif O00OOO0O000OO0000 =='normal':#line:2048
        if url =='normal':#line:2049
            if KEEPTRAKT =='true':#line:2050
                traktit .autoUpdate ('all')#line:2051
                wiz .setS ('traktlastsave',str (THREEDAYS ))#line:2052
            if KEEPREAL =='true':#line:2053
                debridit .autoUpdate ('all')#line:2054
                wiz .setS ('debridlastsave',str (THREEDAYS ))#line:2055
            if KEEPALLUC =='true':#line:2056
                allucit .autoUpdate ('all')#line:2057
                wiz .setS ('allucnlastsave',str (THREEDAYS ))#line:2058
            if KEEPLOGIN =='true':#line:2059
                loginit .autoUpdate ('all')#line:2060
                wiz .setS ('loginlastsave',str (THREEDAYS ))#line:2061
        O0OOOOOO00OO0OO0O =int (KODIV );OOOOOO0O0OO0OO0OO =int (float (wiz .checkBuild (OOO0OOOOOOO00OO00 ,'kodi')))#line:2062
        if not O0OOOOOO00OO0OO0O ==OOOOOO0O0OO0OO0OO :#line:2063
            if O0OOOOOO00OO0OO0O ==16 and OOOOOO0O0OO0OO0OO <=15 :O0O0000000OO000OO =False #line:2064
            else :O0O0000000OO000OO =True #line:2065
        else :O0O0000000OO000OO =False #line:2066
        if O0O0000000OO000OO ==True :#line:2067
            OO000OO00000OOOOO =DIALOG .yesno ("%s - [COLOR red]WARNING!![/COLOR]"%ADDONTITLE ,'[COLOR %s]There is a chance that the skin will not appear correctly'%COLOR2 ,'When installing a %s build on a Kodi %s install'%(wiz .checkBuild (OOO0OOOOOOO00OO00 ,'kodi'),KODIV ),'Would you still like to install: [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOO0OOOOOOO00OO00 ,wiz .checkBuild (OOO0OOOOOOO00OO00 ,'version')),nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]Yes, Install[/COLOR][/B]')#line:2068
        else :#line:2069
            if not over ==False :OO000OO00000OOOOO =1 #line:2070
            else :OO000OO00000OOOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]האם ברצונך להוריד ולהתקין את: '%COLOR2 ,'[COLOR %s]%s v%s[/COLOR] ?[/COLOR]'%(COLOR1 ,OOO0OOOOOOO00OO00 ,wiz .checkBuild (OOO0OOOOOOO00OO00 ,'version')),nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]כן, התקן[/COLOR][/B]')#line:2071
        if OO000OO00000OOOOO :#line:2072
            wiz .clearS ('build')#line:2073
            OOOOO0OOO0O000OO0 =wiz .checkBuild (OOO0OOOOOOO00OO00 ,'url')#line:2094
            O000000O00O00O0O0 =OOO0OOOOOOO00OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:2095
            if not wiz .workingURL (OOOOO0OOO0O000OO0 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:2096
            if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2097
            DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOOOOOO00OO00 ,wiz .checkBuild (OOO0OOOOOOO00OO00 ,'version')),'','Please Wait')#line:2098
            O0000OOO000O0O00O =os .path .join (PACKAGES ,'%s.zip'%O000000O00O00O0O0 )#line:2099
            try :os .remove (O0000OOO000O0O00O )#line:2100
            except :pass #line:2101
            logging .warning (OOOOO0OOO0O000OO0 )#line:2102
            if 'google'in OOOOO0OOO0O000OO0 :#line:2103
               O0O0O00O000OO0OOO =googledrive_download (OOOOO0OOO0O000OO0 ,O0000OOO000O0O00O ,DP ,wiz .checkBuild (OOO0OOOOOOO00OO00 ,'filesize'))#line:2104
            else :#line:2107
              downloader .download (OOOOO0OOO0O000OO0 ,O0000OOO000O0O00O ,DP )#line:2108
            xbmc .sleep (500 )#line:2109
            O0OOO0O00000O0000 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOOOOOO00OO00 ,wiz .checkBuild (OOO0OOOOOOO00OO00 ,'version'))#line:2110
            DP .update (0 ,O0OOO0O00000O0000 ,'','Please Wait')#line:2111
            OOOOOOOOOO0OO0O00 ,O0OO0000O0000OOO0 ,OO0OO000OO000000O =extract .all (O0000OOO000O0O00O ,HOME ,DP ,title =O0OOO0O00000O0000 )#line:2112
            if int (float (OOOOOOOOOO0OO0O00 ))>0 :#line:2113
                wiz .fixmetas ()#line:2114
                wiz .lookandFeelData ('save')#line:2115
                wiz .defaultSkin ()#line:2116
                wiz .setS ('buildname',OOO0OOOOOOO00OO00 )#line:2118
                wiz .setS ('buildversion',wiz .checkBuild (OOO0OOOOOOO00OO00 ,'version'))#line:2119
                wiz .setS ('buildtheme','')#line:2120
                wiz .setS ('latestversion',wiz .checkBuild (OOO0OOOOOOO00OO00 ,'version'))#line:2121
                wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:2122
                wiz .setS ('installed','true')#line:2123
                wiz .setS ('extract',str (OOOOOOOOOO0OO0O00 ))#line:2124
                wiz .setS ('errors',str (O0OO0000O0000OOO0 ))#line:2125
                wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOOOOOOOO0OO0O00 ,O0OO0000O0000OOO0 ))#line:2126
                try :os .remove (O0000OOO000O0O00O )#line:2127
                except :pass #line:2128
                if int (float (O0OO0000O0000OOO0 ))>0 :#line:2129
                    OO0OOO00OO00O0000 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOOOOOO00OO00 ,wiz .checkBuild (OOO0OOOOOOO00OO00 ,'version')),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,OOOOOOOOOO0OO0O00 ,'%',COLOR1 ,O0OO0000O0000OOO0 ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:2130
                    if OO0OOO00OO00O0000 :#line:2131
                        if isinstance (O0OO0000O0000OOO0 ,unicode ):#line:2132
                            OO0OO000OO000000O =OO0OO000OO000000O .encode ('utf-8')#line:2133
                        wiz .TextBox (ADDONTITLE ,OO0OO000OO000000O )#line:2134
                DP .close ()#line:2135
                O00O0OO0OOOOOOO00 =wiz .themeCount (OOO0OOOOOOO00OO00 )#line:2136
                if not O00O0OO0OOOOOOO00 ==False :#line:2137
                    buildWizard (OOO0OOOOOOO00OO00 ,'theme')#line:2138
                if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:2139
                DIALOG .ok (ADDONTITLE ,"[COLOR %s]ההתקנה הסתיימה בהצלחה עליך ללחוץ על כפתור ה OK על מנת לסיים את ההתקנה.[/COLOR]"%COLOR2 );wiz .killxbmc ('true')#line:2140
            else :#line:2141
                if isinstance (O0OO0000O0000OOO0 ,unicode ):#line:2142
                    OO0OO000OO000000O =OO0OO000OO000000O .encode ('utf-8')#line:2143
                wiz .TextBox ("%s: Error Installing Build"%ADDONTITLE ,OO0OO000OO000000O )#line:2144
        else :#line:2145
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Cancelled![/COLOR]'%COLOR2 )#line:2146
    elif O00OOO0O000OO0000 =='theme':#line:2147
        if theme ==None :#line:2148
            O00O0OO0OOOOOOO00 =wiz .checkBuild (OOO0OOOOOOO00OO00 ,'theme')#line:2149
            O0OOOO00O00OOO00O =[]#line:2150
            if not O00O0OO0OOOOOOO00 =='http://'and wiz .workingURL (O00O0OO0OOOOOOO00 )==True :#line:2151
                O0OOOO00O00OOO00O =wiz .themeCount (OOO0OOOOOOO00OO00 ,False )#line:2152
                if len (O0OOOO00O00OOO00O )>0 :#line:2153
                    if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,OOO0OOOOOOO00OO00 ,COLOR1 ,len (O0OOOO00O00OOO00O )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:2154
                        wiz .log ("Theme List: %s "%str (O0OOOO00O00OOO00O ))#line:2155
                        O0OO0OOO0O0OOOOO0 =DIALOG .select (ADDONTITLE ,O0OOOO00O00OOO00O )#line:2156
                        wiz .log ("Theme install selected: %s"%O0OO0OOO0O0OOOOO0 )#line:2157
                        if not O0OO0OOO0O0OOOOO0 ==-1 :theme =O0OOOO00O00OOO00O [O0OO0OOO0O0OOOOO0 ];OOOOOOOOOO0O0O00O =True #line:2158
                        else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:2159
                    else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:2160
            else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: לא נמצא ![/COLOR]'%COLOR2 )#line:2161
        else :OOOOOOOOOO0O0O00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,OOO0OOOOOOO00OO00 ,wiz .checkBuild (OOO0OOOOOOO00OO00 ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:2162
        if OOOOOOOOOO0O0O00O :#line:2163
            OO00OOOO000O00O0O =wiz .checkTheme (OOO0OOOOOOO00OO00 ,theme ,'url')#line:2164
            O000000O00O00O0O0 =OOO0OOOOOOO00OO00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:2165
            if not wiz .workingURL (OO00OOOO000O00O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:2166
            if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2167
            DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:2168
            O0000OOO000O0O00O =os .path .join (PACKAGES ,'%s.zip'%O000000O00O00O0O0 )#line:2169
            try :os .remove (O0000OOO000O0O00O )#line:2170
            except :pass #line:2171
            downloader .download (OO00OOOO000O00O0O ,O0000OOO000O0O00O ,DP )#line:2172
            xbmc .sleep (500 )#line:2173
            DP .update (0 ,"","Installing %s "%OOO0OOOOOOO00OO00 )#line:2174
            O0OO0000O00OO000O =False #line:2175
            if url not in ["fresh","normal"]:#line:2176
                O0OO0000O00OO000O =testTheme (O0000OOO000O0O00O )if not wiz .currSkin ()in ['skin.confluence','skin.estuary']else False #line:2177
                O00O000O0O0OOO000 =testGui (O0000OOO000O0O00O )if not wiz .currSkin ()in ['skin.confluence','skin.estuary']else False #line:2178
                if O0OO0000O00OO000O ==True :#line:2179
                    wiz .lookandFeelData ('save')#line:2180
                    O0OO00000OOOO0OOO =wiz .skinToDefault ('Theme Install')#line:2181
                    if O0OO00000OOOO0OOO ==False :return False #line:2182
                    xbmc .sleep (500 )#line:2183
            O0OOO0O00000O0000 ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:2184
            DP .update (0 ,O0OOO0O00000O0000 ,'','Please Wait')#line:2185
            OOOOOOOOOO0OO0O00 ,O0OO0000O0000OOO0 ,OO0OO000OO000000O =extract .all (O0000OOO000O0O00O ,HOME ,DP ,title =O0OOO0O00000O0000 )#line:2186
            wiz .setS ('buildtheme',theme )#line:2187
            wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OOOOOOOOOO0OO0O00 ,O0OO0000O0000OOO0 ))#line:2188
            DP .close ()#line:2189
            if url not in ["fresh","normal"]:#line:2190
                wiz .forceUpdate ()#line:2191
                if KODIV >=17 :#line:2192
                    OO0O0O0OOOOO000OO =grabAddons (O0000OOO000O0O00O )#line:2193
                    wiz .addonDatabase (OO0O0O0OOOOO000OO ,1 ,True )#line:2194
                if O00O000O0O0OOO000 ==True :#line:2195
                    wiz .lookandFeelData ('save')#line:2196
                    wiz .defaultSkin ()#line:2197
                    O0OOO00OOOO00OOOO =wiz .getS ('defaultskin')#line:2198
                    wiz .swapSkins (O0OOO00OOOO00OOOO ,"Theme Installer")#line:2199
                    wiz .lookandFeelData ('restore')#line:2200
                elif O0OO0000O00OO000O ==True :#line:2201
                    OO00O0OO00000O0O0 =wiz .swapSkins (O0OOO00OOOO00OOOO ,'Theme Install')#line:2202
                    if OO00O0OO00000O0O0 ==False :return #line:2203
                    wiz .lookandFeelData ('restore')#line:2204
                else :#line:2205
                    wiz .ebi ("ReloadSkin()")#line:2206
                    xbmc .sleep (1000 )#line:2207
                    wiz .ebi ("Container.Refresh")#line:2208
        else :#line:2209
            wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:2210
def thirdPartyInstall (O0000OO000OO00OOO ,O00O000OO00O0OOO0 ):#line:2211
	if not wiz .workingURL (O00O000OO00O0OOO0 ):#line:2212
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:2213
	OO0OOOOOOO00OOO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0000OO000OO00OOO ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:2214
	if OO0OOOOOOO00OOO00 ==1 :#line:2215
		freshStart ('third',True )#line:2216
	wiz .clearS ('build')#line:2217
	OOO0OOO0OO000O00O =O0000OO000OO00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:2218
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2219
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OO000OO00OOO ),'','Please Wait')#line:2220
	O0OOO0OO000OOO000 =os .path .join (PACKAGES ,'%s.zip'%OOO0OOO0OO000O00O )#line:2221
	try :os .remove (O0OOO0OO000OOO000 )#line:2222
	except :pass #line:2223
	downloader .download (O00O000OO00O0OOO0 ,O0OOO0OO000OOO000 ,DP )#line:2224
	xbmc .sleep (500 )#line:2225
	OO000OO0OO000OO00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OO000OO00OOO )#line:2226
	DP .update (0 ,OO000OO0OO000OO00 ,'','Please Wait')#line:2227
	O0O000OO000OOOO00 ,OO0OO0O0O0OO0OO00 ,O0OOOO00000O0OOO0 =extract .all (O0OOO0OO000OOO000 ,HOME ,DP ,title =OO000OO0OO000OO00 )#line:2228
	if int (float (O0O000OO000OOOO00 ))>0 :#line:2229
		wiz .fixmetas ()#line:2230
		wiz .lookandFeelData ('save')#line:2231
		wiz .defaultSkin ()#line:2232
		wiz .setS ('installed','true')#line:2234
		wiz .setS ('extract',str (O0O000OO000OOOO00 ))#line:2235
		wiz .setS ('errors',str (OO0OO0O0O0OO0OO00 ))#line:2236
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O000OO000OOOO00 ,OO0OO0O0O0OO0OO00 ))#line:2237
		try :os .remove (O0OOO0OO000OOO000 )#line:2238
		except :pass #line:2239
		if int (float (OO0OO0O0O0OO0OO00 ))>0 :#line:2240
			O0O0O00O0OO0OO00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0000OO000OO00OOO ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O000OO000OOOO00 ,'%',COLOR1 ,OO0OO0O0O0OO0OO00 ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:2241
			if O0O0O00O0OO0OO00O :#line:2242
				if isinstance (OO0OO0O0O0OO0OO00 ,unicode ):#line:2243
					O0OOOO00000O0OOO0 =O0OOOO00000O0OOO0 .encode ('utf-8')#line:2244
				wiz .TextBox (ADDONTITLE ,O0OOOO00000O0OOO0 )#line:2245
	DP .close ()#line:2246
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:2247
	if INSTALLMETHOD ==1 :O0O0O00O0O0OO0OOO =1 #line:2248
	elif INSTALLMETHOD ==2 :O0O0O00O0O0OO0OOO =0 #line:2249
	else :O0O0O00O0O0OO0OOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:2250
	if O0O0O00O0O0OO0OOO ==1 :wiz .reloadFix ()#line:2251
	else :wiz .killxbmc (True )#line:2252
def testTheme (OO0O00OO00O0O000O ):#line:2253
	O0000OO0OO000OOO0 =zipfile .ZipFile (OO0O00OO00O0O000O )#line:2254
	for OO00OOO00OOOO0OO0 in O0000OO0OO000OOO0 .infolist ():#line:2255
		wiz .log (str (OO00OOO00OOOO0OO0 .filename ))#line:2256
		if '/settings.xml'in OO00OOO00OOOO0OO0 .filename :#line:2257
			return True #line:2258
	return False #line:2259
def testGui (O00O0O0O00O0O0O0O ):#line:2260
	OO000O0O00OO00OO0 =zipfile .ZipFile (O00O0O0O00O0O0O0O )#line:2261
	for OOOOO00000OO0OO0O in OO000O0O00OO00OO0 .infolist ():#line:2262
		if '/guisettings.xml'in OOOOO00000OO0OO0O .filename :#line:2263
			return True #line:2264
	return False #line:2265
def grabAddons (OO00O00O0000O00OO ):#line:2266
	OOO0O0OOOO00000O0 =zipfile .ZipFile (OO00O00O0000O00OO )#line:2267
	OO0000O00OOO0OOOO =[]#line:2268
	for OO0O0O00OOO0OOO0O in OOO0O0OOOO00000O0 .infolist ():#line:2269
		if str (OO0O0O00OOO0OOO0O .filename ).find ('addon.xml')==-1 :continue #line:2270
		OOO00OO00O0O0O000 =str (OO0O0O00OOO0OOO0O .filename ).split ('/')#line:2271
		if not OOO00OO00O0O0O000 [-2 ]in OO0000O00OOO0OOOO :#line:2272
			OO0000O00OOO0OOOO .append (OOO00OO00O0O0O000 [-2 ])#line:2273
	return OO0000O00OOO0OOOO #line:2274
def apkInstaller (OOOOOO00O0O0OO000 ,O0O000O0OOO0OO000 ):#line:2275
	wiz .log (OOOOOO00O0O0OO000 )#line:2276
	wiz .log (O0O000O0OOO0OO000 )#line:2277
	if wiz .platform ()=='android'or DEVELOPER =='true':#line:2278
		O0OO0O000O0O00OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to download and install:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OOOOOO00O0O0OO000 ),yeslabel ="[B][COLOR green]Download[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2279
		if not O0OO0O000O0O00OO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:2280
		OO000O0OOOO0OO0O0 =OOOOOO00O0O0OO000 #line:2281
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2282
		if not wiz .workingURL (O0O000O0OOO0OO000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:2283
		DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO000O0OOOO0OO0O0 ),'','Please Wait')#line:2284
		O00OO00OOO000O0O0 =os .path .join (PACKAGES ,"%s.apk"%OOOOOO00O0O0OO000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:2285
		try :os .remove (O00OO00OOO000O0O0 )#line:2286
		except :pass #line:2287
		downloader .download (O0O000O0OOO0OO000 ,O00OO00OOO000O0O0 ,DP )#line:2288
		xbmc .sleep (100 )#line:2289
		DP .close ()#line:2290
		notify .apkInstaller (OOOOOO00O0O0OO000 )#line:2291
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O00OO00OOO000O0O0 +'")')#line:2292
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:2293
def apkInstaller1 (OO000O0O00O0O0000 ,O0O00OOOO00O0OO0O ):#line:2294
	if wiz .platform ()=='android'or DEVELOPER =='true':#line:2295
		O0000000O0O000OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to download and install:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O0O00O0O0000 ),yeslabel ="[B][COLOR green]Download[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2296
		if not O0000000O0O000OO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:2297
		OO00OOOO000O0O0OO =OO000O0O00O0O0000 #line:2298
		if O0000000O0O000OO0 :#line:2299
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2300
			if not wiz .workingURL (O0O00OOOO00O0OO0O )==True :wiz .LogNotify (ADDONTITLE ,'APK Installer: [COLOR red]Invalid Apk Url![/COLOR]');return #line:2301
			DP .create (ADDONTITLE ,'Downloading %s'%OO00OOOO000O0O0OO ,'','Please Wait')#line:2302
			O0O00O0O0OO0O00O0 =os .path .join (PACKAGES ,"%s.apk"%OO000O0O00O0O0000 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:2303
			try :os .remove (O0O00O0O0OO0O00O0 )#line:2304
			except :pass #line:2305
			downloader .download (O0O00OOOO00O0OO0O ,O0O00O0O0OO0O00O0 ,DP )#line:2306
			xbmc .sleep (500 )#line:2307
			DP .close ()#line:2308
			DIALOG .ok (ADDONTITLE ,"Launching the APK to be installed","Follow the install process to complete.")#line:2309
			xbmc .executebuiltin ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0O00O0O0OO0O00O0 +'")')#line:2310
		else :wiz .LogNotify (ADDONTITLE ,'[COLOR red]ERROR:[/COLOR] Install Cancelled')#line:2311
	else :wiz .LogNotify (ADDONTITLE ,'[COLOR red]ERROR:[/COLOR] None Android Device')#line:2312
def romInstaller (O0OO00O00OO0OO0OO ,O000O0O00O00000OO ):#line:2313
	OO00O0OOO0OOO000O =xbmc .translatePath (BACKUPROMS )#line:2314
	if OO00O0OOO0OOO000O =='':#line:2315
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that you do not have an extract location setup for Rom Packs"%COLOR2 ,"Would you like to set one?[/COLOR]",yeslabel ="[COLOR green][B]Set Location[/B][/COLOR]",nolabel ="[COLOR red][B]Cancel Download[/B][/COLOR]"):#line:2316
			wiz .openS ()#line:2317
			OO00O0OOO0OOO000O =wiz .getS ('rompath')#line:2318
			if OO00O0OOO0OOO000O =='':return #line:2319
	O00OOOOOOOOO00OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Are you sure you would like to download and extract [COLOR %s]%s[/COLOR] to:"%(COLOR2 ,COLOR1 ,O0OO00O00OO0OO0OO ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00O0OOO0OOO000O ),yeslabel ="[B][COLOR green]Download[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:2320
	if not O00OOOOOOOOO00OO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:2321
	OOO00OOO0O00O0000 =O0OO00O00OO0OO0OO #line:2322
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2323
	if not wiz .workingURL (O000O0O00O00000OO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Rom Url![/COLOR]'%COLOR2 );return #line:2324
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO00OOO0O00O0000 ),'','Please Wait')#line:2325
	OO0O0O0OO00OO0OOO =os .path .join (PACKAGES ,"%s.zip"%O0OO00O00OO0OO0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:2326
	try :os .remove (OO0O0O0OO00OO0OOO )#line:2327
	except :pass #line:2328
	downloader .download (O000O0O00O00000OO ,OO0O0O0OO00OO0OOO ,DP )#line:2329
	xbmc .sleep (100 )#line:2330
	OO000O00OOO0O000O ,O0OOO0000O0OO00OO ,O0O000000OO0O0OOO =extract .all (OO0O0O0OO00OO0OOO ,OO00O0OOO0OOO000O ,DP ,title =OOO00OOO0O00O0000 )#line:2331
	try :os .remove (OO0O0O0OO00OO0OOO )#line:2332
	except :pass #line:2333
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Rom Pack Installed[/COLOR]'%COLOR2 )#line:2334
	DP .close ()#line:2335
def createMenu (OOOOOOOOO00O00000 ,O00O000OOO0O0OO00 ,OOO00OO0OO0000000 ):#line:2339
	if OOOOOOOOO00O00000 =='saveaddon':#line:2340
		O000O000OOOOOOO0O =[]#line:2341
		O000OOOOO0OOOOOO0 =urllib .quote_plus (O00O000OOO0O0OO00 .lower ().replace (' ',''))#line:2342
		O0O00000OOOOOOO00 =O00O000OOO0O0OO00 .replace ('Debrid','Real Debrid')#line:2343
		O00O0OO0OOO0OO000 =urllib .quote_plus (OOO00OO0OO0000000 .lower ().replace (' ',''))#line:2344
		OOO00OO0OO0000000 =OOO00OO0OO0000000 .replace ('url','URL Resolver')#line:2345
		O000O000OOOOOOO0O .append ((THEME2 %OOO00OO0OO0000000 .title (),' '))#line:2346
		O000O000OOOOOOO0O .append ((THEME3 %'Save %s Data'%O0O00000OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O000OOOOO0OOOOOO0 ,O00O0OO0OOO0OO000 )))#line:2347
		O000O000OOOOOOO0O .append ((THEME3 %'Restore %s Data'%O0O00000OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O000OOOOO0OOOOOO0 ,O00O0OO0OOO0OO000 )))#line:2348
		O000O000OOOOOOO0O .append ((THEME3 %'Clear %s Data'%O0O00000OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,O000OOOOO0OOOOOO0 ,O00O0OO0OOO0OO000 )))#line:2349
	elif OOOOOOOOO00O00000 =='save':#line:2350
		O000O000OOOOOOO0O =[]#line:2351
		O000OOOOO0OOOOOO0 =urllib .quote_plus (O00O000OOO0O0OO00 .lower ().replace (' ',''))#line:2352
		O0O00000OOOOOOO00 =O00O000OOO0O0OO00 .replace ('Debrid','Real Debrid')#line:2353
		O00O0OO0OOO0OO000 =urllib .quote_plus (OOO00OO0OO0000000 .lower ().replace (' ',''))#line:2354
		OOO00OO0OO0000000 =OOO00OO0OO0000000 .replace ('url','URL Resolver')#line:2355
		O000O000OOOOOOO0O .append ((THEME2 %OOO00OO0OO0000000 .title (),' '))#line:2356
		O000O000OOOOOOO0O .append ((THEME3 %'Register %s'%O0O00000OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,O000OOOOO0OOOOOO0 ,O00O0OO0OOO0OO000 )))#line:2357
		O000O000OOOOOOO0O .append ((THEME3 %'Save %s Data'%O0O00000OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,O000OOOOO0OOOOOO0 ,O00O0OO0OOO0OO000 )))#line:2358
		O000O000OOOOOOO0O .append ((THEME3 %'Restore %s Data'%O0O00000OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,O000OOOOO0OOOOOO0 ,O00O0OO0OOO0OO000 )))#line:2359
		O000O000OOOOOOO0O .append ((THEME3 %'Import %s Data'%O0O00000OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,O000OOOOO0OOOOOO0 ,O00O0OO0OOO0OO000 )))#line:2360
		O000O000OOOOOOO0O .append ((THEME3 %'Clear Addon %s Data'%O0O00000OOOOOOO00 ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,O000OOOOO0OOOOOO0 ,O00O0OO0OOO0OO000 )))#line:2361
	elif OOOOOOOOO00O00000 =='install':#line:2362
		O000O000OOOOOOO0O =[]#line:2363
		O00O0OO0OOO0OO000 =urllib .quote_plus (OOO00OO0OO0000000 )#line:2364
		O000O000OOOOOOO0O .append ((THEME2 %OOO00OO0OO0000000 ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,O00O0OO0OOO0OO000 )))#line:2365
		O000O000OOOOOOO0O .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,O00O0OO0OOO0OO000 )))#line:2366
		O000O000OOOOOOO0O .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,O00O0OO0OOO0OO000 )))#line:2367
		O000O000OOOOOOO0O .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,O00O0OO0OOO0OO000 )))#line:2368
		O000O000OOOOOOO0O .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,O00O0OO0OOO0OO000 )))#line:2369
	O000O000OOOOOOO0O .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:2370
	return O000O000OOOOOOO0O #line:2371
def toggleCache (O0000O0O0O0OOO0O0 ):#line:2372
	O000OO0000OO00OOO =['includevideo','includeall','includebob','includezen,' 'includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:2373
	OOO00OO0OO0OOO000 =['Include Video Addons','Include All Addons','Include Bob','Include Zen','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:2374
	if O0000O0O0O0OOO0O0 in ['true','false']:#line:2375
		for O0O0O0O0O0O0O000O in O000OO0000OO00OOO :#line:2376
			wiz .setS (O0O0O0O0O0O0O000O ,O0000O0O0O0OOO0O0 )#line:2377
	else :#line:2378
		if not O0000O0O0O0OOO0O0 in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:2379
			try :#line:2380
				O0O0O0O0O0O0O000O =OOO00OO0OO0OOO000 [O000OO0000OO00OOO .index (O0000O0O0O0OOO0O0 )]#line:2381
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,O0O0O0O0O0O0O000O ))#line:2382
			except :#line:2383
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O0000O0O0O0OOO0O0 ))#line:2384
		else :#line:2385
			OOO00O00000OO0OO0 ='true'if wiz .getS (O0000O0O0O0OOO0O0 )=='false'else 'false'#line:2386
			wiz .setS (O0000O0O0O0OOO0O0 ,OOO00O00000OO0OO0 )#line:2387
def viewLogFile ():#line:2389
	OO0OOO0OOO0OO00OO =wiz .Grab_Log (True )#line:2390
	O0O0OO000OOOOOO00 =wiz .Grab_Log (True ,True )#line:2391
	OO0O0OO0OOOO00O00 =0 ;O0O00O00O0OOO0OOO =OO0OOO0OOO0OO00OO #line:2392
	if not O0O0OO000OOOOOO00 ==False and not OO0OOO0OOO0OO00OO ==False :#line:2393
		OO0O0OO0OOOO00O00 =DIALOG .select (ADDONTITLE ,["View %s"%OO0OOO0OOO0OO00OO .replace (LOG ,""),"View %s"%O0O0OO000OOOOOO00 .replace (LOG ,"")])#line:2394
		if OO0O0OO0OOOO00O00 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]בוטלה תפיה בלוג[/COLOR]'%COLOR2 );return #line:2395
	elif OO0OOO0OOO0OO00OO ==False and O0O0OO000OOOOOO00 ==False :#line:2396
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]לא נמצא קובץ לוג[/COLOR]'%COLOR2 )#line:2397
		return #line:2398
	elif not OO0OOO0OOO0OO00OO ==False :OO0O0OO0OOOO00O00 =0 #line:2399
	elif not O0O0OO000OOOOOO00 ==False :OO0O0OO0OOOO00O00 =1 #line:2400
	O0O00O00O0OOO0OOO =OO0OOO0OOO0OO00OO if OO0O0OO0OOOO00O00 ==0 else O0O0OO000OOOOOO00 #line:2401
	O000O0OOO000O0OOO =wiz .Grab_Log (False )if OO0O0OO0OOOO00O00 ==0 else wiz .Grab_Log (False ,True )#line:2402
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0O00O00O0OOO0OOO ),O000O0OOO000O0OOO )#line:2403
def errorList (O0O0O0OOO0O0OOOO0 ):#line:2404
	OOOO0000OOO000OO0 =[]#line:2405
	OOOO00O0OO0OO0OO0 =open (O0O0O0OOO0O0OOOO0 ).read ()#line:2406
	OOO000OOO0OO0000O =OOOO00O0OO0OO0OO0 .replace ('\n','[CR]').replace ('\r','')#line:2407
	OOOO00O0O0O0O0OOO =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OOO000OOO0OO0000O )#line:2408
	for O0O0000000000O0O0 in OOOO00O0O0O0O0OOO :#line:2409
		OOOO0000OOO000OO0 .append (O0O0000000000O0O0 )#line:2410
	return OOOO0000OOO000OO0 #line:2411
def errorChecking (log =None ,count =None ,last =None ):#line:2412
	O0O0OOOO00O00OOOO =[];O00O0O0OOOOOO0OOO =[];OOO0O0OO0O0000O0O =[];#line:2413
	if log ==None :#line:2414
		O0OOO0O000O000000 =wiz .Grab_Log (True ,False )#line:2415
		OOO0OO00000O0O0OO =wiz .Grab_Log (True ,True )#line:2416
		if OOO0OO00000O0O0OO ==False and O0OOO0O000O000000 ==False :#line:2417
			if count ==None :#line:2418
				wiz .LogNotify ('[COLOR %s]View Error Log[/COLOR]'%COLOR1 ,'[COLOR %s]לא נמצא קובץ לוג[/COLOR]'%COLOR2 )#line:2419
				return #line:2420
			else :#line:2421
				return 0 #line:2422
		if not O0OOO0O000O000000 ==False :#line:2423
			O00O0O0OOOOOO0OOO =errorList (O0OOO0O000O000000 )#line:2424
		if not OOO0OO00000O0O0OO ==False :#line:2425
			OOO0O0OO0O0000O0O =errorList (OOO0OO00000O0O0OO )#line:2426
		if len (OOO0O0OO0O0000O0O )>0 :#line:2427
			for O0O00O0OOOOO000O0 in OOO0O0OO0O0000O0O :O0O0OOOO00O00OOOO =[O0O00O0OOOOO000O0 ]+O0O0OOOO00O00OOOO #line:2428
		if len (O00O0O0OOOOOO0OOO )>0 :#line:2429
			for O0O00O0OOOOO000O0 in O00O0O0OOOOOO0OOO :O0O0OOOO00O00OOOO =[O0O00O0OOOOO000O0 ]+O0O0OOOO00O00OOOO #line:2430
	else :#line:2431
		O00O0O0OOOOOO0OOO =errorList (log )#line:2432
		if len (O00O0O0OOOOOO0OOO )>0 :#line:2433
			for O0O00O0OOOOO000O0 in O00O0O0OOOOOO0OOO :O0O0OOOO00O00OOOO =[O0O00O0OOOOO000O0 ]+O0O0OOOO00O00OOOO #line:2434
	if not count ==None :#line:2435
		return len (O0O0OOOO00O00OOOO )#line:2436
	elif len (O0O0OOOO00O00OOOO )>0 :#line:2437
		if last ==None :#line:2438
			OO0O00OO00O000O00 =0 ;OO00O0O0OO0OOO00O =''#line:2439
			for O0O00O0OOOOO000O0 in O0O0OOOO00O00OOOO :#line:2440
				OO0O00OO00O000O00 +=1 #line:2441
				OO00O0O0OO0OOO00O +="[B][COLOR red]ERROR NUMBER %s:[/B][/COLOR]%s\n"%(str (OO0O00OO00O000O00 ),O0O00O0OOOOO000O0 .replace (HOME ,'/').replace ('                                        ',''))#line:2442
		else :#line:2443
			OO00O0O0OO0OOO00O ="[B][COLOR red]Last Error in Log:[/B][/COLOR]%s\n"%(O0O0OOOO00O00OOOO [0 ].replace (HOME ,'/').replace ('                                        ',''))#line:2444
		wiz .TextBox ("%s: Errors in Log"%ADDONTITLE ,OO00O0O0OO0OOO00O )#line:2445
	else :#line:2446
		wiz .LogNotify ('[COLOR %s]View Error Log[/COLOR]'%COLOR1 ,'[COLOR %s]לא נמצאו שגיאות[/COLOR]'%COLOR2 )#line:2447
def log_tools ():#line:2449
	O0OOO00000OOOO0O0 =int (errorChecking (count =True ))#line:2450
	O0O000OO0OOOO0O00 =str (O0OOO00000OOOO0O0 )#line:2451
	O0000O00OO0O00000 ='[COLOR red]%s[/COLOR] נמצא/ו '%(O0O000OO0OOOO0O00 )if O0OOO00000OOOO0O0 >0 else 'לא נמצא '#line:2452
	OOOOO0OOOO000OOO0 ='[B][COLOR green]פעיל[/COLOR][/B]';O0O000OO0O0O0O0OO ='[B][COLOR red]כבוי[/COLOR][/B]'#line:2453
	if wiz .Grab_Log (True )==False :OO00OOOOO0OO0OO00 =0 #line:2454
	else :OO00OOOOO0OO0OO00 =errorChecking (wiz .Grab_Log (True ),True )#line:2455
	if wiz .Grab_Log (True ,True )==False :O0000OO0O0O00O0OO =0 #line:2456
	else :O0000OO0O0O00O0OO =errorChecking (wiz .Grab_Log (True ,True ),True )#line:2457
	O00O00OOOO000O000 =int (OO00OOOOO0OO0OO00 )+int (O0000OO0O0O00O0OO )#line:2458
	OO00000OO0O00O000 =': [COLOR red]לא נמצא[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2459
	return O0000O00OO0O00000 #line:2460
ACTION_PREVIOUS_MENU =10 #line:2464
ACTION_NAV_BACK =92 #line:2465
ACTION_MOVE_LEFT =1 #line:2466
ACTION_MOVE_RIGHT =2 #line:2467
ACTION_MOVE_UP =3 #line:2468
ACTION_MOVE_DOWN =4 #line:2469
ACTION_MOUSE_WHEEL_UP =104 #line:2470
ACTION_MOUSE_WHEEL_DOWN =105 #line:2471
ACTION_MOVE_MOUSE =107 #line:2472
ACTION_SELECT_ITEM =7 #line:2473
ACTION_BACKSPACE =110 #line:2474
ACTION_MOUSE_LEFT_CLICK =100 #line:2475
ACTION_MOUSE_LONG_CLICK =108 #line:2476
def LogViewer (default =None ):#line:2477
	class O000O000O0O000OO0 (xbmcgui .WindowXMLDialog ):#line:2478
		def __init__ (OOO00O00OO00OO0O0 ,*O00OO000OO0O000OO ,**OOO00O0OOO0OO0OO0 ):#line:2479
			OOO00O00OO00OO0O0 .default =OOO00O0OOO0OO0OO0 ['default']#line:2480
		def onInit (O00OO000000O0O00O ):#line:2481
			O00OO000000O0O00O .title =101 #line:2482
			O00OO000000O0O00O .msg =102 #line:2483
			O00OO000000O0O00O .scrollbar =103 #line:2484
			O00OO000000O0O00O .upload =201 #line:2485
			O00OO000000O0O00O .kodi =202 #line:2486
			O00OO000000O0O00O .kodiold =203 #line:2487
			O00OO000000O0O00O .wizard =204 #line:2488
			O00OO000000O0O00O .okbutton =205 #line:2489
			OOOO0O0O00OOOO000 =open (O00OO000000O0O00O .default ,'r')#line:2490
			O00OO000000O0O00O .logmsg =OOOO0O0O00OOOO000 .read ()#line:2491
			OOOO0O0O00OOOO000 .close ()#line:2492
			O00OO000000O0O00O .titlemsg ="%s: %s"%(ADDONTITLE ,O00OO000000O0O00O .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:2493
			O00OO000000O0O00O .showdialog ()#line:2494
		def showdialog (OOO00O00000000000 ):#line:2495
			OOO00O00000000000 .getControl (OOO00O00000000000 .title ).setLabel (OOO00O00000000000 .titlemsg )#line:2496
			OOO00O00000000000 .getControl (OOO00O00000000000 .msg ).setText (wiz .highlightText (OOO00O00000000000 .logmsg ))#line:2497
			OOO00O00000000000 .setFocusId (OOO00O00000000000 .scrollbar )#line:2498
		def onClick (O00O0OO0000OOOOOO ,O00O000O0O000O0O0 ):#line:2499
			if O00O000O0O000O0O0 ==O00O0OO0000OOOOOO .okbutton :O00O0OO0000OOOOOO .close ()#line:2500
			elif O00O000O0O000O0O0 ==O00O0OO0000OOOOOO .upload :O00O0OO0000OOOOOO .close ();uploadLog .Main ()#line:2501
			elif O00O000O0O000O0O0 ==O00O0OO0000OOOOOO .kodi :#line:2502
				O0OOO0OOO000OO0OO =wiz .Grab_Log (False )#line:2503
				OO0OOOO00O0OOO0O0 =wiz .Grab_Log (True )#line:2504
				if O0OOO0OOO000OO0OO ==False :#line:2505
					O00O0OO0000OOOOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:2506
					O00O0OO0000OOOOOO .getControl (O00O0OO0000OOOOOO .msg ).setText ("Log File Does Not Exists!")#line:2507
				else :#line:2508
					O00O0OO0000OOOOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OOOO00O0OOO0O0 .replace (LOG ,''))#line:2509
					O00O0OO0000OOOOOO .getControl (O00O0OO0000OOOOOO .title ).setLabel (O00O0OO0000OOOOOO .titlemsg )#line:2510
					O00O0OO0000OOOOOO .getControl (O00O0OO0000OOOOOO .msg ).setText (wiz .highlightText (O0OOO0OOO000OO0OO ))#line:2511
					O00O0OO0000OOOOOO .setFocusId (O00O0OO0000OOOOOO .scrollbar )#line:2512
			elif O00O000O0O000O0O0 ==O00O0OO0000OOOOOO .kodiold :#line:2513
				O0OOO0OOO000OO0OO =wiz .Grab_Log (False ,True )#line:2514
				OO0OOOO00O0OOO0O0 =wiz .Grab_Log (True ,True )#line:2515
				if O0OOO0OOO000OO0OO ==False :#line:2516
					O00O0OO0000OOOOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:2517
					O00O0OO0000OOOOOO .getControl (O00O0OO0000OOOOOO .msg ).setText ("Log File Does Not Exists!")#line:2518
				else :#line:2519
					O00O0OO0000OOOOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OOOO00O0OOO0O0 .replace (LOG ,''))#line:2520
					O00O0OO0000OOOOOO .getControl (O00O0OO0000OOOOOO .title ).setLabel (O00O0OO0000OOOOOO .titlemsg )#line:2521
					O00O0OO0000OOOOOO .getControl (O00O0OO0000OOOOOO .msg ).setText (wiz .highlightText (O0OOO0OOO000OO0OO ))#line:2522
					O00O0OO0000OOOOOO .setFocusId (O00O0OO0000OOOOOO .scrollbar )#line:2523
			elif O00O000O0O000O0O0 ==O00O0OO0000OOOOOO .wizard :#line:2524
				O0OOO0OOO000OO0OO =wiz .Grab_Log (False ,False ,True )#line:2525
				OO0OOOO00O0OOO0O0 =wiz .Grab_Log (True ,False ,True )#line:2526
				if O0OOO0OOO000OO0OO ==False :#line:2527
					O00O0OO0000OOOOOO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:2528
					O00O0OO0000OOOOOO .getControl (O00O0OO0000OOOOOO .msg ).setText ("Log File Does Not Exists!")#line:2529
				else :#line:2530
					O00O0OO0000OOOOOO .titlemsg ="%s: %s"%(ADDONTITLE ,OO0OOOO00O0OOO0O0 .replace (ADDONDATA ,''))#line:2531
					O00O0OO0000OOOOOO .getControl (O00O0OO0000OOOOOO .title ).setLabel (O00O0OO0000OOOOOO .titlemsg )#line:2532
					O00O0OO0000OOOOOO .getControl (O00O0OO0000OOOOOO .msg ).setText (wiz .highlightText (O0OOO0OOO000OO0OO ))#line:2533
					O00O0OO0000OOOOOO .setFocusId (O00O0OO0000OOOOOO .scrollbar )#line:2534
		def onAction (OO00OOO00OOOO00O0 ,O000O0O00000O00O0 ):#line:2535
			if O000O0O00000O00O0 ==ACTION_PREVIOUS_MENU :OO00OOO00OOOO00O0 .close ()#line:2536
			elif O000O0O00000O00O0 ==ACTION_NAV_BACK :OO00OOO00OOOO00O0 .close ()#line:2537
	if default ==None :default =wiz .Grab_Log (True )#line:2538
	OOOO000O0O0OO0OO0 =O000O000O0O000OO0 ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:2539
	OOOO000O0O0OO0OO0 .doModal ()#line:2540
	del OOOO000O0O0OO0OO0 #line:2541
def removeAddon (O00OOO00OO0OOOOOO ,OOOO0O0OO0000O0OO ,over =False ):#line:2551
	if not over ==False :#line:2552
		O0000O0O00OO0OOOO =1 #line:2553
	else :#line:2554
		O0000O0O00OO0OOOO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOOO0O0OO0000O0OO ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O00OOO00OO0OOOOOO ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:2555
	if O0000O0O00OO0OOOO ==1 :#line:2556
		OO0OO00000000OOOO =os .path .join (ADDONS ,O00OOO00OO0OOOOOO )#line:2557
		wiz .log ("Removing Addon %s"%O00OOO00OO0OOOOOO )#line:2558
		wiz .cleanHouse (OO0OO00000000OOOO )#line:2559
		xbmc .sleep (200 )#line:2560
		try :shutil .rmtree (OO0OO00000000OOOO )#line:2561
		except Exception as O00O0O0OO0OOOO00O :wiz .log ("Error removing %s"%O00OOO00OO0OOOOOO ,xbmc .LOGNOTICE )#line:2562
		removeAddonData (O00OOO00OO0OOOOOO ,OOOO0O0OO0000O0OO ,over )#line:2563
	if over ==False :#line:2564
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOOO0O0OO0000O0OO ))#line:2565
def removeAddonData (O0OOO00OO00O00OO0 ,name =None ,over =False ):#line:2566
	if O0OOO00OO00O00OO0 =='all':#line:2567
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s] מידע ההרחבות מספריית היוזר דאטא- כל התפריטים ימחקו! [COLOR %s] כל [/COLOR]תהליך הסרת [/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]הסר מידע[/COLOR][/B]',nolabel ='[B][COLOR red]בטל הסרה[/COLOR][/B]'):#line:2568
			wiz .cleanHouse (ADDOND )#line:2569
		else :wiz .LogNotify ('[COLOR %s]הסרת נתוני הרחבות[/COLOR]'%COLOR1 ,'[COLOR %s] בוטלה![/COLOR]'%COLOR2 )#line:2570
	elif O0OOO00OO00O00OO0 =='uninstalled':#line:2571
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s] נתוני ההרחבות הלא פעילות מספריית היוזר דאטא?[COLOR %s] כל [/COLOR]  להסיר את  [/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]הסר מידע[/COLOR][/B]',nolabel ='[B][COLOR red]בטל הסרה[/COLOR][/B]'):#line:2572
			OOO000O0O0OO00O00 =0 #line:2573
			for OOOO0OOO0OOO00OOO in glob .glob (os .path .join (ADDOND ,'*')):#line:2574
				O00O00O0OOOO0O0OO =OOOO0OOO0OOO00OOO .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:2575
				if O00O00O0OOOO0O0OO in EXCLUDES :pass #line:2576
				elif os .path .exists (os .path .join (ADDONS ,O00O00O0OOOO0O0OO )):pass #line:2577
				else :wiz .cleanHouse (OOOO0OOO0OOO00OOO );OOO000O0O0OO00O00 +=1 ;wiz .log (OOOO0OOO0OOO00OOO );shutil .rmtree (OOOO0OOO0OOO00OOO )#line:2578
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,OOO000O0O0OO00O00 ))#line:2579
		else :wiz .LogNotify ('[COLOR %s]הסרת נתוני ההרחבות  [/COLOR]'%COLOR1 ,'[COLOR %s]בוטלה! [/COLOR]'%COLOR2 )#line:2580
	elif O0OOO00OO00O00OO0 =='empty':#line:2581
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]  ספריות ההרחבות הריקות מספריית היוזר דאטא?[COLOR %s] כל [/COLOR] האם להסיר את  [/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]הסר מידע[/COLOR][/B]',nolabel ='[B][COLOR red]בטל הסרה[/COLOR][/B]'):#line:2582
			OOO000O0O0OO00O00 =wiz .emptyfolder (ADDOND )#line:2583
			wiz .LogNotify ('[COLOR %s]מסיר ספריות ריקות [/COLOR]'%COLOR1 ,'[COLOR %s]%s ספריה/יות הוסרו[/COLOR]'%(COLOR2 ,OOO000O0O0OO00O00 ))#line:2584
		else :wiz .LogNotify ('[COLOR %s]הסרת ספריות ריקות [/COLOR]'%COLOR1 ,'[COLOR %s] בוטלה! [/COLOR]'%COLOR2 )#line:2585
	else :#line:2586
		O00OO0O0O0OO0OO00 =os .path .join (USERDATA ,'addon_data',O0OOO00OO00O00OO0 )#line:2587
		if O0OOO00OO00O00OO0 in EXCLUDES :#line:2588
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:2589
		elif os .path .exists (O00OO0O0O0OO0OO00 ):#line:2590
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,O0OOO00OO00O00OO0 ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:2591
				wiz .cleanHouse (O00OO0O0O0OO0OO00 )#line:2592
				try :#line:2593
					shutil .rmtree (O00OO0O0O0OO0OO00 )#line:2594
				except :#line:2595
					wiz .log ("Error deleting: %s"%O00OO0O0O0OO0OO00 )#line:2596
			else :#line:2597
				wiz .log ('Addon data for %s was not removed'%O0OOO00OO00O00OO0 )#line:2598
	wiz .refresh ()#line:2599
def restoreit (OOO0O0OOO00O0OOOO ):#line:2600
	if OOO0O0OOO00O0OOOO =='build':#line:2601
		O00OOOOO0OO0OOOOO =freshStart ('restore')#line:2602
		if O00OOOOO0OO0OOOOO ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:2603
	if not wiz .currSkin ()in ['skin.confluence','skin.estuary']:#line:2604
		wiz .skinToDefault ('Restore Backup')#line:2605
	wiz .restoreLocal (OOO0O0OOO00O0OOOO )#line:2606
def restoreextit (O000OOO000000O0O0 ):#line:2607
	if O000OOO000000O0O0 =='build':#line:2608
		O0OOO00OO000OOOO0 =freshStart ('restore')#line:2609
		if O0OOO00OO000OOOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:2610
	wiz .restoreExternal (O000OOO000000O0O0 )#line:2611
def buildInfo (O0OOO0OO0OOOO00OO ):#line:2612
	if wiz .workingURL (BUILDFILE )==True :#line:2613
		if wiz .checkBuild (O0OOO0OO0OOOO00OO ,'url'):#line:2614
			O0OOO0OO0OOOO00OO ,OOO0000000O000O00 ,OOO00OOO0OOO0O0OO ,OOOOO00O0OOOOO000 ,OOO0O00OO000OOO0O ,OO0O0O0OOO0O0OO0O ,O0OO0OO000O0O00O0 ,O0OO00OOO0OOOOO00 ,OO0O00000O0O0O00O ,O00OO0000O00OOOO0 ,OOOOOOOO000O0OOOO ,O000OO000OO0OOOO0 ,OOO0O0O0OO00O00O0 =wiz .checkBuild (O0OOO0OO0OOOO00OO ,'all')#line:2615
			OOOOOOOO000O0OOOO ='Yes'if OOOOOOOO000O0OOOO .lower ()=='yes'else 'No'#line:2616
			O00OO0O00OO00OO0O =False #line:2617
			if not O000OO000OO0OOOO0 =="http://":#line:2618
				try :#line:2619
					O0OOOO0OOOO0O0000 ,OOO00O0OO0000O0OO ,O000000O0OOO000OO ,O00OOOOO0OO00O0O0 ,O0OO00000O00000O0 ,O0OOO00O0O0OOOO00 ,OO000OOO0O000O0O0 ,OO000OOOOOOO0O00O ,OOOO00O00OO0OOO00 ,O000OOOOOO0OOOOO0 ,O0O0OOOOOOOO00O00 =wiz .checkInfo (O000OO000OO0OOOO0 )#line:2620
					O00OO0O00OO00OO0O =True #line:2621
				except :#line:2622
					O00OO0O00OO00OO0O =False #line:2623
			if O00OO0O00OO00OO0O ==True :#line:2624
				O0000O000000000O0 ="[COLOR %s]Build Name:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O0OOO0OO0OOOO00OO )#line:2625
				O0000O000000000O0 +="[COLOR %s]Build Version:[/COLOR] v[COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,OOO0000000O000O00 )#line:2626
				O0000O000000000O0 +="[COLOR %s]Latest Update:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O0OO00000O00000O0 )#line:2627
				if not O0OO0OO000O0O00O0 =="http://":#line:2628
					O0O00O0OO0O00O000 =wiz .themeCount (O0OOO0OO0OOOO00OO ,False )#line:2629
					O0000O000000000O0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0O00O0OO0O00O000 ))#line:2630
				O0000O000000000O0 +="[COLOR %s]Kodi Version:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,OO0O0O0OOO0O0OO0O )#line:2631
				O0000O000000000O0 +="[COLOR %s]Extracted -גודל[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,wiz .convertSize (int (float (OOO00O0OO0000O0OO ))))#line:2632
				O0000O000000000O0 +="[COLOR %s]Zip -גודל[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,wiz .convertSize (int (float (O000000O0OOO000OO ))))#line:2633
				O0000O000000000O0 +="[COLOR %s]Skin Name:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O00OOOOO0OO00O0O0 )#line:2634
				O0000O000000000O0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,OOOOOOOO000O0OOOO )#line:2635
				O0000O000000000O0 +="[COLOR %s]Description:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,OOO0O0O0OO00O00O0 )#line:2636
				O0000O000000000O0 +="[COLOR %s]Programs:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O0OOO00O0O0OOOO00 )#line:2637
				O0000O000000000O0 +="[COLOR %s]Video:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,OO000OOO0O000O0O0 )#line:2638
				O0000O000000000O0 +="[COLOR %s]Music:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,OO000OOOOOOO0O00O )#line:2639
				O0000O000000000O0 +="[COLOR %s]Pictures:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,OOOO00O00OO0OOO00 )#line:2640
				O0000O000000000O0 +="[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O000OOOOOO0OOOOO0 )#line:2641
				O0000O000000000O0 +="[COLOR %s]Scripts:[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,O0O0OOOOOOOO00O00 )#line:2642
			else :#line:2643
				O0000O000000000O0 ="[COLOR %s]Build Name:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OOO0OO0OOOO00OO )#line:2644
				O0000O000000000O0 +="[COLOR %s]Build Version:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0000000O000O00 )#line:2645
				if not O0OO0OO000O0O00O0 =="http://":#line:2646
					O0O00O0OO0O00O000 =wiz .themeCount (O0OOO0OO0OOOO00OO ,False )#line:2647
					O0000O000000000O0 +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (O0O00O0OO0O00O000 ))#line:2648
				O0000O000000000O0 +="[COLOR %s]Kodi Version:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0O0O0OOO0O0OO0O )#line:2649
				O0000O000000000O0 +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOOOOOOO000O0OOOO )#line:2650
				O0000O000000000O0 +="[COLOR %s]Description:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OOO0O0O0OO00O00O0 )#line:2651
			wiz .TextBox (ADDONTITLE ,O0000O000000000O0 )#line:2652
		else :wiz .log ("Invalid Build Name!")#line:2653
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:2654
def viewpack ():#line:2656
	OOOOO00O00OO0O0OO =wiz .workingURL (ADDONPACK )#line:2657
	if not OOOOO00O00OO0O0OO ==True :#line:2658
		addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2659
		addFile ('%s'%OOOOO00O00OO0O0OO ,'',themeit =THEME3 )#line:2660
		return #line:2661
	O0OOO0O0000O0O00O =wiz .openURL (ADDONPACK ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2662
	O0OO00O00O0000000 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0OOO0O0000O0O00O )#line:2663
	for OOOOOO0000OOOOO0O ,O000000O0O00O0O0O ,O0OO0OO0O0OOOO00O ,OO00O00OOOO000O0O ,OOO0O0OOO0O00OO00 in O0OO00O00O0000000 :#line:2664
		addFolder ('',OOOOOO0000OOOOO0O ,O000000O0O00O0O0O ,'addonpackwiz',O0OO0OO0O0OOOO00O ,OO00O00OOOO000O0O ,'')#line:2665
def addonpackwiz ():#line:2666
		O0000OO00OOO0000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the:'%COLOR2 ,'[COLOR %s]%s[/COLOR]?[/COLOR]'%(COLOR1 ,name ),nolabel ='[B]לא, בטל[/B]',yeslabel ='[B]Install[/B]')#line:2667
		if O0000OO00OOO0000O :#line:2668
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2669
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,name ),'','Please Wait')#line:2670
			OOOO0OO0OO00OOO00 =os .path .join (PACKAGES ,'pack.zip')#line:2671
			try :os .remove (OOOO0OO0OO00OOO00 )#line:2672
			except :pass #line:2673
			downloader .download (url ,OOOO0OO0OO00OOO00 ,DP )#line:2674
			xbmc .sleep (500 )#line:2675
			DP .update (0 ,"","Installing %s "%name )#line:2676
			OO000O0OO000OO0OO ='[COLOR %s][B]Installing Addon Pack:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,name )#line:2677
			DP .update (0 ,OO000O0OO000OO0OO ,'','Please Wait')#line:2678
			OO00O000000O0OOO0 ,OOO0OO00O0OOO000O ,OO000OO00O00OOOO0 =extract .all (OOOO0OO0OO00OOO00 ,HOME ,DP ,title =OO000O0OO000OO0OO )#line:2679
			wiz .log ('INSTALLED %s: [ERRORS:%s]'%(OO00O000000O0OOO0 ,OOO0OO00O0OOO000O ))#line:2680
			DP .close ()#line:2681
			O0000OO00OOO0000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Installed:'%COLOR2 ,'[COLOR %s]%s[/COLOR]?[/COLOR]'%(COLOR1 ,name ),'[COLOR green]Successfully[/COLOR]',nolabel ='[B]Reset[/B]',yeslabel ='[B]Force Close[/B]')#line:2683
			if O0000OO00OOO0000O ==1 :#line:2684
				wiz .killxbmc ('true')#line:2685
			elif O0000OO00OOO0000O ==0 :#line:2686
				wiz .RESET ()#line:2687
		else :#line:2688
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Addon Pack: Cancelled![/COLOR]'%COLOR2 )#line:2689
def dependsList (OO0O0OOO0OOOO0OO0 ):#line:2690
	O000O0O00OOOO0000 =os .path .join (ADDONS ,OO0O0OOO0OOOO0OO0 ,'addon.xml')#line:2691
	if os .path .exists (O000O0O00OOOO0000 ):#line:2692
		O00OOOO00O0OOO0OO =open (O000O0O00OOOO0000 ,mode ='r');OOOOOOOO00OOOO000 =O00OOOO00O0OOO0OO .read ();O00OOOO00O0OOO0OO .close ();#line:2693
		O000OOOO0O00000OO =wiz .parseDOM (OOOOOOOO00OOOO000 ,'import',ret ='addon')#line:2694
		O00OO00O00OO0OO00 =[]#line:2695
		for OO0O0O0O00OO0OOOO in O000OOOO0O00000OO :#line:2696
			if not 'xbmc.python'in OO0O0O0O00OO0OOOO :#line:2697
				O00OO00O00OO0OO00 .append (OO0O0O0O00OO0OOOO )#line:2698
		return O00OO00O00OO0OO00 #line:2699
	return []#line:2700
def manageSaveData (OOO00000OOOOOOOO0 ):#line:2701
	if OOO00000OOOOOOOO0 =='import':#line:2702
		O00OO000OO000OO0O =os .path .join (ADDONDATA ,'temp')#line:2703
		if not os .path .exists (O00OO000OO000OO0O ):os .makedirs (O00OO000OO000OO0O )#line:2704
		O0000OO0000OOO0OO =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:2705
		if not O0000OO0000OOO0OO .endswith ('.zip'):#line:2706
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:2707
			return #line:2708
		O0O0OOO00OO000O00 =os .path .join (MYBUILDS ,'SaveData.zip')#line:2709
		OO000000O0O000OO0 =xbmcvfs .copy (O0000OO0000OOO0OO ,O0O0OOO00OO000O00 )#line:2710
		wiz .log ("%s"%str (OO000000O0O000OO0 ))#line:2711
		extract .all (xbmc .translatePath (O0O0OOO00OO000O00 ),O00OO000OO000OO0O )#line:2712
		O0O0O00O0OO0OOOOO =os .path .join (O00OO000OO000OO0O ,'trakt')#line:2713
		OO0O000O0OO0O0O00 =os .path .join (O00OO000OO000OO0O ,'login')#line:2714
		O0O0OOO0O000O00O0 =os .path .join (O00OO000OO000OO0O ,'debrid')#line:2715
		O0000OOOOOOO0OO00 =0 #line:2716
		if os .path .exists (O0O0O00O0OO0OOOOO ):#line:2717
			O0000OOOOOOO0OO00 +=1 #line:2718
			O0OOO0O0O0OOOOOO0 =os .listdir (O0O0O00O0OO0OOOOO )#line:2719
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:2720
			for OO0O0OO0OOO0000OO in O0OOO0O0O0OOOOOO0 :#line:2721
				O00OO0000O00OOO0O =os .path .join (traktit .TRAKTFOLD ,OO0O0OO0OOO0000OO )#line:2722
				OOO00O00O0OO0O00O =os .path .join (O0O0O00O0OO0OOOOO ,OO0O0OO0OOO0000OO )#line:2723
				if os .path .exists (O00OO0000O00OOO0O ):#line:2724
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0O0OO0OOO0000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:2725
					else :os .remove (O00OO0000O00OOO0O )#line:2726
				shutil .copy (OOO00O00O0OO0O00O ,O00OO0000O00OOO0O )#line:2727
			traktit .importlist ('all')#line:2728
			traktit .traktIt ('restore','all')#line:2729
		if os .path .exists (OO0O000O0OO0O0O00 ):#line:2730
			O0000OOOOOOO0OO00 +=1 #line:2731
			O0OOO0O0O0OOOOOO0 =os .listdir (OO0O000O0OO0O0O00 )#line:2732
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:2733
			for OO0O0OO0OOO0000OO in O0OOO0O0O0OOOOOO0 :#line:2734
				O00OO0000O00OOO0O =os .path .join (loginit .LOGINFOLD ,OO0O0OO0OOO0000OO )#line:2735
				OOO00O00O0OO0O00O =os .path .join (OO0O000O0OO0O0O00 ,OO0O0OO0OOO0000OO )#line:2736
				if os .path .exists (O00OO0000O00OOO0O ):#line:2737
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0O0OO0OOO0000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:2738
					else :os .remove (O00OO0000O00OOO0O )#line:2739
				shutil .copy (OOO00O00O0OO0O00O ,O00OO0000O00OOO0O )#line:2740
			loginit .importlist ('all')#line:2741
			loginit .loginIt ('restore','all')#line:2742
		if os .path .exists (O0O0OOO0O000O00O0 ):#line:2743
			O0000OOOOOOO0OO00 +=1 #line:2744
			O0OOO0O0O0OOOOOO0 =os .listdir (O0O0OOO0O000O00O0 )#line:2745
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:2746
			for OO0O0OO0OOO0000OO in O0OOO0O0O0OOOOOO0 :#line:2747
				O00OO0000O00OOO0O =os .path .join (debridit .REALFOLD ,OO0O0OO0OOO0000OO )#line:2748
				OOO00O00O0OO0O00O =os .path .join (O0O0OOO0O000O00O0 ,OO0O0OO0OOO0000OO )#line:2749
				if os .path .exists (O00OO0000O00OOO0O ):#line:2750
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OO0O0OO0OOO0000OO ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:2751
					else :os .remove (O00OO0000O00OOO0O )#line:2752
				shutil .copy (OOO00O00O0OO0O00O ,O00OO0000O00OOO0O )#line:2753
			debridit .importlist ('all')#line:2754
			debridit .debridIt ('restore','all')#line:2755
		wiz .cleanHouse (O00OO000OO000OO0O )#line:2756
		wiz .removeFolder (O00OO000OO000OO0O )#line:2757
		os .remove (O0O0OOO00OO000O00 )#line:2758
		if O0000OOOOOOO0OO00 ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:2759
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:2760
	elif OOO00000OOOOOOOO0 =='export':#line:2761
		O00O00OOOOOOO0OO0 =xbmc .translatePath (MYBUILDS )#line:2762
		OO00O0000O00OO00O =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:2763
		traktit .traktIt ('update','all')#line:2764
		loginit .loginIt ('update','all')#line:2765
		debridit .debridIt ('update','all')#line:2766
		O0000OO0000OOO0OO =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:2767
		O0000OO0000OOO0OO =xbmc .translatePath (O0000OO0000OOO0OO )#line:2768
		O0O0O0O0000O0O0OO =os .path .join (O00O00OOOOOOO0OO0 ,'SaveData.zip')#line:2769
		OOOOOO00OO0O0000O =zipfile .ZipFile (O0O0O0O0000O0O0OO ,mode ='w')#line:2770
		for OOOOOO0O0OO0000OO in OO00O0000O00OO00O :#line:2771
			if os .path .exists (OOOOOO0O0OO0000OO ):#line:2772
				O0OOO0O0O0OOOOOO0 =os .listdir (OOOOOO0O0OO0000OO )#line:2773
				for O0OO0O0O0O0OOO0O0 in O0OOO0O0O0OOOOOO0 :#line:2774
					OOOOOO00OO0O0000O .write (os .path .join (OOOOOO0O0OO0000OO ,O0OO0O0O0O0OOO0O0 ),os .path .join (OOOOOO0O0OO0000OO ,O0OO0O0O0O0OOO0O0 ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:2775
		OOOOOO00OO0O0000O .close ()#line:2776
		if O0000OO0000OOO0OO ==O00O00OOOOOOO0OO0 :#line:2777
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O0O0000O0O0OO ))#line:2778
		else :#line:2779
			try :#line:2780
				xbmcvfs .copy (O0O0O0O0000O0O0OO ,os .path .join (O0000OO0000OOO0OO ,'SaveData.zip'))#line:2781
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O0000OO0000OOO0OO ,'SaveData.zip')))#line:2782
			except :#line:2783
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O0O0O0O0000O0O0OO ))#line:2784
def freshStart (install =None ,over =False ):#line:2788
	if KEEPTRAKT =='true':#line:2789
		traktit .autoUpdate ('all')#line:2790
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:2791
	if KEEPREAL =='true':#line:2792
		debridit .autoUpdate ('all')#line:2793
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:2794
	if KEEPLOGIN =='true':#line:2795
		loginit .autoUpdate ('all')#line:2796
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:2797
	if over ==True :O00OO0OO00O0O0O0O =1 #line:2798
	elif install =='restore':O00OO0OO00O0O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]  [B][COLOR springgreen] -  עליך לאשר  - [/COLOR][/B]"%COLOR2 ,"מחיקת בילד נוכחי ולאחר מכן שחזר  מקובץ [/COLOR]",nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR springgreen]אשר[/COLOR][/B]')#line:2799
	elif install :O00OO0OO00O0O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s] [B][COLOR springgreen] שים לב!  [/COLOR][/B]"%COLOR2 ,"יותקן כעת לאחר מחיקה של קבצי הקודי הנוכחים  [COLOR %s]%s[/COLOR]!!!"%(COLOR1 ,install ),nolabel ='[B][COLOR red]לא, בטל [/COLOR][/B]',yeslabel ='[B][COLOR springgreen]כן, המשך [/COLOR][/B]')#line:2800
	else :O00OO0OO00O0O0O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Do you wish to restore your"%COLOR2 ,"Configuration to default settings?[/COLOR]",nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR springgreen]Yes[/COLOR][/B]')#line:2801
	if O00OO0OO00O0O0O0O :#line:2802
		if 0:#not wiz .currSkin ()in ['skin.confluence','skin.estuary','skin.pellucid','skin.myconfluence','skin.estuary','skin.eminence.2.mod','skin.aeon.nox.silvo','skin.phenomenal']:#line:2803
			OOOO0O000OO0O0OO0 ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.eminence.2.mod'if KODIV <17 else 'skin.myconfluence'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.aeon.nox.silvo'if KODIV <17 else 'skin.pellucid'#line:2804
			skinSwitch .swapSkins (OOOO0O000OO0O0OO0 )#line:2807
			O0OOO0OO00O00O000 =0 #line:2808
			xbmc .sleep (1000 )#line:2809
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O0OOO0OO00O00O000 <150 :#line:2810
				O0OOO0OO00O00O000 +=1 #line:2811
				xbmc .sleep (200 )#line:2812
				wiz .ebi ('SendAction(Select)')#line:2813
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:2814
				wiz .ebi ('SendClick(11)')#line:2815
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: תם זמן החלפת מעטפת [/COLOR]'%COLOR2 );return False #line:2816
			xbmc .sleep (1000 )#line:2817
		if 0:#not wiz .currSkin ()in ['skin.confluence','skin.estuary','skin.pellucid','skin.estuary','skin.eminence.2.mod','skin.aeon.nox.silvo','skin.phenomenal']:#line:2818
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: החלפה נכשלה[/COLOR]'%COLOR2 )#line:2819
			return #line:2820
		wiz .addonUpdates ('set')#line:2821
		OOO00O0O0O000OOO0 =os .path .abspath (HOME )#line:2822
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים וספריות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:2823
		OO00OO0O000O0OOOO =sum ([len (OOOOO000O0OOOO00O )for O00OO000OO0O00O0O ,OOO00O000000O00O0 ,OOOOO000O0OOOO00O in os .walk (OOO00O0O0O000OOO0 )]);O000OO0O0O0OO000O =0 #line:2824
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:2825
		EXCLUDES .append ('My_Builds')#line:2826
		EXCLUDES .append ('archive_cache')#line:2827
		if KEEPREPOS =='true':#line:2828
			OO0OOO00OOO0000OO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:2829
			for OOOOOOO0O0O0OO0OO in OO0OOO00OOO0000OO :#line:2830
				OOOOOO0O0OO00OO00 =os .path .split (OOOOOOO0O0O0OO0OO [:-1 ])[1 ]#line:2831
				if not OOOOOO0O0OO00OO00 ==EXCLUDES :#line:2832
					EXCLUDES .append (OOOOOO0O0OO00OO00 )#line:2833
		if KEEPSUPER =='true':#line:2834
			EXCLUDES .append ('plugin.program.super.favourites')#line:2835
		if KEEPWHITELIST =='true':#line:2836
			OO0O0OOO0OOOOOO00 =''#line:2837
			O0O0000O00O0OO0O0 =wiz .whiteList ('read')#line:2838
			if len (O0O0000O00O0OO0O0 )>0 :#line:2839
				for OOOOOOO0O0O0OO0OO in O0O0000O00O0OO0O0 :#line:2840
					try :O0O00O0O00O0OOOOO ,OO00OO0OO0O0OOO00 ,OO000OOOO0O00OO0O =OOOOOOO0O0O0OO0OO #line:2841
					except :pass #line:2842
					if OO000OOOO0O00OO0O .startswith ('pvr'):OO0O0OOO0OOOOOO00 =OO00OO0OO0O0OOO00 #line:2843
					OO0OO0O0O0O00OOOO =dependsList (OO000OOOO0O00OO0O )#line:2844
					for O00OO00OO000O0000 in OO0OO0O0O0O00OOOO :#line:2845
						if not O00OO00OO000O0000 in EXCLUDES :#line:2846
							EXCLUDES .append (O00OO00OO000O0000 )#line:2847
						O00O00OOOO0O0O0OO =dependsList (O00OO00OO000O0000 )#line:2848
						for OO0OOO000O00O0O00 in O00O00OOOO0O0O0OO :#line:2849
							if not OO0OOO000O00O0O00 in EXCLUDES :#line:2850
								EXCLUDES .append (OO0OOO000O00O0O00 )#line:2851
					if not OO000OOOO0O00OO0O in EXCLUDES :#line:2852
						EXCLUDES .append (OO000OOOO0O00OO0O )#line:2853
				if not OO0O0OOO0OOOOOO00 =='':wiz .setS ('pvrclient',OO000OOOO0O00OO0O )#line:2854
		if wiz .getS ('pvrclient')=='':#line:2855
			for OOOOOOO0O0O0OO0OO in EXCLUDES :#line:2856
				if OOOOOOO0O0O0OO0OO .startswith ('pvr'):#line:2857
					wiz .setS ('pvrclient',OOOOOOO0O0O0OO0OO )#line:2858
		DP .update (0 ,"[COLOR %s] מנקה קבצים וספריות"%COLOR2 )#line:2859
		O00OOOOO0OO00O000 =wiz .latestDB ('Addons')#line:2860
		for O0OOOOO00O0OO0000 ,O0O000O0OOOOOOO0O ,O000O00000000OOOO in os .walk (OOO00O0O0O000OOO0 ,topdown =True ):#line:2861
			O0O000O0OOOOOOO0O [:]=[OOOOOO000OOO00000 for OOOOOO000OOO00000 in O0O000O0OOOOOOO0O if OOOOOO000OOO00000 not in EXCLUDES ]#line:2862
			for O0O00O0O00O0OOOOO in O000O00000000OOOO :#line:2863
				O000OO0O0O0OO000O +=1 #line:2864
				OO000OOOO0O00OO0O =O0OOOOO00O0OO0000 .replace ('/','\\').split ('\\')#line:2865
				O0OOO0OO00O00O000 =len (OO000OOOO0O00OO0O )-1 #line:2866
				if O0O00O0O00O0OOOOO =='sources.xml'and OO000OOOO0O00OO0O [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (O0OOOOO00O0OO0000 ,O0O00O0O00O0OOOOO ),xbmc .LOGNOTICE )#line:2867
				elif O0O00O0O00O0OOOOO =='favourites.xml'and OO000OOOO0O00OO0O [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (O0OOOOO00O0OO0000 ,O0O00O0O00O0OOOOO ),xbmc .LOGNOTICE )#line:2868
				elif O0O00O0O00O0OOOOO =='profiles.xml'and OO000OOOO0O00OO0O [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (O0OOOOO00O0OO0000 ,O0O00O0O00O0OOOOO ),xbmc .LOGNOTICE )#line:2869
				elif O0O00O0O00O0OOOOO =='advancedsettings.xml'and OO000OOOO0O00OO0O [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (O0OOOOO00O0OO0000 ,O0O00O0O00O0OOOOO ),xbmc .LOGNOTICE )#line:2870
				elif O0O00O0O00O0OOOOO in LOGFILES :wiz .log ("Keep Log File: %s"%O0O00O0O00O0OOOOO ,xbmc .LOGNOTICE )#line:2871
				elif O0O00O0O00O0OOOOO .endswith ('.db'):#line:2872
					try :#line:2873
						if O0O00O0O00O0OOOOO ==O00OOOOO0OO00O000 and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(O0O00O0O00O0OOOOO ,KODIV ),xbmc .LOGNOTICE )#line:2874
						else :os .remove (os .path .join (O0OOOOO00O0OO0000 ,O0O00O0O00O0OOOOO ))#line:2875
					except Exception as OO0OOO0000O0OO0O0 :#line:2876
						if not O0O00O0O00O0OOOOO .startswith ('Textures13'):#line:2877
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:2878
							wiz .log ("-> %s"%(str (OO0OOO0000O0OO0O0 )),xbmc .LOGNOTICE )#line:2879
							wiz .purgeDb (os .path .join (O0OOOOO00O0OO0000 ,O0O00O0O00O0OOOOO ))#line:2880
				else :#line:2881
					DP .update (int (wiz .percentage (O000OO0O0O0OO000O ,OO00OO0O000O0OOOO )),'','[COLOR %s] קובץ [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O00O0O00O0OOOOO ),'')#line:2882
					try :os .remove (os .path .join (O0OOOOO00O0OO0000 ,O0O00O0O00O0OOOOO ))#line:2883
					except Exception as OO0OOO0000O0OO0O0 :#line:2884
						wiz .log ("Error removing %s"%os .path .join (O0OOOOO00O0OO0000 ,O0O00O0O00O0OOOOO ),xbmc .LOGNOTICE )#line:2885
						wiz .log ("-> / %s"%(str (OO0OOO0000O0OO0O0 )),xbmc .LOGNOTICE )#line:2886
			if DP .iscanceled ():#line:2887
				DP .close ()#line:2888
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Fresh Start Cancelled[/COLOR]"%COLOR2 )#line:2889
				return False #line:2890
		for O0OOOOO00O0OO0000 ,O0O000O0OOOOOOO0O ,O000O00000000OOOO in os .walk (OOO00O0O0O000OOO0 ,topdown =True ):#line:2891
			O0O000O0OOOOOOO0O [:]=[OOO000O00OOOO0O00 for OOO000O00OOOO0O00 in O0O000O0OOOOOOO0O if OOO000O00OOOO0O00 not in EXCLUDES ]#line:2892
			for O0O00O0O00O0OOOOO in O0O000O0OOOOOOO0O :#line:2893
				DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,O0O00O0O00O0OOOOO ),'')#line:2894
				if O0O00O0O00O0OOOOO not in ["Database","userdata","temp","addons","addon_data"]:#line:2895
					shutil .rmtree (os .path .join (O0OOOOO00O0OO0000 ,O0O00O0O00O0OOOOO ),ignore_errors =True ,onerror =None )#line:2896
			if DP .iscanceled ():#line:2897
				DP .close ()#line:2898
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Fresh Start Cancelled[/COLOR]"%COLOR2 )#line:2899
				return False #line:2900
		DP .close ()#line:2901
		wiz .clearS ('build')#line:2902
		if over ==True :#line:2903
			return True #line:2904
		elif install =='restore':#line:2905
			return True #line:2906
		elif install :#line:2907
			buildWizard (install ,'normal',over =True )#line:2908
		else :#line:2909
			if INSTALLMETHOD ==1 :OOOO0O000O00000O0 =1 #line:2910
			elif INSTALLMETHOD ==2 :OOOO0O000O00000O0 =0 #line:2911
			else :OOOO0O000O00000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]You Need To [COLOR %s]Force close[/COLOR] This App [COLOR %s]And[/COLOR] Then Restart It Again[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR white]>>>>>>[/COLOR][/B]",nolabel ="[B][COLOR springgreen]Force Close[/COLOR][/B]")#line:2912
			if OOOO0O000O00000O0 ==1 :wiz .reloadFix ('fresh')#line:2913
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:2914
	else :#line:2915
		if not install =='restore':#line:2916
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Fresh Install: Cancelled![/COLOR]'%COLOR2 )#line:2917
			wiz .refresh ()#line:2918
def clearCache ():#line:2924
	if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]האם לנקות זכרון מטמון?[/COLOR]'%COLOR2 ,nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]נקה מטמון[/COLOR][/B]'):#line:2925
		wiz .clearCache ()#line:2926
		DC .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2927
def clearArchive ():#line:2928
	if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]האם תרצה לנקות את ספריית  \'Archive_Cache\' [/COLOR]'%COLOR2 ,nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]כן נקה[/COLOR][/B]'):#line:2929
		wiz .clearArchive ()#line:2930
def clearPackages ():#line:2931
	if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]האם למחוק את חבילות ההתקנה?[/COLOR]'%COLOR2 ,nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]מחק[/COLOR][/B]'):#line:2932
		wiz .clearPackages ('total')#line:2933
		DPK .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2934
		TPK .setLabel ('-קבצים  [B][COLOR lime]0[/B][/COLOR]')#line:2935
def totalClean ():#line:2937
	if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]האם לנקות  תמונות, חבילות ומטמון?[/COLOR]'%COLOR2 ,nolabel ='[B][COLOR red]בטל תהליך[/COLOR][/B]',yeslabel ='[B][COLOR green]נקה הכל[/COLOR][/B]'):#line:2938
		wiz .clearCache ()#line:2939
		wiz .clearPackages ('total')#line:2940
		clearThumb ('total')#line:2941
		TC .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2942
		DC .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2943
		DPK .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2944
		TPK .setLabel ('-קבצים  [B][COLOR lime]0[/B][/COLOR]')#line:2945
		DTH .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2946
		TTH .setLabel ('-קבצים  [B][COLOR lime]0[/B][/COLOR]')#line:2947
def clearThumb (type =None ):#line:2948
	O0OO0000O00000OO0 =wiz .latestDB ('Textures')#line:2949
	if not type ==None :OO000OOOOOO000OO0 =1 #line:2950
	else :OO000OOOOOO000OO0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]האם תרצה למחוק את  %s ואת ספריית התמונות? '%(COLOR2 ,O0OO0000O00000OO0 ),"הם ימוקמו מחדש לאחר הפעלה. [/COLOR]",nolabel ='[B][COLOR red]אל תמחק[/COLOR][/B]',yeslabel ='[B][COLOR green]מחק קבצים[/COLOR][/B]')#line:2951
	if OO000OOOOOO000OO0 ==1 :#line:2952
		try :wiz .removeFile (os .join (DATABASE ,O0OO0000O00000OO0 ))#line:2953
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0OO0000O00000OO0 )#line:2954
		wiz .removeFolder (THUMBS )#line:2955
		DTH .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2956
		TTH .setLabel ('-קבצים  [B][COLOR lime]0[/B][/COLOR]')#line:2957
	else :wiz .log ('Clear thumbnames cancelled')#line:2958
	wiz .redoThumbs ()#line:2959
def purgeDb ():#line:2960
	OO0OO0O000O0O00O0 =[];O0O0OO00OO00OO0OO =[]#line:2961
	for O0O000OOO0O0OOO00 ,O0OO00OOO0OO0O0O0 ,OOO000000000O0000 in os .walk (HOME ):#line:2962
		for OO0OOOOO0OOOOO00O in fnmatch .filter (OOO000000000O0000 ,'*.db'):#line:2963
			if OO0OOOOO0OOOOO00O !='Thumbs.db':#line:2964
				OO000O000O000OOOO =os .path .join (O0O000OOO0O0OOO00 ,OO0OOOOO0OOOOO00O )#line:2965
				OO0OO0O000O0O00O0 .append (OO000O000O000OOOO )#line:2966
				O00O0OOOO0OO0OOOO =OO000O000O000OOOO .replace ('\\','/').split ('/')#line:2967
				O0O0OO00OO00OO0OO .append ('(%s) %s'%(O00O0OOOO0OO0OOOO [len (O00O0OOOO0OO0OOOO )-2 ],O00O0OOOO0OO0OOOO [len (O00O0OOOO0OO0OOOO )-1 ]))#line:2968
	if KODIV >=16 :#line:2969
		OO0O0OO00O000OOO0 =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O0OO00OO00OO0OO )#line:2970
		if OO0O0OO00O000OOO0 ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:2971
		elif len (OO0O0OO00O000OOO0 )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:2972
		else :#line:2973
			for OOO00OO00OOO0000O in OO0O0OO00O000OOO0 :wiz .purgeDb (OO0OO0O000O0O00O0 [OOO00OO00OOO0000O ])#line:2974
	else :#line:2975
		OO0O0OO00O000OOO0 =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O0OO00OO00OO0OO )#line:2976
		if OO0O0OO00O000OOO0 ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:2977
		else :wiz .purgeDb (OO0OO0O000O0O00O0 [OOO00OO00OOO0000O ])#line:2978
def Add_Directory_Item (OOOOOOOOOO0O0OO00 ,O00000OO0O0OOO0OO ,O00O0O0OOO0OO0OO0 ,O0OO0O0O0000000OO ):#line:3007
	xbmcplugin .addDirectoryItem (OOOOOOOOOO0O0OO00 ,O00000OO0O0OOO0OO ,O00O0O0OOO0OO0OO0 ,O0OO0O0O0000000OO )#line:3008
def addDir2 (O0O000OO0O0OOOOO0 ,OO00O0OOO0000O000 ,O000OO00O00OO0000 ,O00OOOO0O0O0OOOOO ,O0O0O000000OO0000 ):#line:3009
		O000OO000O0000OOO =sys .argv [0 ]+"?url="+urllib .quote_plus (OO00O0OOO0000O000 )+"&mode="+str (O000OO00O00OO0000 )+"&name="+urllib .quote_plus (O0O000OO0O0OOOOO0 )+"&iconimage="+urllib .quote_plus (O00OOOO0O0O0OOOOO )#line:3010
		OOO0000OO00O0OOO0 =True #line:3011
		OOOOO00O0O00O0O0O =xbmcgui .ListItem (O0O000OO0O0OOOOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =O00OOOO0O0O0OOOOO )#line:3012
		OOOOO00O0O00O0O0O .setInfo (type ="Video",infoLabels ={"Title":O0O000OO0O0OOOOO0 ,"Plot":O0O000OO0O0OOOOO0 })#line:3013
		OOOOO00O0O00O0O0O .setProperty ('fanart_image',O0O0O000000OO0000 )#line:3014
		OOO0000OO00O0OOO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000OO000O0000OOO ,listitem =OOOOO00O0O00O0O0O ,isFolder =True )#line:3015
		return OOO0000OO00O0OOO0 #line:3016
def addFolder (OO0O0OO0O00000OOO ,O00000000O0000OO0 ,OO00OO000O00O00O0 ,O0OO000000O0O0O0O ,iconimage ='',FanArt ='',video ='',description =''):#line:3017
	if OO0O0OO0O00000OOO !='folder2'and OO0O0OO0O00000OOO !='addon':#line:3018
		if len (iconimage )>0 :#line:3019
			iconimage =Images +iconimage #line:3020
		else :#line:3021
			iconimage ='DefaultFolder.png'#line:3022
	if OO0O0OO0O00000OOO =='addon':#line:3023
		if len (iconimage )>0 :#line:3024
			iconimage =iconimage #line:3025
		else :#line:3026
			iconimage ='none'#line:3027
	if FanArt =='':#line:3028
		FanArt =FanArt #line:3029
	O0000OO000OOO0000 =sys .argv [0 ]+"?url="+urllib .quote_plus (OO00OO000O00O00O0 )+"&mode="+str (O0OO000000O0O0O0O )+"&name="+urllib .quote_plus (O00000000O0000OO0 )+"&FanArt="+urllib .quote_plus (FanArt )+"&video="+urllib .quote_plus (video )+"&description="+urllib .quote_plus (description )#line:3030
	OOO00OO0O0O0O0O0O =True #line:3031
	OO000O0O00OOO00OO =xbmcgui .ListItem (O00000000O0000OO0 ,iconImage ="DefaultFolder.png",thumbnailImage =iconimage )#line:3032
	OO000O0O00OOO00OO .setInfo (type ="Video",infoLabels ={"Title":O00000000O0000OO0 ,"Plot":description })#line:3033
	OO000O0O00OOO00OO .setProperty ("FanArt_Image",FanArt )#line:3034
	OO000O0O00OOO00OO .setProperty ("Build.Video",video )#line:3035
	if (OO0O0OO0O00000OOO =='folder')or (OO0O0OO0O00000OOO =='folder2')or (OO0O0OO0O00000OOO =='tutorial_folder')or (OO0O0OO0O00000OOO =='news_folder'):#line:3036
		OOO00OO0O0O0O0O0O =Add_Directory_Item (handle =int (sys .argv [1 ]),url =O0000OO000OOO0000 ,listitem =OO000O0O00OOO00OO ,isFolder =True )#line:3037
	else :#line:3038
		OOO00OO0O0O0O0O0O =Add_Directory_Item (handle =int (sys .argv [1 ]),url =O0000OO000OOO0000 ,listitem =OO000O0O00OOO00OO ,isFolder =False )#line:3039
	return OOO00OO0O0O0O0O0O #line:3040
def addDir (O000000O0O00OOOO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:3041
	OOOOO00O000O00O00 =sys .argv [0 ]#line:3042
	if not mode ==None :OOOOO00O000O00O00 +="?mode=%s"%urllib .quote_plus (mode )#line:3043
	if not name ==None :OOOOO00O000O00O00 +="&name="+urllib .quote_plus (name )#line:3044
	if not url ==None :OOOOO00O000O00O00 +="&url="+urllib .quote_plus (url )#line:3045
	O00OO0OOOOO0O00OO =True #line:3046
	if themeit :O000000O0O00OOOO0 =themeit %O000000O0O00OOOO0 #line:3047
	OO0000OO00O000OOO =xbmcgui .ListItem (O000000O0O00OOOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:3048
	OO0000OO00O000OOO .setInfo (type ="Video",infoLabels ={"Title":O000000O0O00OOOO0 ,"Plot":description })#line:3049
	OO0000OO00O000OOO .setProperty ("Fanart_Image",fanart )#line:3050
	if not menu ==None :OO0000OO00O000OOO .addContextMenuItems (menu ,replaceItems =overwrite )#line:3051
	O00OO0OOOOO0O00OO =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOOOO00O000O00O00 ,listitem =OO0000OO00O000OOO ,isFolder =True )#line:3052
	return O00OO0OOOOO0O00OO #line:3053
def addFile (O0OOOO00O00O0OOO0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:3054
    logging.warning(mode)
    OOO0O0000OO0O0O0O =sys .argv [0 ]#line:3055
    if not mode ==None :OOO0O0000OO0O0O0O +="?mode=%s"%urllib .quote_plus (mode )#line:3056
    if not name ==None :OOO0O0000OO0O0O0O +="&name="+urllib .quote_plus (name )#line:3057
    if not url ==None :OOO0O0000OO0O0O0O +="&url="+urllib .quote_plus (url )#line:3058
    O00O0O000OOOO000O =True #line:3059
    if themeit :O0OOOO00O00O0OOO0 =themeit %O0OOOO00O00O0OOO0 #line:3060
    OO000O0O0000OOO00 =xbmcgui .ListItem (O0OOOO00O00O0OOO0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:3061
    OO000O0O0000OOO00 .setInfo (type ="Video",infoLabels ={"Title":O0OOOO00O00O0OOO0 ,"Plot":description })#line:3062
    OO000O0O0000OOO00 .setProperty ("Fanart_Image",fanart )#line:3063
    if not menu ==None :OO000O0O0000OOO00 .addContextMenuItems (menu ,replaceItems =overwrite )#line:3064
    O00O0O000OOOO000O =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO0O0000OO0O0O0O ,listitem =OO000O0O0000OOO00 ,isFolder =False )#line:3065
    return O00O0O000OOOO000O #line:3066
def get_params ():#line:3067
	OO0OO0O0OO000OOO0 =[]#line:3068
	OOO0OO0OO00OOOOOO =sys .argv [2 ]#line:3069
	if len (OOO0OO0OO00OOOOOO )>=2 :#line:3070
		OOOO00O0OOO0O00O0 =sys .argv [2 ]#line:3071
		O00OO0O00O0O0O000 =OOOO00O0OOO0O00O0 .replace ('?','')#line:3072
		if (OOOO00O0OOO0O00O0 [len (OOOO00O0OOO0O00O0 )-1 ]=='/'):#line:3073
			OOOO00O0OOO0O00O0 =OOOO00O0OOO0O00O0 [0 :len (OOOO00O0OOO0O00O0 )-2 ]#line:3074
		OOOOO0O0OOOO0OOOO =O00OO0O00O0O0O000 .split ('&')#line:3075
		OO0OO0O0OO000OOO0 ={}#line:3076
		for OOOOO0OO0OO0000O0 in range (len (OOOOO0O0OOOO0OOOO )):#line:3077
			OO00O0000O00000O0 ={}#line:3078
			OO00O0000O00000O0 =OOOOO0O0OOOO0OOOO [OOOOO0OO0OO0000O0 ].split ('=')#line:3079
			if (len (OO00O0000O00000O0 ))==2 :#line:3080
				OO0OO0O0OO000OOO0 [OO00O0000O00000O0 [0 ]]=OO00O0000O00000O0 [1 ]#line:3081
		return OO0OO0O0OO000OOO0 #line:3082
if len (sys .argv )>1 :#line:3083
    params =get_params ()#line:3084
url =None #line:3085
name =None #line:3086
mode =None #line:3087
try :mode =urllib .unquote_plus (params ["mode"])#line:3088
except :pass #line:3089
try :name =urllib .unquote_plus (params ["name"])#line:3090
except :pass #line:3091
try :url =urllib .unquote_plus (params ["url"])#line:3092
except :pass #line:3093
def setView (OO000000O0OOOO000 ,OO0OOOO00O0OO0OO0 ):#line:3095
	if wiz .getS ('auto-view')=='true':#line:3096
		OOO0OO0O000OOO0O0 =wiz .getS (OO0OOOO00O0OO0OO0 )#line:3097
		if OOO0OO0O000OOO0O0 =='50'and KODIV >=17 and SKIN =='skin.estuary':OOO0OO0O000OOO0O0 ='55'#line:3098
		if OOO0OO0O000OOO0O0 =='500'and KODIV >=17 and SKIN =='skin.estuary':OOO0OO0O000OOO0O0 ='50'#line:3099
		wiz .ebi ("Container.SetViewMode(%s)"%OOO0OO0O000OOO0O0 )#line:3100
wiz .FTGlog ('<Must remain to get any support>')#line:3108
FOCUS_BUTTON_COLOR =uservar .FOCUS_BUTTON_COLOR #line:3109
DESCOLOR =uservar .DESCOLOR #line:3110
DES_T_COLOR =uservar .DES_T_COLOR #line:3111
MAIN_BUTTONS_TEXT =uservar .MAIN_BUTTONS_TEXT #line:3112
OTHER_BUTTONS_TEXT =uservar .OTHER_BUTTONS_TEXT #line:3113
LIST_TEXT =uservar .LIST_TEXT #line:3114
HIGHLIGHT_LIST =uservar .HIGHLIGHT_LIST #line:3115
net =net .Net ()#line:3117
window =pyxbmct .AddonDialogWindow ('')#line:3118
EXIT =os .path .join (ART ,'%s.png'%uservar .EXIT_BUTTON_COLOR )#line:3119
FBUTTON =os .path .join (ART ,'%s.png'%FOCUS_BUTTON_COLOR )#line:3120
LBUTTON =os .path .join (ART ,'%s.png'%HIGHLIGHT_LIST )#line:3121
BUTTON =os .path .join (ART ,'button.png')#line:3122
LISTBG =os .path .join (ART ,'listbg.png')#line:3123
SPLASH =os .path .join (ART ,'splash.jpg')#line:3124
SpeedBG =os .path .join (ART ,'speedtest.jpg')#line:3125
MAINBG =os .path .join (ART ,'main.jpg')#line:3126
NOTXT =os .path .join (ART ,'%s.gif'%uservar .NO_TXT_FILE )#line:3127
def playVideoB (OOO0O0O0O0O00OO00 ):#line:3150
	if 'watch?v='in OOO0O0O0O0O00OO00 :#line:3151
		OOO0OO00OOO00OO0O ,OOOOOO00000O000OO =OOO0O0O0O0O00OO00 .split ('?')#line:3152
		O0OOO00O000O000OO =OOOOOO00000O000OO .split ('&')#line:3153
		for OOO0O00O00000O000 in O0OOO00O000O000OO :#line:3154
			if OOO0O00O00000O000 .startswith ('v='):#line:3155
				OOO0O0O0O0O00OO00 =OOO0O00O00000O000 [2 :]#line:3156
				break #line:3157
			else :continue #line:3158
	elif 'embed'in OOO0O0O0O0O00OO00 or 'youtu.be'in OOO0O0O0O0O00OO00 :#line:3159
		OOO0OO00OOO00OO0O =OOO0O0O0O0O00OO00 .split ('/')#line:3160
		if len (OOO0OO00OOO00OO0O [-1 ])>5 :#line:3161
			OOO0O0O0O0O00OO00 =OOO0OO00OOO00OO0O [-1 ]#line:3162
		elif len (OOO0OO00OOO00OO0O [-2 ])>5 :#line:3163
			OOO0O0O0O0O00OO00 =OOO0OO00OOO00OO0O [-2 ]#line:3164
	wiz .log ("YouTube URL: %s"%OOO0O0O0O0O00OO00 )#line:3165
	notify .Preview (OOO0O0O0O0O00OO00 )#line:3166
def runspeedtest ():#line:3168
	O00000OOOO000OO0O =speedtest .speedtest ()#line:3169
	speedthumb .setImage (O00000OOOO000OO0O [0 ])#line:3170
def HIDEALL ():#line:3172
	try :#line:3173
		InstallButtonROM .setVisible (False )#line:3174
	except :pass #line:3175
	try :#line:3176
		InstallButtonEMU .setVisible (False )#line:3177
	except :pass #line:3178
	try :#line:3179
		no_txt .setVisible (False )#line:3180
	except :pass #line:3181
	try :#line:3182
		splash .setVisible (False )#line:3183
	except :pass #line:3184
	try :#line:3185
		AddonButton .setVisible (False )#line:3186
	except :pass #line:3187
	try :#line:3188
		APKButton .setVisible (False )#line:3189
	except :pass #line:3190
	try :#line:3191
		ROMButton .setVisible (False )#line:3192
	except :pass #line:3193
	try :#line:3194
		EmuButton .setVisible (False )#line:3195
	except :pass #line:3196
	try :#line:3197
		InstallButton .setVisible (False )#line:3198
	except :pass #line:3199
	try :#line:3200
		FreshStartButton .setVisible (False )#line:3201
	except :pass #line:3202
	try :#line:3203
		listbg .setVisible (False )#line:3204
	except :pass #line:3205
	try :#line:3206
		no_txt .setVisible (False )#line:3207
	except :pass #line:3208
	try :#line:3209
		splash .setVisible (False )#line:3210
	except :pass #line:3211
	try :#line:3212
		speedthumb .setVisible (False )#line:3213
	except :pass #line:3214
	try :#line:3215
		buildlist .setVisible (False )#line:3216
	except :pass #line:3217
	try :#line:3218
		PreviewButton .setVisible (False )#line:3219
	except :pass #line:3220
	try :#line:3221
		ThemeButton .setVisible (False )#line:3222
	except :pass #line:3223
	try :#line:3224
		buildinfobg .setVisible (False )#line:3225
	except :pass #line:3226
	try :#line:3227
		buildbg .setVisible (False )#line:3228
	except :pass #line:3229
	try :#line:3230
		buildthumb .setVisible (False )#line:3231
	except :pass #line:3232
	try :#line:3233
		buildtextbox .setVisible (False )#line:3234
	except :pass #line:3235
	try :#line:3236
		vertextbox .setVisible (False )#line:3237
	except :pass #line:3238
	try :#line:3239
		koditextbox .setVisible (False )#line:3240
	except :pass #line:3241
	try :#line:3242
		desctextbox .setVisible (False )#line:3243
	except :pass #line:3244
	try :#line:3245
		addthumb .setVisible (False )#line:3246
	except :pass #line:3247
	try :#line:3248
		InstallButtonA .setVisible (False )#line:3249
	except :pass #line:3250
	try :#line:3251
		addonlist .setVisible (False )#line:3252
	except :pass #line:3253
	try :#line:3254
		addthumb .setVisible (False )#line:3255
	except :pass #line:3256
	try :#line:3257
		desctextboxA .setVisible (False )#line:3258
	except :pass #line:3259
	try :#line:3260
		addtextbox .setVisible (False )#line:3261
	except :pass #line:3262
	try :#line:3263
		listbgA .setVisible (False )#line:3264
	except :pass #line:3265
	try :#line:3266
		buildbgA .setVisible (False )#line:3267
	except :pass #line:3268
	try :#line:3269
		apkthumb .setVisible (False )#line:3270
	except :pass #line:3271
	try :#line:3272
		apklist .setVisible (False )#line:3273
	except :pass #line:3274
	try :#line:3275
		apkthumb .setVisible (False )#line:3276
	except :pass #line:3277
	try :#line:3278
		apktextbox .setVisible (False )#line:3279
	except :pass #line:3280
	try :#line:3281
		desctextboxAPK .setVisible (False )#line:3282
	except :pass #line:3283
	try :#line:3284
		InstallButtonAPK .setVisible (False )#line:3285
	except :pass #line:3286
	try :#line:3287
		emulist .setVisible (False )#line:3288
	except :pass #line:3289
	try :#line:3290
		emuthumb .setVisible (False )#line:3291
	except :pass #line:3292
	try :#line:3293
		desctextboxEMU .setVisible (False )#line:3294
	except :pass #line:3295
	try :#line:3296
		emutextbox .setVisible (False )#line:3297
	except :pass #line:3298
	try :#line:3299
		InstallButtonEMU .setVisible (False )#line:3300
	except :pass #line:3301
	try :#line:3302
		romlist .setVisible (False )#line:3303
	except :pass #line:3304
	try :#line:3305
		romthumb .setVisible (False )#line:3306
	except :pass #line:3307
	try :#line:3308
		desctextboxROM .setVisible (False )#line:3309
	except :pass #line:3310
	try :#line:3311
		romtextbox .setVisible (False )#line:3312
	except :pass #line:3313
	try :#line:3314
		InstallButtonROM .setVisible (False )#line:3315
	except :pass #line:3316
	try :#line:3317
		maintbg .setVisible (False )#line:3318
	except :pass #line:3319
	try :#line:3320
		total_clean_button .setVisible (False )#line:3321
	except :pass #line:3322
	try :#line:3323
		total_cache_button .setVisible (False )#line:3324
	except :pass #line:3325
	try :#line:3326
		total_packages_button .setVisible (False )#line:3327
	except :pass #line:3328
	try :#line:3329
		total_thumbnails_button .setVisible (False )#line:3330
	except :pass #line:3331
	try :#line:3332
		TC .setVisible (False )#line:3333
	except :pass #line:3334
	try :#line:3335
		DC .setVisible (False )#line:3336
	except :pass #line:3337
	try :#line:3338
		DPK .setVisible (False )#line:3339
	except :pass #line:3340
	try :#line:3341
		DTH .setVisible (False )#line:3342
	except :pass #line:3343
	try :#line:3344
		TPK .setVisible (False )#line:3345
	except :pass #line:3346
	try :#line:3347
		TTH .setVisible (False )#line:3348
	except :pass #line:3349
	try :#line:3350
		sysinfobg .setVisible (False )#line:3351
	except :pass #line:3352
	try :#line:3353
		speedtest_button .setVisible (False )#line:3354
	except :pass #line:3355
	try :#line:3356
		sysinfo_title .setVisible (False )#line:3357
	except :pass #line:3358
	try :#line:3359
		version1 .setVisible (False )#line:3360
	except :pass #line:3361
	try :#line:3362
		store .setVisible (False )#line:3363
	except :pass #line:3364
	try :#line:3365
		rom_used .setVisible (False )#line:3366
	except :pass #line:3367
	try :#line:3368
		rom_free .setVisible (False )#line:3369
	except :pass #line:3370
	try :#line:3371
		rom_total .setVisible (False )#line:3372
	except :pass #line:3373
	try :#line:3374
		mem .setVisible (False )#line:3375
	except :pass #line:3376
	try :#line:3377
		ram_used .setVisible (False )#line:3378
	except :pass #line:3379
	try :#line:3380
		ram_free .setVisible (False )#line:3381
	except :pass #line:3382
	try :#line:3383
		ram_total .setVisible (False )#line:3384
	except :pass #line:3385
	try :#line:3386
		kodi .setVisible (False )#line:3387
	except :pass #line:3388
	try :#line:3389
		total .setVisible (False )#line:3390
	except :pass #line:3391
	try :#line:3392
		video .setVisible (False )#line:3393
	except :pass #line:3394
	try :#line:3395
		program .setVisible (False )#line:3396
	except :pass #line:3397
	try :#line:3398
		music .setVisible (False )#line:3399
	except :pass #line:3400
	try :#line:3401
		picture .setVisible (False )#line:3402
	except :pass #line:3403
	try :#line:3404
		repos .setVisible (False )#line:3405
	except :pass #line:3406
	try :#line:3407
		skins .setVisible (False )#line:3408
	except :pass #line:3409
	try :#line:3410
		scripts .setVisible (False )#line:3411
	except :pass #line:3412
	try :#line:3413
		netinfobg .setVisible (False )#line:3414
	except :pass #line:3415
	try :#line:3416
		netinfo_title .setVisible (False )#line:3417
	except :pass #line:3418
	try :#line:3419
		un_hide_net .setVisible (False )#line:3420
	except :pass #line:3421
	try :#line:3422
		settings_button1 .setVisible (False )#line:3423
	except :pass #line:3424
	try :#line:3425
		trigger_title .setVisible (False )#line:3426
	except :pass #line:3427
	try :#line:3428
		MAC .setVisible (False )#line:3429
	except :pass #line:3430
	try :#line:3431
		INTER_IP .setVisible (False )#line:3432
	except :pass #line:3433
	try :#line:3434
		IP .setVisible (False )#line:3435
	except :pass #line:3436
	try :#line:3437
		ISP .setVisible (False )#line:3438
	except :pass #line:3439
	try :#line:3440
		CITY .setVisible (False )#line:3441
	except :pass #line:3442
	try :#line:3443
		STATE .setVisible (False )#line:3444
	except :pass #line:3445
	try :#line:3446
		COUNTRY .setVisible (False )#line:3447
	except :pass #line:3448
	try :#line:3449
		bakresbg .setVisible (False )#line:3450
	except :pass #line:3451
	try :#line:3452
		favs .setVisible (False )#line:3453
	except :pass #line:3454
	try :#line:3455
		backuploc .setVisible (False )#line:3456
	except :pass #line:3457
	try :#line:3458
		Backup .setVisible (False )#line:3459
	except :pass #line:3460
	try :#line:3461
		backup_build_button .setVisible (False )#line:3462
	except :pass #line:3463
	try :#line:3464
		backup_gui_button .setVisible (False )#line:3465
	except :pass #line:3466
	try :#line:3467
		backup_addondata_button .setVisible (False )#line:3468
	except :pass #line:3469
	try :#line:3470
		restore_build_button .setVisible (False )#line:3471
	except :pass #line:3472
	try :#line:3473
		restore_gui_button .setVisible (False )#line:3474
	except :pass #line:3475
	try :#line:3476
		restore_addondata_button .setVisible (False )#line:3477
	except :pass #line:3478
	try :#line:3479
		clear_backup_button .setVisible (False )#line:3480
	except :pass #line:3481
	try :#line:3482
		savefav_button .setVisible (False )#line:3483
	except :pass #line:3484
	try :#line:3485
		restorefav_button .setVisible (False )#line:3486
	except :pass #line:3487
	try :#line:3488
		clearfav_button .setVisible (False )#line:3489
	except :pass #line:3490
	try :#line:3491
		backupaddonpack_button .setVisible (False )#line:3492
	except :pass #line:3493
	try :#line:3494
		restore_title .setVisible (False )#line:3495
	except :pass #line:3496
	try :#line:3497
		delete_title .setVisible (False )#line:3498
	except :pass #line:3499
	try :#line:3500
		set_title .setVisible (False )#line:3501
	except :pass #line:3502
	try :#line:3503
		settings_button .setVisible (False )#line:3504
	except :pass #line:3505
	try :#line:3506
		view_error_button .setVisible (False )#line:3507
	except :pass #line:3508
	try :#line:3509
		full_log_button .setVisible (False )#line:3510
	except :pass #line:3511
	try :#line:3512
		upload_log_button .setVisible (False )#line:3513
	except :pass #line:3514
	try :#line:3515
		removeaddons_button .setVisible (False )#line:3516
	except :pass #line:3517
	try :#line:3518
		removeaddondata_all_button .setVisible (False )#line:3519
	except :pass #line:3520
	try :#line:3521
		removeaddondata_u_button .setVisible (False )#line:3522
	except :pass #line:3523
	try :#line:3524
		removeaddondata_e_button .setVisible (False )#line:3525
	except :pass #line:3526
	try :#line:3527
		checksources_button .setVisible (False )#line:3528
	except :pass #line:3529
	try :#line:3530
		checkrepos_button .setVisible (False )#line:3531
	except :pass #line:3532
	try :#line:3533
		forceupdate_button .setVisible (False )#line:3534
	except :pass #line:3535
	try :#line:3536
		fixaddonupdate_button .setVisible (False )#line:3537
	except :pass #line:3538
	try :#line:3539
		Addon .setVisible (False )#line:3540
	except :pass #line:3541
	try :#line:3542
		scan .setVisible (False )#line:3543
	except :pass #line:3544
	try :#line:3545
		fix .setVisible (False )#line:3546
	except :pass #line:3547
	try :#line:3548
		delet .setVisible (False )#line:3549
	except :pass #line:3550
	try :#line:3551
		delet1 .setVisible (False )#line:3552
	except :pass #line:3553
	try :#line:3554
		Log_title .setVisible (False )#line:3555
	except :pass #line:3556
	try :#line:3557
		toolsbg .setVisible (False )#line:3558
	except :pass #line:3559
	try :#line:3560
		Log_errors .setVisible (False )#line:3561
	except :pass #line:3562
	try :#line:3563
		WhiteList .setVisible (False )#line:3564
	except :pass #line:3565
	try :#line:3566
		whitelist_edit_button .setVisible (False )#line:3567
	except :pass #line:3568
	try :#line:3569
		whitelist_view_button .setVisible (False )#line:3570
	except :pass #line:3571
	try :#line:3572
		whitelist_clear_button .setVisible (False )#line:3573
	except :pass #line:3574
	try :#line:3575
		whitelist_import_button .setVisible (False )#line:3576
	except :pass #line:3577
	try :#line:3578
		whitelist_export_button .setVisible (False )#line:3579
	except :pass #line:3580
	try :#line:3581
		Advan .setVisible (False )#line:3582
	except :pass #line:3583
	try :#line:3584
		autoadvanced_buttonQ .setVisible (False )#line:3585
	except :pass #line:3586
	try :#line:3587
		autoadvanced_button .setVisible (False )#line:3588
	except :pass #line:3589
	try :#line:3590
		currentsettings_button .setVisible (False )#line:3591
	except :pass #line:3592
	try :#line:3593
		removeadvanced_button .setVisible (False )#line:3594
	except :pass #line:3595
	try :#line:3596
		buildname .setVisible (False )#line:3597
	except :pass #line:3598
	try :#line:3599
		buildversion .setVisible (False )#line:3600
	except :pass #line:3601
	try :#line:3602
		buildtheme .setVisible (False )#line:3603
	except :pass #line:3604
	try :#line:3605
		skinname .setVisible (False )#line:3606
	except :pass #line:3607
	try :#line:3608
		errorinstall .setVisible (False )#line:3609
	except :pass #line:3610
	try :#line:3611
		lastupdatchk .setVisible (False )#line:3612
	except :pass #line:3613
def list_update ():#line:3615
    global Bname #line:3616
    global url #line:3617
    global name #line:3618
    global plugin #line:3619
    global buildlist
    try :#line:3620
        logging.warning('Build list')
        if window .getFocus ()==buildlist :#line:3621
            O0OO0OOOO0O0000O0 =buildlist .getSelectedPosition ()#line:3622
            O0OO0O0OOOO0OO000 =net .http_GET (BUILDFILE ).content .replace ('\n','').replace ('\r','')#line:3623
            url =re .compile ('url="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3624
            name =re .compile ('name="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3625
            OOO0OOOOOO00OO0O0 =re .compile ('icon="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3626
            OO00O00O00O00O00O =re .compile ('version="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3627
            O0O0O0O00OOO0O000 =re .compile ('kodi="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3628
            OO00OOOO00OOO0O0O =re .compile ('description="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3629
            buildtextbox .setLabel ('[COLOR %s] -בילד נבחר  [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,name ))#line:3630
            vertextbox .setLabel ('[COLOR %s] -גרסה [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO00O00O00O00O00O ))#line:3631
            koditextbox .setLabel ('[COLOR %s] -גרסת קודי  [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O0O0O0O00OOO0O000 ))#line:3632
            desctextbox .setText ('[COLOR %s][COLOR red][B]בחרו בהתקנה רגילה אם יש לכם בילד מותקן[/B][/COLOR][COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO00OOOO00OOO0O0O ))#line:3633
            buildthumb .setImage (OOO0OOOOOO00OO0O0 )#line:3634
            OO00OO0000OOOOO0O =buildlist .getListItem (buildlist .getSelectedPosition ()).getLabel ()#line:3635
            Bname =wiz .stripcolortags (OO00OO0000OOOOO0O )#line:3636
    except Exception as e:
        import linecache,os
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)

        logging.warning('ERROR IN DP:'+str(lineno)+str(e))
        logging.warning('inline:'+line)
    try :#line:3638
        if window .getFocus ()==addonlist :#line:3639
            O0OO0OOOO0O0000O0 =addonlist .getSelectedPosition ()#line:3640
            O0OO0O0OOOO0OO000 =net .http_GET (ADDONFILE ).content .replace ('\n','').replace ('\r','')#line:3641
            OO0OOOOOO00000OOO =re .compile ('icon="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3642
            url =re .compile ('url="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3643
            name =re .compile ('name="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3644
            OO00OOOO00OOO0O0O =re .compile ('description="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3645
            plugin =re .compile ('plugin="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3646
            addtextbox .setLabel ('[COLOR %s]Addon Selected:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,name ))#line:3647
            desctextboxA .setText ('[COLOR %s]Addon Description:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO00OOOO00OOO0O0O ))#line:3648
            addthumb .setImage (OO0OOOOOO00000OOO )#line:3649
            OO00OO0000OOOOO0O =addonlist .getListItem (addonlist .getSelectedPosition ()).getLabel ()#line:3650
            name =wiz .stripcolortags (OO00OO0000OOOOO0O )#line:3651
    except :pass #line:3652
    try :#line:3653
        if window .getFocus ()==apklist :#line:3654
            O0OO0OOOO0O0000O0 =apklist .getSelectedPosition (name ,url )#line:3655
            O0OO0O0OOOO0OO000 =net .http_GET (APKFILE ).content .replace ('\n','').replace ('\r','')#line:3656
            OO0OOO0OOOOOO0O00 =re .compile ('icon="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3657
            url =re .compile ('url="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3658
            name =re .compile ('name="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3659
            OO00OOOO00OOO0O0O =re .compile ('description="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3660
            apktextbox .setLabel ('[COLOR %s]APK Selected:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,name ))#line:3661
            desctextboxAPK .setText ('[COLOR %s]APK Description:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO00OOOO00OOO0O0O ))#line:3662
            apkthumb .setImage (OO0OOO0OOOOOO0O00 )#line:3663
            OO00OO0000OOOOO0O =apklist .getListItem (apklist .getSelectedPosition ()).getLabel ()#line:3664
            name =wiz .stripcolortags (OO00OO0000OOOOO0O )#line:3665
    except :pass #line:3666
    try :#line:3667
        if window .getFocus ()==emulist :#line:3668
            O0OO0OOOO0O0000O0 =emulist .getSelectedPosition (name ,url )#line:3669
            O0OO0O0OOOO0OO000 =net .http_GET (EMUAPKS ).content .replace ('\n','').replace ('\r','')#line:3670
            O0OOO0O00O0O0O0O0 =re .compile ('icon="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3671
            url =re .compile ('url="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3672
            name =re .compile ('name="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3673
            OO00OOOO00OOO0O0O =re .compile ('description="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3674
            emutextbox .setLabel ('[COLOR %s]EMU Selected:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,name ))#line:3675
            desctextboxEMU .setText ('[COLOR %s]EMU Description:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO00OOOO00OOO0O0O ))#line:3676
            emuthumb .setImage (O0OOO0O00O0O0O0O0 )#line:3677
    except :pass #line:3678
    try :#line:3679
        if window .getFocus ()==romlist :#line:3680
            O0OO0OOOO0O0000O0 =romlist .getSelectedPosition (name ,url )#line:3681
            O0OO0O0OOOO0OO000 =net .http_GET (ROMPACK ).content .replace ('\n','').replace ('\r','')#line:3682
            O0OOO0O00O0O0O0O0 =re .compile ('icon="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3683
            url =re .compile ('url="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3684
            name =re .compile ('name="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3685
            OO00OOOO00OOO0O0O =re .compile ('description="(.+?)"').findall (O0OO0O0OOOO0OO000 )[O0OO0OOOO0O0000O0 ]#line:3686
            romtextbox .setLabel ('[COLOR %s]ROM PACK Selected:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,name ))#line:3687
            desctextboxROM .setText ('[COLOR %s]ROM PACK Description:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO00OOOO00OOO0O0O ))#line:3688
            romthumb .setImage (O0OOO0O00O0O0O0O0 )#line:3689
    except :pass #line:3690
def BuildList ():#line:3692
	global InstallButton #line:3693
	global FreshStartButton #line:3694
	global buildlist #line:3695
	global buildthumb #line:3696
	global buildtextbox #line:3697
	global vertextbox #line:3698
	global koditextbox #line:3699
	global desctextbox #line:3700
	global no_txt #line:3701
	global buildname #line:3702
	global buildversion #line:3703
	global buildtheme #line:3704
	global skinname #line:3705
	global errorinstall #line:3706
	global lastupdatchk #line:3707
	global Bname #line:3708
	global PreviewButton #line:3709
	global ThemeButton #line:3710
	list_update ()#line:3711
	HIDEALL ()#line:3713
	if not BUILDFILE =='http://'and not BUILDFILE =='':#line:3714
		listbg .setVisible (True )#line:3716
		buildbg .setVisible (True )#line:3717
		buildinfobg .setVisible (True )#line:3718
		PreviewButton =pyxbmct .Button ('[COLOR %s][B]סרטון הדגמה[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3720
		window .placeControl (PreviewButton ,20 ,20 ,8 ,8 )#line:3721
		window .connect (PreviewButton ,lambda :buildVideo (Bname ))#line:3722
		InstallButton =pyxbmct .Button ('[COLOR %s][B]התקנה רגילה[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3724
		window .placeControl (InstallButton ,28 ,20 ,8 ,8 )#line:3725
		window .connect (InstallButton ,lambda :buildWizard (Bname ,'normal'))#line:3726
		FreshStartButton =pyxbmct .Button ('[COLOR %s][B]התקנה נקיה[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3728
		window .placeControl (FreshStartButton ,36 ,20 ,8 ,8 )#line:3729
		window .connect (FreshStartButton ,lambda :buildWizard (Bname ,'fresh'))#line:3730
		ThemeButton =pyxbmct .Button ('[COLOR %s][B]התקנת ערכות[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3732
		window .placeControl (ThemeButton ,44 ,20 ,8 ,8 )#line:3733
		window .connect (ThemeButton ,lambda :buildWizard (Bname ,'theme'))#line:3734
		buildthumb =pyxbmct .Image (ICON )#line:3739
		window .placeControl (buildthumb ,21 ,30 ,45 ,19 )#line:3740
		buildlist =pyxbmct .List (buttonFocusTexture =LBUTTON )#line:3742
		window .placeControl (buildlist ,14 ,1 ,79 ,15 )#line:3743
		buildtextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:3745
		window .placeControl (buildtextbox ,13 ,20 ,10 ,25 )#line:3746
		vertextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:3748
		window .placeControl (vertextbox ,60 ,20 ,10 ,15 )#line:3749
		koditextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:3751
		window .placeControl (koditextbox ,65 ,20 ,10 ,15 )#line:3752
		desctextbox =pyxbmct .TextBox ()#line:3754
		window .placeControl (desctextbox ,70 ,20 ,17 ,30 )#line:3755
		desctextbox .autoScroll (1100 ,1100 ,1100 )#line:3756
		OO0O0OOOOOOOOO00O =ADDON .getSetting ('buildname')#line:3758
		O00OOO0OOOOO00O0O =ADDON .getSetting ('buildversion')#line:3759
		OO0000OO000OOO000 =ADDON .getSetting ('defaultskinname')#line:3760
		OOOO000OOO0O0OOOO =ADDON .getSetting ('buildtheme')#line:3761
		O00OOO0OO0OOO0O0O =ADDON .getSetting ('errors')#line:3762
		OO0O000000OOO0OOO =ADDON .getSetting ('lastbuildcheck')#line:3763
		if OO0O0OOOOOOOOO00O =='':buildname =None #line:3766
		else :buildname =ADDON .getSetting ('buildname')#line:3767
		if O00OOO0OOOOO00O0O =='':buildversion =None #line:3769
		else :buildversion =ADDON .getSetting ('buildversion')#line:3770
		if OO0000OO000OOO000 =='':O00O0O0000000O000 =None #line:3772
		else :O00O0O0000000O000 =ADDON .getSetting ('defaultskinname')#line:3773
		if OOOO000OOO0O0OOOO =='':buildtheme =None #line:3775
		else :buildtheme =ADDON .getSetting ('buildtheme')#line:3776
		if O00OOO0OO0OOO0O0O =='':O00OO0OO0O000OO00 =None #line:3778
		else :O00OO0OO0O000OO00 =ADDON .getSetting ('errors')#line:3779
		if OO0O000000OOO0OOO =='':O000OO0OO000000OO =None #line:3781
		else :O000OO0OO000000OO =ADDON .getSetting ('lastbuildcheck')#line:3782
		buildname =pyxbmct .Label ('[COLOR %s] בילד נוכחי מותקן [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,buildname ))#line:3786
		window .placeControl (buildname ,90 ,2 ,8 ,25 )#line:3787
		buildversion =pyxbmct .Label ('[COLOR %s] גרסת בילד [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,buildversion ))#line:3789
		window .placeControl (buildversion ,95 ,2 ,8 ,20 )#line:3790
		skinname =pyxbmct .Label ('[COLOR %s] סקין בילד מותקן [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O00O0O0000000O000 ))#line:3792
		window .placeControl (skinname ,100 ,2 ,11 ,20 )#line:3793
		buildtheme =pyxbmct .Label ('[COLOR %s] ערכת בילד מותקן  [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,buildtheme ))#line:3795
		window .placeControl (buildtheme ,90 ,28 ,8 ,21 )#line:3796
		errorinstall =pyxbmct .Label ('[COLOR %s] שגיאות במהלך ההתקנה  [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O00OO0OO0O000OO00 ))#line:3798
		window .placeControl (errorinstall ,95 ,28 ,8 ,20 )#line:3799
		lastupdatchk =pyxbmct .Label ('[COLOR %s] בדיקת עדכון אחרון  [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O000OO0OO000000OO ))#line:3801
		window .placeControl (lastupdatchk ,100 ,28 ,8 ,20 )#line:3802
		buildlist .reset ()#line:3805
		buildlist .setVisible (True )#line:3806
		buildthumb .setVisible (True )#line:3807
		InstallButton .setVisible (True )#line:3809
		FreshStartButton .setVisible (True )#line:3810
		buildtextbox .setVisible (True )#line:3811
		vertextbox .setVisible (True )#line:3812
		koditextbox .setVisible (True )#line:3813
		desctextbox .setVisible (True )#line:3814
		buildname .setVisible (True )#line:3816
		buildversion .setVisible (True )#line:3817
		buildtheme .setVisible (True )#line:3818
		skinname .setVisible (True )#line:3819
		errorinstall .setVisible (True )#line:3820
		lastupdatchk .setVisible (True )#line:3821
		buildthumb .setImage (ICON )#line:3823
		O0OOOO0OO00OO0000 =net .http_GET (BUILDFILE ).content .replace ('\n','').replace ('\r','')#line:3824
		O00O0O0O00000O000 =re .compile ('name="(.+?)"').findall (O0OOOO0OO00OO0000 )#line:3825
		for O00O0O0O0OOOO0O00 in O00O0O0O00000O000 :#line:3826
			O00O0O0O0OOOO0O00 ='[COLOR %s]'%LIST_TEXT +O00O0O0O0OOOO0O00 +'[/COLOR]'#line:3827
			buildlist .addItem (O00O0O0O0OOOO0O00 )#line:3828
		BuildsButton .controlUp (buildlist )#line:3830
		BuildsButton .controlDown (buildlist )#line:3831
		buildlist .controlRight (PreviewButton )#line:3833
		buildlist .controlUp (BuildsButton )#line:3834
		PreviewButton .controlDown (InstallButton )#line:3836
		PreviewButton .controlUp (BuildsButton )#line:3837
		PreviewButton .controlLeft (buildlist )#line:3838
		InstallButton .controlDown (FreshStartButton )#line:3840
		InstallButton .controlUp (PreviewButton )#line:3841
		InstallButton .controlLeft (buildlist )#line:3842
		FreshStartButton .controlDown (ThemeButton )#line:3844
		FreshStartButton .controlUp (InstallButton )#line:3845
		FreshStartButton .controlLeft (buildlist )#line:3846
		ThemeButton .controlUp (FreshStartButton )#line:3849
		ThemeButton .controlLeft (buildlist )#line:3850
	else :#line:3851
		no_txt .setVisible (True )#line:3852
		wiz .FTGlog ('No Build txt')#line:3853
def AddonInstall (O0OOO0OO000OO0O00 ):#line:3855
	OOOO0OO00OOOOOOOO =wiz .openURL (ADDONFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:3856
	O00OOO00OOOO000O0 =re .compile ('name="%s".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OOO0OO000OO0O00 ).findall (OOOO0OO00OOOOOOOO )#line:3857
	if len (O00OOO00OOOO000O0 )>0 :#line:3858
		OOOO00OOO0000O000 =0 #line:3859
		for O00O0O00O00OOO000 ,OO00O0OO000OOO000 ,O0O000O00000OO0O0 ,OOO00OO00O0O0OO00 ,OOO0000OOOOO0O0OO ,OOO0O00OO00O000OO ,O0000O00000O00OO0 ,O0OOO00OO0OOO00O0 ,OOOO0O0OO00O0OO0O in O00OOO00OOOO000O0 :#line:3860
			if O00O0O00O00OOO000 .lower ()=='skin':#line:3861
				skinInstaller (O0OOO0OO000OO0O00 ,url )#line:3862
			elif O00O0O00O00OOO000 .lower ()=='pack':#line:3863
				packInstaller (O0OOO0OO000OO0O00 ,url )#line:3864
			else :#line:3865
				addonInstaller (O00O0O00O00OOO000 ,url )#line:3866
def APKinstall (OO0OO00OO00OO0OO0 ):#line:3868
	O0OO0O00OO000OO00 =OO0OO00OO00OO0OO0 #line:3869
	OO0O0OOOO0O000OO0 =checkAPK (OO0OO00OO00OO0OO0 ,'url')#line:3870
	apkInstaller1 (O0OO0O00OO000OO00 ,OO0O0OOOO0O000OO0 )#line:3871
def AddonList ():#line:3873
	global InstallButtonA #line:3874
	global addonlist #line:3875
	global addthumb #line:3876
	global desctextboxA #line:3877
	global addtextbox #line:3878
	global no_txt #line:3879
	global url #line:3880
	global name #line:3881
	HIDEALL ()#line:3883
	if not ADDONFILE =='http://'and not ADDONFILE =='':#line:3884
		listbgA .setVisible (True )#line:3886
		buildbgA .setVisible (True )#line:3887
		InstallButtonA =pyxbmct .Button ('[COLOR %s][B]Install[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3890
		window .placeControl (InstallButtonA ,30 ,20 ,9 ,8 )#line:3891
		window .connect (InstallButtonA ,lambda :AddonInstall (name ))#line:3893
		addthumb =pyxbmct .Image (ICON )#line:3895
		window .placeControl (addthumb ,31 ,30 ,45 ,19 )#line:3896
		addonlist =pyxbmct .List (buttonFocusTexture =LBUTTON )#line:3898
		window .placeControl (addonlist ,24 ,1 ,79 ,15 )#line:3899
		addtextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:3901
		window .placeControl (addtextbox ,24 ,20 ,10 ,25 )#line:3902
		desctextboxA =pyxbmct .TextBox ()#line:3904
		window .placeControl (desctextboxA ,80 ,20 ,17 ,30 )#line:3905
		desctextboxA .autoScroll (1100 ,1100 ,1100 )#line:3906
		addonlist .reset ()#line:3908
		addonlist .setVisible (True )#line:3909
		addthumb .setVisible (True )#line:3910
		AddonButton .setVisible (True )#line:3912
		APKButton .setVisible (True )#line:3913
		ROMButton .setVisible (True )#line:3914
		EmuButton .setVisible (True )#line:3915
		InstallButtonA .setVisible (True )#line:3917
		addtextbox .setVisible (True )#line:3918
		desctextboxA .setVisible (True )#line:3919
		addthumb .setImage (ICON )#line:3921
		O0OO0000OOOO0O000 =net .http_GET (ADDONFILE ).content .replace ('\n','').replace ('\r','')#line:3922
		O0000O0OO0OOO00O0 =re .compile ('name="(.+?)"').findall (O0OO0000OOOO0O000 )#line:3923
		for name in O0000O0OO0OOO00O0 :#line:3924
			name ='[COLOR %s]'%LIST_TEXT +name +'[/COLOR]'#line:3925
			addonlist .addItem (name )#line:3926
		AddonButton .controlDown (addonlist )#line:3928
		addonlist .controlRight (InstallButtonA )#line:3930
		addonlist .controlUp (AddonButton )#line:3931
		InstallButtonA .controlLeft (addonlist )#line:3933
		InstallButtonA .controlUp (AddonButton )#line:3934
	else :#line:3938
		no_txt .setVisible (True )#line:3939
		AddonButton .setVisible (True )#line:3940
		APKButton .setVisible (True )#line:3941
		ROMButton .setVisible (True )#line:3942
		EmuButton .setVisible (True )#line:3943
		wiz .FTGlog ('No Addon txt')#line:3944
def APKList ():#line:3946
	global InstallButtonAPK #line:3947
	global apklist #line:3948
	global apkthumb #line:3949
	global desctextboxAPK #line:3950
	global apktextbox #line:3951
	global no_txt #line:3952
	HIDEALL ()#line:3954
	if not APKFILE =='http://'and not APKFILE =='':#line:3955
		listbgA .setVisible (True )#line:3957
		buildbgA .setVisible (True )#line:3958
		InstallButtonAPK =pyxbmct .Button ('[COLOR %s][B]Install[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3960
		window .placeControl (InstallButtonAPK ,30 ,20 ,9 ,8 )#line:3961
		window .connect (InstallButtonAPK ,lambda :apkInstaller1 (OO000OO000000O0OO ,url ))#line:3962
		apkthumb =pyxbmct .Image (ICON )#line:3964
		window .placeControl (apkthumb ,31 ,30 ,45 ,19 )#line:3965
		apklist =pyxbmct .List (buttonFocusTexture =LBUTTON )#line:3967
		window .placeControl (apklist ,24 ,1 ,79 ,15 )#line:3968
		apktextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:3970
		window .placeControl (apktextbox ,24 ,20 ,10 ,25 )#line:3971
		desctextboxAPK =pyxbmct .TextBox ()#line:3973
		window .placeControl (desctextboxAPK ,80 ,20 ,17 ,30 )#line:3974
		desctextboxAPK .autoScroll (1100 ,1100 ,1100 )#line:3975
		AddonButton .setVisible (True )#line:3977
		APKButton .setVisible (True )#line:3978
		ROMButton .setVisible (True )#line:3979
		EmuButton .setVisible (True )#line:3980
		apklist .reset ()#line:3982
		apklist .setVisible (True )#line:3983
		apkthumb .setVisible (True )#line:3984
		InstallButtonAPK .setVisible (True )#line:3985
		apktextbox .setVisible (True )#line:3986
		desctextboxAPK .setVisible (True )#line:3987
		apkthumb .setImage (ICON )#line:3989
		OO0O000O0000O0O0O =net .http_GET (APKFILE ).content .replace ('\n','').replace ('\r','')#line:3990
		O0OO0O00O0OOO0OO0 =re .compile ('name="(.+?)"').findall (OO0O000O0000O0O0O )#line:3991
		for OO000OO000000O0OO in O0OO0O00O0OOO0OO0 :#line:3992
			OO000OO000000O0OO ='[COLOR %s]'%LIST_TEXT +OO000OO000000O0OO +'[/COLOR]'#line:3993
			apklist .addItem (OO000OO000000O0OO )#line:3994
		APKButton .controlDown (apklist )#line:3996
		apklist .controlRight (InstallButtonAPK )#line:3998
		apklist .controlUp (APKButton )#line:3999
		InstallButtonAPK .controlLeft (apklist )#line:4001
		InstallButtonAPK .controlUp (APKButton )#line:4002
	else :#line:4003
		no_txt .setVisible (True )#line:4004
		AddonButton .setVisible (True )#line:4005
		APKButton .setVisible (True )#line:4006
		ROMButton .setVisible (True )#line:4007
		EmuButton .setVisible (True )#line:4008
		wiz .FTGlog ('No APK txt')#line:4009
def EmuList ():#line:4011
	global emulist #line:4012
	global emuthumb #line:4013
	global desctextboxEMU #line:4014
	global emutextbox #line:4015
	global InstallButtonEMU #line:4016
	global no_txt #line:4017
	HIDEALL ()#line:4019
	if not EMUAPKS =='http://'and not EMUAPKS =='':#line:4020
		listbgA .setVisible (True )#line:4022
		buildbgA .setVisible (True )#line:4023
		InstallButtonEMU =pyxbmct .Button ('[COLOR %s][B]Install[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4025
		window .placeControl (InstallButtonEMU ,30 ,20 ,9 ,8 )#line:4026
		window .connect (InstallButtonEMU ,lambda :apkInstaller1 (O0O0O0O00O00OOO0O ,url ))#line:4027
		emulist =pyxbmct .List (buttonFocusTexture =LBUTTON )#line:4029
		window .placeControl (emulist ,24 ,1 ,79 ,15 )#line:4030
		emuthumb =pyxbmct .Image (ICON )#line:4032
		window .placeControl (emuthumb ,31 ,30 ,45 ,19 )#line:4033
		emutextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:4035
		window .placeControl (emutextbox ,24 ,20 ,10 ,25 )#line:4036
		desctextboxEMU =pyxbmct .TextBox ()#line:4038
		window .placeControl (desctextboxEMU ,80 ,20 ,17 ,30 )#line:4039
		desctextboxEMU .autoScroll (1100 ,1100 ,1100 )#line:4040
		AddonButton .setVisible (True )#line:4042
		APKButton .setVisible (True )#line:4043
		ROMButton .setVisible (True )#line:4044
		EmuButton .setVisible (True )#line:4045
		emulist .setVisible (True )#line:4050
		desctextboxEMU .setVisible (True )#line:4051
		emutextbox .setVisible (True )#line:4052
		InstallButtonEMU .setVisible (True )#line:4053
		emulist .reset ()#line:4055
		emulist .setVisible (True )#line:4056
		emuthumb .setVisible (True )#line:4057
		O0O00000OO0O0OO00 =net .http_GET (EMUAPKS ).content .replace ('\n','').replace ('\r','')#line:4058
		O000000OO00O00O0O =re .compile ('name="(.+?)"').findall (O0O00000OO0O0OO00 )#line:4059
		for O0O0O0O00O00OOO0O in O000000OO00O00O0O :#line:4060
			O0O0O0O00O00OOO0O ='[COLOR %s]'%LIST_TEXT +O0O0O0O00O00OOO0O +'[/COLOR]'#line:4061
			emulist .addItem (O0O0O0O00O00OOO0O )#line:4062
		EmuButton .controlDown (emulist )#line:4064
		emulist .controlRight (InstallButtonEMU )#line:4066
		emulist .controlUp (EmuButton )#line:4067
		InstallButtonEMU .controlLeft (emulist )#line:4069
		InstallButtonEMU .controlUp (EmuButton )#line:4070
	else :#line:4071
		no_txt .setVisible (True )#line:4072
		AddonButton .setVisible (True )#line:4073
		APKButton .setVisible (True )#line:4074
		ROMButton .setVisible (True )#line:4075
		EmuButton .setVisible (True )#line:4076
		wiz .FTGlog ('No EMU txt')#line:4077
def RomList ():#line:4079
	global romlist #line:4080
	global romthumb #line:4081
	global desctextboxROM #line:4082
	global romtextbox #line:4083
	global InstallButtonROM #line:4084
	global no_txt #line:4085
	HIDEALL ()#line:4087
	if not ROMPACK =='http://'and not ROMPACK =='':#line:4088
		listbgA .setVisible (True )#line:4090
		buildbgA .setVisible (True )#line:4091
		InstallButtonROM =pyxbmct .Button ('[COLOR %s][B]Install[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4093
		window .placeControl (InstallButtonROM ,30 ,20 ,9 ,8 )#line:4094
		window .connect (InstallButtonROM ,lambda :UNZIPROM ())#line:4095
		romlist =pyxbmct .List (buttonFocusTexture =LBUTTON )#line:4097
		window .placeControl (romlist ,24 ,1 ,79 ,15 )#line:4098
		romthumb =pyxbmct .Image (ICON )#line:4100
		window .placeControl (romthumb ,31 ,30 ,45 ,19 )#line:4101
		romtextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:4103
		window .placeControl (romtextbox ,24 ,20 ,10 ,25 )#line:4104
		desctextboxROM =pyxbmct .TextBox ()#line:4107
		window .placeControl (desctextboxROM ,80 ,20 ,17 ,30 )#line:4108
		desctextboxROM .autoScroll (1100 ,1100 ,1100 )#line:4109
		AddonButton .setVisible (True )#line:4111
		APKButton .setVisible (True )#line:4112
		ROMButton .setVisible (True )#line:4113
		EmuButton .setVisible (True )#line:4114
		romlist .setVisible (True )#line:4116
		romthumb .setVisible (True )#line:4117
		desctextboxROM .setVisible (True )#line:4118
		romtextbox .setVisible (True )#line:4119
		InstallButtonROM .setVisible (True )#line:4120
		romlist .reset ()#line:4122
		romlist .setVisible (True )#line:4123
		OOOOO0O000O00OO0O =net .http_GET (ROMPACK ).content .replace ('\n','').replace ('\r','')#line:4125
		OO0O00O0O000O00OO =re .compile ('name="(.+?)"').findall (OOOOO0O000O00OO0O )#line:4126
		for OOO0OO000OO00O00O in OO0O00O0O000O00OO :#line:4127
			OOO0OO000OO00O00O ='[COLOR %s]'%LIST_TEXT +OOO0OO000OO00O00O +'[/COLOR]'#line:4128
			romlist .addItem (OOO0OO000OO00O00O )#line:4129
		ROMButton .controlDown (romlist )#line:4131
		romlist .controlRight (InstallButtonROM )#line:4133
		romlist .controlUp (ROMButton )#line:4134
		InstallButtonROM .controlLeft (romlist )#line:4136
		InstallButtonROM .controlUp (ROMButton )#line:4137
	else :#line:4138
		no_txt .setVisible (True )#line:4139
		AddonButton .setVisible (True )#line:4140
		APKButton .setVisible (True )#line:4141
		ROMButton .setVisible (True )#line:4142
		EmuButton .setVisible (True )#line:4143
		wiz .FTGlog ('No ROM txt')#line:4144
def Un_Hide_Net ():#line:4146
	O00OOOOO000O0OOO0 ,OO0O0OO000O00O0OO ,OO00OO0OOO00O00O0 ,O0000OOOO00O00000 ,OOOO00O000OO0O0O0 ,OOOO0OOO00OOO0000 ,OOO0OO0O0OOO000OO =wiz .net_info ()#line:4147
	MAC .setLabel ('[COLOR %s]Mac:[/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O00OOOOO000O0OOO0 ))#line:4148
	INTER_IP .setLabel ('[COLOR %s]-אייפי פנימי [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO0O0OO000O00O0OO ))#line:4149
	IP .setLabel ('[COLOR %s]-אייפי חיצוני [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO00OO0OOO00O00O0 ))#line:4150
	CITY .setLabel ('[COLOR %s]-עיר [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O0000OOOO00O00000 ))#line:4151
	STATE .setLabel ('[COLOR %s]-ארץ [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOOO00O000OO0O0O0 ))#line:4152
	COUNTRY .setLabel ('[COLOR %s]-מדינה [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOOO0OOO00OOO0000 ))#line:4153
	ISP .setLabel ('[COLOR %s]-ספק [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOO0OO0O0OOO000OO ))#line:4154
def Maint ():#line:4156
	HIDEALL ()#line:4157
	global total_clean_button #line:4158
	global total_cache_button #line:4159
	global total_packages_button #line:4160
	global total_thumbnails_button #line:4161
	global TC #line:4162
	global DC #line:4163
	global DPK #line:4164
	global DTH #line:4165
	global TPK #line:4166
	global TTH #line:4167
	global speedtest_button #line:4168
	global sysinfo_title #line:4169
	global version1 #line:4170
	global store #line:4171
	global rom_used #line:4172
	global rom_free #line:4173
	global rom_total #line:4174
	global mem #line:4175
	global ram_used #line:4176
	global ram_free #line:4177
	global ram_total #line:4178
	global kodi #line:4179
	global total #line:4180
	global video #line:4181
	global program #line:4182
	global music #line:4183
	global picture #line:4184
	global repos #line:4185
	global skins #line:4186
	global scripts #line:4187
	sysinfobg .setVisible (True )#line:4189
	maintbg .setVisible (True )#line:4190
	speedthumb .setVisible (True )#line:4191
	netinfobg .setVisible (True )#line:4192
	OO000O0OO0O0OO0O0 =wiz .getSize (PACKAGES )#line:4194
	OO0O0O0O0O0OOOOO0 =wiz .getTotal (PACKAGES )#line:4195
	O000O00O0OO00O000 =wiz .getSize (THUMBS )#line:4196
	O00000OO0OO00O000 =wiz .getTotal (THUMBS )#line:4197
	OOOO00OO0OO00O0O0 =wiz .getCacheSize ()#line:4198
	OO0O000OOO00O0OOO =OO000O0OO0O0OO0O0 +O000O00O0OO00O000 +OOOO00OO0OO00O0O0 #line:4199
	picture ,music ,video ,OOO0O0OO0OOO0OOOO ,repos ,scripts ,skins ,OO0OO000O0OOOO00O ,OOO00O0O00000O000 ,O0O000O00000000O0 ,OOO0O0O00000OO00O ,O0OOOO0OOO0OOOOO0 ,O00000O0000000000 ,ram_free ,ram_used ,ram_total =wiz .SYSINFO ()#line:4200
	sysinfo_title =pyxbmct .Label ('[COLOR %s][B]נתוני מערכת[/B][/COLOR]'%DES_T_COLOR )#line:4204
	window .placeControl (sysinfo_title ,12 ,31 ,10 ,15 )#line:4205
	version1 =pyxbmct .Label ('[COLOR %s]-גרסה [/COLOR] [COLOR %s]%s[/COLOR] - [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO0OO000O0OOOO00O ,DESCOLOR ,OOO00O0O00000O000 ))#line:4206
	window .placeControl (version1 ,18 ,37 ,10 ,15 )#line:4207
	store =pyxbmct .Label ('[B][COLOR %s] אחסון [/COLOR][/B]'%DESCOLOR )#line:4208
	window .placeControl (store ,23 ,39 ,10 ,10 )#line:4209
	rom_used =pyxbmct .Label ('[COLOR %s]-בשימוש [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O0OOOO0OOO0OOOOO0 ))#line:4210
	window .placeControl (rom_used ,28 ,39 ,10 ,10 )#line:4211
	rom_free =pyxbmct .Label ('[COLOR %s]-פנוי [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOO0O0O00000OO00O ))#line:4212
	window .placeControl (rom_free ,32 ,39 ,10 ,10 )#line:4213
	rom_total =pyxbmct .Label ('[COLOR %s]-כללי [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O00000O0000000000 ))#line:4214
	window .placeControl (rom_total ,37 ,39 ,10 ,10 )#line:4215
	mem =pyxbmct .Label ('[B][COLOR %s] זכרון [/COLOR][/B]'%DESCOLOR )#line:4216
	window .placeControl (mem ,43 ,39 ,10 ,10 )#line:4217
	ram_used =pyxbmct .Label ('[COLOR %s]-בשימוש [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,ram_used ))#line:4219
	window .placeControl (ram_used ,48 ,39 ,10 ,10 )#line:4220
	ram_free =pyxbmct .Label ('[COLOR %s]-פנוי [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,ram_free ))#line:4221
	window .placeControl (ram_free ,53 ,39 ,10 ,10 )#line:4222
	ram_total =pyxbmct .Label ('[COLOR %s]-כללי [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,ram_total ))#line:4223
	window .placeControl (ram_total ,58 ,39 ,10 ,10 )#line:4224
	kodi =pyxbmct .Label ('[COLOR %s]-שם [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O0O000O00000000O0 ))#line:4228
	window .placeControl (kodi ,17 ,22 ,10 ,15 )#line:4229
	O0OO0O00O00O00O0O =len (picture )+len (music )+len (video )+len (OOO0O0OO0OOO0OOOO )+len (scripts )+len (skins )+len (repos )#line:4230
	total =pyxbmct .Label ('[COLOR %s]-סך הרחבות [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O0OO0O00O00O00O0O ))#line:4231
	window .placeControl (total ,22 ,22 ,10 ,10 )#line:4232
	video =pyxbmct .Label ('[COLOR %s]-הרחבות וידאו [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (video ))))#line:4233
	window .placeControl (video ,27 ,22 ,10 ,10 )#line:4234
	program =pyxbmct .Label ('[COLOR %s]-הרחבות תוכנה [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (OOO0O0OO0OOO0OOOO ))))#line:4235
	window .placeControl (program ,33 ,22 ,10 ,10 )#line:4236
	music =pyxbmct .Label ('[COLOR %s]-הרחבות מוזיקה [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (music ))))#line:4237
	window .placeControl (music ,37 ,22 ,10 ,10 )#line:4238
	picture =pyxbmct .Label ('[COLOR %s]-הרחבות תמונה [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (picture ))))#line:4239
	window .placeControl (picture ,42 ,22 ,10 ,10 )#line:4240
	repos =pyxbmct .Label ('[COLOR %s]- מספר ריפויים [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (repos ))))#line:4241
	window .placeControl (repos ,47 ,22 ,10 ,10 )#line:4242
	skins =pyxbmct .Label ('[COLOR %s]-מעטפת [/COLOR][COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (skins ))))#line:4243
	window .placeControl (skins ,52 ,22 ,10 ,10 )#line:4244
	scripts =pyxbmct .Label ('[COLOR %s]-מודול/סקריפט[/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (scripts ))))#line:4245
	window .placeControl (scripts ,57 ,22 ,10 ,10 )#line:4246
	global MAC #line:4248
	global INTER_IP #line:4249
	global IP #line:4250
	global CITY #line:4251
	global STATE #line:4252
	global COUNTRY #line:4253
	global ISP #line:4254
	global netinfo_title #line:4255
	global un_hide_net #line:4256
	global settings_button1 #line:4257
	global trigger_title #line:4258
	netinfo_title =pyxbmct .Label ('[COLOR %s][B]מאפייני רשת[/B][/COLOR]'%DES_T_COLOR )#line:4263
	window .placeControl (netinfo_title ,12 ,7 ,10 ,20 )#line:4264
	MAC =pyxbmct .Label ('[COLOR %s]Mac: [/COLOR] [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:4265
	window .placeControl (MAC ,18 ,1 ,10 ,18 )#line:4266
	INTER_IP =pyxbmct .Label ('[COLOR %s]-אייפי פנימי [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:4267
	window .placeControl (INTER_IP ,23 ,1 ,10 ,18 )#line:4268
	IP =pyxbmct .Label ('[COLOR %s]-אייפי חיצוני [/COLOR] [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:4269
	window .placeControl (IP ,28 ,1 ,10 ,18 )#line:4270
	CITY =pyxbmct .Label ('[COLOR %s]-עיר [/COLOR] [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:4271
	window .placeControl (CITY ,33 ,1 ,10 ,18 )#line:4272
	STATE =pyxbmct .Label ('[COLOR %s]-ארץ [/COLOR] [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:4273
	window .placeControl (STATE ,38 ,1 ,10 ,18 )#line:4274
	COUNTRY =pyxbmct .Label ('[COLOR %s]-מדינה [/COLOR] [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:4275
	window .placeControl (COUNTRY ,43 ,1 ,10 ,18 )#line:4276
	ISP =pyxbmct .Label ('[COLOR %s]-ספק[/COLOR] [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:4277
	window .placeControl (ISP ,48 ,1 ,10 ,18 )#line:4278
	TC =pyxbmct .Label ('[COLOR %s]-גודל[/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,wiz .convertSize (OO0O000OOO00O0OOO )))#line:4281
	window .placeControl (TC ,80 ,21 ,10 ,9 )#line:4282
	DC =pyxbmct .Label ('[COLOR %s]-גודל[/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,wiz .convertSize (OOOO00OO0OO00O0O0 )))#line:4283
	window .placeControl (DC ,96 ,21 ,10 ,9 )#line:4284
	DPK =pyxbmct .Label ('[COLOR %s]-גודל[/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,wiz .convertSize (OO000O0OO0O0OO0O0 )))#line:4285
	window .placeControl (DPK ,96 ,31 ,10 ,9 )#line:4286
	TPK =pyxbmct .Label ('[COLOR %s]-קבצים [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO0O0O0O0O0OOOOO0 ))#line:4287
	window .placeControl (TPK ,101 ,31 ,10 ,9 )#line:4288
	DTH =pyxbmct .Label ('[COLOR %s]-גודל[/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,wiz .convertSize (O000O00O0OO00O000 )))#line:4289
	window .placeControl (DTH ,96 ,41 ,10 ,9 )#line:4290
	TTH =pyxbmct .Label ('[COLOR %s]-קבצים [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O00000OO0OO00O000 ))#line:4291
	window .placeControl (TTH ,101 ,41 ,10 ,9 )#line:4292
	total_clean_button =pyxbmct .Button ('[COLOR %s]ניקוי כללי[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4295
	window .placeControl (total_clean_button ,72 ,21 ,9 ,8 )#line:4296
	window .connect (total_clean_button ,lambda :totalClean ())#line:4297
	total_cache_button =pyxbmct .Button ('[COLOR %s]מחק מטמון[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4299
	window .placeControl (total_cache_button ,87 ,21 ,9 ,9 )#line:4300
	window .connect (total_cache_button ,lambda :clearCache ())#line:4301
	total_packages_button =pyxbmct .Button ('[COLOR %s]מחק חבילות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4303
	window .placeControl (total_packages_button ,87 ,31 ,9 ,9 )#line:4304
	window .connect (total_packages_button ,lambda :clearPackages ())#line:4305
	total_thumbnails_button =pyxbmct .Button ('[COLOR %s]מחק תמונות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4307
	window .placeControl (total_thumbnails_button ,87 ,41 ,9 ,9 )#line:4308
	window .connect (total_thumbnails_button ,lambda :clearThumb (type =None ))#line:4309
	speedtest_button =pyxbmct .Button ('[COLOR %s]בדיקת מהירות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4311
	window .placeControl (speedtest_button ,58 ,1 ,9 ,8 )#line:4312
	window .connect (speedtest_button ,lambda :runspeedtest ())#line:4313
	un_hide_net =pyxbmct .Button ('[COLOR %s]הראה מאפייני רשת[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4315
	window .placeControl (un_hide_net ,58 ,10 ,9 ,8 )#line:4316
	window .connect (un_hide_net ,lambda :Un_Hide_Net ())#line:4317
	trigger_title =pyxbmct .Label ('[COLOR lime][B]כלים נוספים[/B][/COLOR]')#line:4319
	window .placeControl (trigger_title ,72 ,33 ,1 ,11 )#line:4320
	settings_button1 =pyxbmct .Button ('[COLOR %s]הגדרות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4322
	window .placeControl (settings_button1 ,72 ,41 ,9 ,8 )#line:4323
	window .connect (settings_button1 ,lambda :wiz .openS ('בדיקת מהירות'))#line:4324
	splash .setVisible (False )#line:4328
	total_clean_button .setVisible (True )#line:4329
	total_cache_button .setVisible (True )#line:4330
	total_packages_button .setVisible (True )#line:4331
	total_thumbnails_button .setVisible (True )#line:4332
	TC .setVisible (True )#line:4333
	DC .setVisible (True )#line:4334
	DPK .setVisible (True )#line:4335
	DTH .setVisible (True )#line:4336
	TPK .setVisible (True )#line:4337
	TTH .setVisible (True )#line:4338
	speedtest_button .setVisible (True )#line:4340
	sysinfo_title .setVisible (True )#line:4342
	version1 .setVisible (True )#line:4343
	store .setVisible (True )#line:4344
	rom_used .setVisible (True )#line:4345
	rom_free .setVisible (True )#line:4346
	rom_total .setVisible (True )#line:4347
	mem .setVisible (True )#line:4348
	ram_used .setVisible (True )#line:4349
	ram_free .setVisible (True )#line:4350
	ram_total .setVisible (True )#line:4351
	kodi .setVisible (True )#line:4352
	total .setVisible (True )#line:4353
	video .setVisible (True )#line:4354
	program .setVisible (True )#line:4355
	music .setVisible (True )#line:4356
	picture .setVisible (True )#line:4357
	repos .setVisible (True )#line:4358
	skins .setVisible (True )#line:4359
	scripts .setVisible (True )#line:4360
	netinfo_title .setVisible (True )#line:4362
	MAC .setVisible (True )#line:4363
	un_hide_net .setVisible (True )#line:4364
	INTER_IP .setVisible (True )#line:4365
	IP .setVisible (True )#line:4366
	ISP .setVisible (True )#line:4367
	CITY .setVisible (True )#line:4368
	STATE .setVisible (True )#line:4369
	COUNTRY .setVisible (True )#line:4370
	settings_button1 .setVisible (True )#line:4371
	trigger_title .setVisible (True )#line:4372
	MaintButton .controlDown (speedtest_button )#line:4374
	speedtest_button .controlUp (MaintButton )#line:4376
	speedtest_button .controlDown (total_clean_button )#line:4377
	speedtest_button .controlRight (un_hide_net )#line:4378
	un_hide_net .controlUp (MaintButton )#line:4380
	un_hide_net .controlDown (total_clean_button )#line:4381
	un_hide_net .controlRight (total_clean_button )#line:4382
	un_hide_net .controlLeft (speedtest_button )#line:4383
	total_clean_button .controlUp (MaintButton )#line:4385
	total_clean_button .controlDown (total_cache_button )#line:4386
	total_clean_button .controlRight (settings_button1 )#line:4387
	total_clean_button .controlLeft (un_hide_net )#line:4388
	total_cache_button .controlUp (total_clean_button )#line:4390
	total_cache_button .controlRight (total_packages_button )#line:4391
	total_cache_button .controlLeft (un_hide_net )#line:4392
	total_packages_button .controlUp (settings_button1 )#line:4394
	total_packages_button .controlRight (total_thumbnails_button )#line:4395
	total_packages_button .controlLeft (total_cache_button )#line:4396
	total_thumbnails_button .controlUp (settings_button1 )#line:4398
	total_thumbnails_button .controlLeft (total_packages_button )#line:4399
	settings_button1 .controlUp (MaintButton )#line:4401
	settings_button1 .controlDown (total_thumbnails_button )#line:4402
	settings_button1 .controlLeft (total_clean_button )#line:4403
def BackRes ():#line:4405
	HIDEALL ()#line:4406
	global favs #line:4407
	global backuploc #line:4408
	global Backup #line:4409
	global backup_build_button #line:4410
	global backup_gui_button #line:4411
	global backup_addondata_button #line:4412
	global restore_build_button #line:4413
	global restore_gui_button #line:4414
	global restore_addondata_button #line:4415
	global clear_backup_button #line:4416
	global savefav_button #line:4417
	global restorefav_button #line:4418
	global clearfav_button #line:4419
	global backupaddonpack_button #line:4420
	global restore_title #line:4421
	global delete_title #line:4422
	global set_title #line:4423
	global settings_button #line:4424
	bakresbg .setVisible (True )#line:4426
	OO0OO00O0000000OO =str (FAVSsave )if not FAVSsave ==''else 'כרגע אין מועדפים שנשמרו'#line:4428
	favs =pyxbmct .Label ('[B][COLOR %s]-שמירה אחרונה בתאריך-[/COLOR] [COLOR %s]%s[/COLOR][/B]'%(DES_T_COLOR ,DESCOLOR ,str (OO0OO00O0000000OO )))#line:4431
	window .placeControl (favs ,14 ,3 ,10 ,30 )#line:4432
	backuploc =pyxbmct .Label ('[B][COLOR %s] נתיב שמירת גיבוי [COLOR %s]%s[/COLOR][/B]'%(DES_T_COLOR ,DESCOLOR ,MYBUILDS ))#line:4434
	window .placeControl (backuploc ,22 ,3 ,10 ,30 )#line:4435
	Backup =pyxbmct .Label ('[B][COLOR %s] כלי גיבוי[/COLOR][/B]'%DES_T_COLOR )#line:4438
	window .placeControl (Backup ,32 ,6 ,10 ,10 )#line:4439
	backup_build_button =pyxbmct .Button ('[COLOR %s] בילד [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4441
	window .placeControl (backup_build_button ,42 ,3 ,10 ,10 )#line:4442
	window .connect (backup_build_button ,lambda :wiz .backUpOptions ('build'))#line:4443
	backup_gui_button =pyxbmct .Button ('[COLOR %s] מימשק [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4445
	window .placeControl (backup_gui_button ,52 ,3 ,10 ,10 )#line:4446
	window .connect (backup_gui_button ,lambda :wiz .backUpOptions ('guifix'))#line:4447
	backupaddonpack_button =pyxbmct .Button ('[COLOR %s] חבילת הרחבות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4449
	window .placeControl (backupaddonpack_button ,62 ,3 ,10 ,10 )#line:4450
	window .connect (backupaddonpack_button ,lambda :wiz .backUpOptions ('addon pack'))#line:4451
	backup_addondata_button =pyxbmct .Button ('[COLOR %s] נתוני הרחבות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4453
	window .placeControl (backup_addondata_button ,72 ,3 ,10 ,10 )#line:4454
	window .connect (backup_addondata_button ,lambda :wiz .backUpOptions ('addondata'))#line:4455
	savefav_button =pyxbmct .Button ('[COLOR %s] מועדפים [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4457
	window .placeControl (savefav_button ,82 ,3 ,10 ,10 )#line:4458
	window .connect (savefav_button ,lambda :wiz .BACKUPFAV ())#line:4459
	restore_title =pyxbmct .Label ('[B][COLOR lime]כלי שחזור-לחיצה תאפס את הבילד! [/COLOR][/B]')#line:4462
	window .placeControl (restore_title ,32 ,20 ,6 ,16 )#line:4463
	restore_build_button =pyxbmct .Button ('[COLOR %s] בילד/חבילה [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4465
	window .placeControl (restore_build_button ,42 ,20 ,10 ,10 )#line:4466
	window .connect (restore_build_button ,lambda :restoreit ('build'))#line:4467
	restore_gui_button =pyxbmct .Button ('[COLOR %s] ממשק [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4469
	window .placeControl (restore_gui_button ,52 ,20 ,10 ,10 )#line:4470
	window .connect (restore_gui_button ,lambda :restoreit ('gui'))#line:4471
	restore_addondata_button =pyxbmct .Button ('[COLOR %s] נתוני הרחבות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4473
	window .placeControl (restore_addondata_button ,62 ,20 ,10 ,10 )#line:4474
	window .connect (restore_addondata_button ,lambda :restoreit ('addondata'))#line:4475
	restorefav_button =pyxbmct .Button ('[COLOR %s] מועדפים [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4477
	window .placeControl (restorefav_button ,72 ,20 ,10 ,10 )#line:4478
	window .connect (restorefav_button ,lambda :wiz .RESTOREFAV ())#line:4479
	delete_title =pyxbmct .Label ('[B][COLOR red] כלי מחיקה [/COLOR][/B]')#line:4482
	window .placeControl (delete_title ,56 ,40 ,10 ,10 )#line:4483
	clearfav_button =pyxbmct .Button ('[COLOR %s] ניקוי מועדפים [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4485
	window .placeControl (clearfav_button ,64 ,37 ,10 ,10 )#line:4486
	window .connect (clearfav_button ,lambda :wiz .DELFAV ())#line:4487
	clear_backup_button =pyxbmct .Button ('[COLOR %s] ניקוי גיבויים [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4489
	window .placeControl (clear_backup_button ,74 ,37 ,10 ,10 )#line:4490
	window .connect (clear_backup_button ,lambda :wiz .cleanupBackup ())#line:4491
	set_title =pyxbmct .Label ('[B][COLOR %s] הגדרות               [/COLOR][/B]'%DES_T_COLOR )#line:4494
	window .placeControl (set_title ,32 ,37 ,10 ,10 )#line:4495
	settings_button =pyxbmct .Button ('[COLOR %s] הגדרות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4497
	window .placeControl (settings_button ,42 ,37 ,10 ,10 )#line:4498
	window .connect (settings_button ,lambda :wiz .openS ('Maintenance'))#line:4499
	favs .setVisible (True )#line:4502
	backuploc .setVisible (True )#line:4503
	Backup .setVisible (True )#line:4504
	backup_build_button .setVisible (True )#line:4505
	backup_gui_button .setVisible (True )#line:4506
	backup_addondata_button .setVisible (True )#line:4507
	restore_build_button .setVisible (True )#line:4508
	restore_gui_button .setVisible (True )#line:4509
	restore_addondata_button .setVisible (True )#line:4510
	clear_backup_button .setVisible (True )#line:4511
	savefav_button .setVisible (True )#line:4512
	restorefav_button .setVisible (True )#line:4513
	clearfav_button .setVisible (True )#line:4514
	backupaddonpack_button .setVisible (True )#line:4515
	restore_title .setVisible (True )#line:4516
	delete_title .setVisible (True )#line:4517
	set_title .setVisible (True )#line:4518
	settings_button .setVisible (True )#line:4519
	BackResButton .controlDown (backup_build_button )#line:4521
	backup_build_button .controlUp (BackResButton )#line:4523
	backup_build_button .controlDown (backup_gui_button )#line:4524
	backup_build_button .controlRight (restore_build_button )#line:4525
	backup_gui_button .controlUp (backup_build_button )#line:4527
	backup_gui_button .controlDown (backupaddonpack_button )#line:4528
	backup_gui_button .controlRight (restore_gui_button )#line:4529
	backupaddonpack_button .controlUp (backup_gui_button )#line:4531
	backupaddonpack_button .controlDown (backup_addondata_button )#line:4532
	backupaddonpack_button .controlRight (restore_addondata_button )#line:4533
	backup_addondata_button .controlUp (backupaddonpack_button )#line:4535
	backup_addondata_button .controlDown (savefav_button )#line:4536
	backup_addondata_button .controlRight (restorefav_button )#line:4537
	savefav_button .controlUp (backup_addondata_button )#line:4539
	savefav_button .controlRight (restorefav_button )#line:4540
	restore_build_button .controlUp (BackResButton )#line:4542
	restore_build_button .controlDown (restore_gui_button )#line:4543
	restore_build_button .controlRight (settings_button )#line:4544
	restore_build_button .controlLeft (backup_build_button )#line:4545
	restore_gui_button .controlUp (restore_build_button )#line:4547
	restore_gui_button .controlDown (restore_addondata_button )#line:4548
	restore_gui_button .controlRight (settings_button )#line:4549
	restore_gui_button .controlLeft (backup_gui_button )#line:4550
	restore_addondata_button .controlUp (restore_gui_button )#line:4552
	restore_addondata_button .controlDown (restorefav_button )#line:4553
	restore_addondata_button .controlRight (clearfav_button )#line:4554
	restore_addondata_button .controlLeft (backupaddonpack_button )#line:4555
	restorefav_button .controlUp (restore_addondata_button )#line:4557
	restorefav_button .controlRight (clear_backup_button )#line:4558
	restorefav_button .controlLeft (backup_addondata_button )#line:4559
	settings_button .controlUp (BackResButton )#line:4561
	settings_button .controlDown (clearfav_button )#line:4562
	settings_button .controlLeft (restore_build_button )#line:4563
	clearfav_button .controlUp (settings_button )#line:4565
	clearfav_button .controlDown (clear_backup_button )#line:4566
	clearfav_button .controlLeft (restore_addondata_button )#line:4567
	clear_backup_button .controlUp (clearfav_button )#line:4569
	clear_backup_button .controlLeft (restorefav_button )#line:4570
def Tools ():#line:4572
	HIDEALL ()#line:4573
	global view_error_button #line:4575
	global full_log_button #line:4576
	global upload_log_button #line:4577
	global Log_title #line:4578
	global Log_errors #line:4579
	toolsbg .setVisible (True )#line:4581
	Log_title =pyxbmct .Label ('[B][COLOR %s]קודי- כלים        [/COLOR][/B]'%DES_T_COLOR )#line:4583
	window .placeControl (Log_title ,15 ,4 ,10 ,10 )#line:4584
	Log_errors =pyxbmct .Label ('[COLOR %s][B]-מספר שגיאות בלוג[/B][/COLOR] %s'%(OTHER_BUTTONS_TEXT ,log_tools ()))#line:4586
	window .placeControl (Log_errors ,22 ,4 ,10 ,15 )#line:4587
	view_error_button =pyxbmct .Button ('[COLOR %s]צפיה בשגיאות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4589
	window .placeControl (view_error_button ,31 ,4 ,9 ,9 )#line:4590
	window .connect (view_error_button ,lambda :errorChecking (log =None ,count =None ,last =None ))#line:4591
	full_log_button =pyxbmct .Button ('[COLOR %s]צפיה בד"וח הלוג המלא[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4593
	window .placeControl (full_log_button ,40 ,4 ,9 ,9 )#line:4594
	window .connect (full_log_button ,lambda :LogViewer ())#line:4595
	upload_log_button =pyxbmct .Button ('[COLOR %s]העלאת דו"ח לוג מלא[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4597
	window .placeControl (upload_log_button ,49 ,4 ,9 ,9 )#line:4598
	window .connect (upload_log_button ,lambda :uploadLog .Main ())#line:4599
	global removeaddons_button #line:4603
	global removeaddondata_u_button #line:4604
	global removeaddondata_e_button #line:4605
	global checksources_button #line:4606
	global checkrepos_button #line:4607
	global forceupdate_button #line:4608
	global fixaddonupdate_button #line:4609
	global removeaddondata_all_button #line:4610
	global scan #line:4611
	global fix #line:4612
	global delet #line:4613
	global delet1 #line:4614
	global Addon #line:4615
	Addon =pyxbmct .Label ('[B][COLOR %s] תחזוקת הרחבות       [/COLOR][/B]'%DES_T_COLOR )#line:4617
	window .placeControl (Addon ,69 ,21 ,9 ,9 )#line:4618
	scan =pyxbmct .Label ('[B][COLOR %s] בצע סריקה עבור      [/COLOR][/B]'%DES_T_COLOR )#line:4620
	window .placeControl (scan ,75 ,4 ,9 ,10 )#line:4621
	checksources_button =pyxbmct .Button ('[COLOR %s]מקורות לא פעילים [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4623
	window .placeControl (checksources_button ,82 ,3 ,9 ,10 )#line:4624
	window .connect (checksources_button ,lambda :wiz .checkSources ())#line:4625
	checkrepos_button =pyxbmct .Button ('[COLOR %s] ריפויים לא פעילים [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4627
	window .placeControl (checkrepos_button ,92 ,3 ,9 ,10 )#line:4628
	window .connect (checkrepos_button ,lambda :wiz .checkRepos ())#line:4629
	fix =pyxbmct .Label ('[B][COLOR %s]בצע/כפה תיקון     [/COLOR][/B]'%DES_T_COLOR )#line:4631
	window .placeControl (fix ,75 ,16 ,9 ,10 )#line:4632
	forceupdate_button =pyxbmct .Button ('[COLOR %s] עדכון הרחבות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4634
	window .placeControl (forceupdate_button ,82 ,15 ,9 ,9 )#line:4635
	window .connect (forceupdate_button ,lambda :wiz .forceUpdate ())#line:4636
	fixaddonupdate_button =pyxbmct .Button ('[COLOR %s] הרחבות לא מתעדכנות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4638
	window .placeControl (fixaddonupdate_button ,92 ,15 ,9 ,9 )#line:4639
	window .connect (fixaddonupdate_button ,lambda :fixaddonupdate )#line:4640
	delet =pyxbmct .Label ('[B][COLOR %s]מחיקת מידע הרחבות[/COLOR][/B]'%DES_T_COLOR )#line:4642
	window .placeControl (delet ,75 ,27 ,9 ,10 )#line:4643
	removeaddons_button =pyxbmct .Button ('[COLOR %s] מחיקת הרחבות שנבחרו  [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4645
	window .placeControl (removeaddons_button ,82 ,26 ,9 ,9 )#line:4646
	window .connect (removeaddons_button ,lambda :removeAddonMenu )#line:4647
	removeaddondata_all_button =pyxbmct .Button ('[COLOR %s] כלל מידע ההרחבות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4649
	window .placeControl (removeaddondata_all_button ,92 ,26 ,9 ,9 )#line:4650
	window .connect (removeaddondata_all_button ,lambda :removeAddonData ('all'))#line:4651
	delet1 =pyxbmct .Label ('[B][COLOR %s]תחזוקת ספריות[/COLOR][/B]'%DES_T_COLOR )#line:4653
	window .placeControl (delet1 ,75 ,38 ,9 ,10 )#line:4654
	removeaddondata_u_button =pyxbmct .Button ('[COLOR %s] ספריות לא מותקנות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4656
	window .placeControl (removeaddondata_u_button ,82 ,37 ,9 ,9 )#line:4657
	window .connect (removeaddondata_u_button ,lambda :removeAddonData ('uninstalled'))#line:4658
	removeaddondata_e_button =pyxbmct .Button ('[COLOR %s] ספריות ריקות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4660
	window .placeControl (removeaddondata_e_button ,92 ,37 ,9 ,9 )#line:4661
	window .connect (removeaddondata_e_button ,lambda :removeAddonData ('empty'))#line:4662
	global WhiteList #line:4665
	global whitelist_edit_button #line:4666
	global whitelist_view_button #line:4667
	global whitelist_clear_button #line:4668
	global whitelist_import_button #line:4669
	global whitelist_export_button #line:4670
	WhiteList =pyxbmct .Label ('[B][COLOR %s] כלים עבור רשימה לבנה [/COLOR][/B]'%DES_T_COLOR )#line:4673
	window .placeControl (WhiteList ,15 ,37 ,9 ,9 )#line:4674
	whitelist_edit_button =pyxbmct .Button ('[COLOR %s]רשימה לבנה: עריכה [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4676
	window .placeControl (whitelist_edit_button ,22 ,36 ,9 ,9 )#line:4677
	window .connect (whitelist_edit_button ,lambda :wiz .whiteList ('edit'))#line:4678
	whitelist_view_button =pyxbmct .Button ('[COLOR %s]רשימה לבנה: צפיה [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4680
	window .placeControl (whitelist_view_button ,31 ,36 ,9 ,9 )#line:4681
	window .connect (whitelist_view_button ,lambda :wiz .whiteList ('view'))#line:4682
	whitelist_clear_button =pyxbmct .Button ('[COLOR %s]רשימה לבנה: נקה [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4684
	window .placeControl (whitelist_clear_button ,40 ,36 ,9 ,9 )#line:4685
	window .connect (whitelist_clear_button ,lambda :wiz .whiteList ('clear'))#line:4686
	whitelist_import_button =pyxbmct .Button ('[COLOR %s]רשימה לבנה: יבוא [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4688
	window .placeControl (whitelist_import_button ,49 ,36 ,9 ,9 )#line:4689
	window .connect (whitelist_import_button ,lambda :wiz .whiteList ('Import'))#line:4690
	whitelist_export_button =pyxbmct .Button ('[COLOR %s]רשימה לבנה: יצוא [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4692
	window .placeControl (whitelist_export_button ,58 ,36 ,9 ,9 )#line:4693
	window .connect (whitelist_export_button ,lambda :wiz .whiteList ('export'))#line:4694
	global Advan #line:4697
	global autoadvanced_buttonQ #line:4698
	global autoadvanced_button #line:4699
	global currentsettings_button #line:4700
	global removeadvanced_button #line:4701
	Advan =pyxbmct .Label ('[B][COLOR %s]כלי הגדרת באפר[/COLOR][/B]'%DES_T_COLOR )#line:4703
	window .placeControl (Advan ,15 ,22 ,9 ,13 )#line:4704
	autoadvanced_buttonQ =pyxbmct .Button ('[COLOR %s]באפר בסיסי[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4706
	window .placeControl (autoadvanced_buttonQ ,22 ,21 ,9 ,9 )#line:4707
	window .connect (autoadvanced_buttonQ ,lambda :notify .autoConfig2 ())#line:4708
	autoadvanced_button =pyxbmct .Button ('[COLOR %s]הגדרת באפר[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4710
	window .placeControl (autoadvanced_button ,31 ,21 ,9 ,9 )#line:4711
	window .connect (autoadvanced_button ,lambda :notify .autoConfig ())#line:4712
	currentsettings_button =pyxbmct .Button ('[COLOR %s]הגדרות נוכחיות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4714
	window .placeControl (currentsettings_button ,40 ,21 ,9 ,9 )#line:4715
	window .connect (currentsettings_button ,lambda :viewAdvanced ())#line:4716
	removeadvanced_button =pyxbmct .Button ('[COLOR %s]מחיקת הגדרות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4718
	window .placeControl (removeadvanced_button ,49 ,21 ,9 ,9 )#line:4719
	window .connect (removeadvanced_button ,lambda :removeAdvanced ())#line:4720
	view_error_button .setVisible (True )#line:4724
	full_log_button .setVisible (True )#line:4725
	upload_log_button .setVisible (True )#line:4726
	removeaddons_button .setVisible (True )#line:4728
	removeaddondata_all_button .setVisible (True )#line:4729
	removeaddondata_u_button .setVisible (True )#line:4730
	removeaddondata_e_button .setVisible (True )#line:4731
	checksources_button .setVisible (True )#line:4733
	checkrepos_button .setVisible (True )#line:4734
	forceupdate_button .setVisible (True )#line:4735
	fixaddonupdate_button .setVisible (True )#line:4736
	Log_title .setVisible (True )#line:4738
	Log_errors .setVisible (True )#line:4739
	Addon .setVisible (True )#line:4742
	scan .setVisible (True )#line:4743
	fix .setVisible (True )#line:4744
	delet .setVisible (True )#line:4745
	delet1 .setVisible (True )#line:4746
	WhiteList .setVisible (True )#line:4747
	whitelist_edit_button .setVisible (True )#line:4749
	whitelist_view_button .setVisible (True )#line:4750
	whitelist_clear_button .setVisible (True )#line:4751
	whitelist_import_button .setVisible (True )#line:4752
	whitelist_export_button .setVisible (True )#line:4753
	Advan .setVisible (True )#line:4755
	autoadvanced_buttonQ .setVisible (True )#line:4756
	autoadvanced_button .setVisible (True )#line:4757
	currentsettings_button .setVisible (True )#line:4758
	removeadvanced_button .setVisible (True )#line:4759
	ToolsButton .controlDown (view_error_button )#line:4761
	view_error_button .controlUp (ToolsButton )#line:4763
	view_error_button .controlDown (full_log_button )#line:4764
	view_error_button .controlRight (autoadvanced_button )#line:4765
	full_log_button .controlUp (view_error_button )#line:4767
	full_log_button .controlDown (upload_log_button )#line:4768
	full_log_button .controlRight (currentsettings_button )#line:4769
	upload_log_button .controlUp (full_log_button )#line:4771
	upload_log_button .controlDown (checksources_button )#line:4772
	upload_log_button .controlRight (removeadvanced_button )#line:4773
	autoadvanced_buttonQ .controlUp (ToolsButton )#line:4775
	autoadvanced_buttonQ .controlLeft (view_error_button )#line:4776
	autoadvanced_buttonQ .controlDown (autoadvanced_button )#line:4777
	autoadvanced_buttonQ .controlRight (whitelist_edit_button )#line:4778
	autoadvanced_button .controlUp (autoadvanced_buttonQ )#line:4780
	autoadvanced_button .controlLeft (view_error_button )#line:4781
	autoadvanced_button .controlDown (currentsettings_button )#line:4782
	autoadvanced_button .controlRight (whitelist_view_button )#line:4783
	currentsettings_button .controlUp (autoadvanced_button )#line:4785
	currentsettings_button .controlLeft (full_log_button )#line:4786
	currentsettings_button .controlDown (removeadvanced_button )#line:4787
	currentsettings_button .controlRight (whitelist_clear_button )#line:4788
	removeadvanced_button .controlUp (currentsettings_button )#line:4790
	removeadvanced_button .controlLeft (upload_log_button )#line:4791
	removeadvanced_button .controlDown (forceupdate_button )#line:4792
	removeadvanced_button .controlRight (whitelist_import_button )#line:4793
	whitelist_edit_button .controlUp (ToolsButton )#line:4795
	whitelist_edit_button .controlLeft (autoadvanced_buttonQ )#line:4796
	whitelist_edit_button .controlDown (whitelist_view_button )#line:4797
	whitelist_view_button .controlUp (whitelist_edit_button )#line:4799
	whitelist_view_button .controlLeft (autoadvanced_button )#line:4800
	whitelist_view_button .controlDown (whitelist_clear_button )#line:4801
	whitelist_clear_button .controlUp (whitelist_view_button )#line:4803
	whitelist_clear_button .controlLeft (currentsettings_button )#line:4804
	whitelist_clear_button .controlDown (whitelist_import_button )#line:4805
	whitelist_import_button .controlUp (whitelist_clear_button )#line:4807
	whitelist_import_button .controlLeft (removeadvanced_button )#line:4808
	whitelist_import_button .controlDown (whitelist_export_button )#line:4809
	whitelist_export_button .controlUp (whitelist_import_button )#line:4811
	whitelist_export_button .controlLeft (removeadvanced_button )#line:4812
	whitelist_export_button .controlDown (removeaddondata_u_button )#line:4813
	checksources_button .controlUp (upload_log_button )#line:4815
	checksources_button .controlDown (checkrepos_button )#line:4816
	checksources_button .controlRight (forceupdate_button )#line:4817
	checkrepos_button .controlUp (checksources_button )#line:4819
	checkrepos_button .controlRight (fixaddonupdate_button )#line:4820
	forceupdate_button .controlUp (removeadvanced_button )#line:4822
	forceupdate_button .controlLeft (checksources_button )#line:4823
	forceupdate_button .controlDown (fixaddonupdate_button )#line:4824
	forceupdate_button .controlRight (removeaddons_button )#line:4825
	fixaddonupdate_button .controlUp (forceupdate_button )#line:4827
	fixaddonupdate_button .controlLeft (checkrepos_button )#line:4828
	fixaddonupdate_button .controlRight (removeaddondata_all_button )#line:4829
	removeaddons_button .controlUp (removeadvanced_button )#line:4831
	removeaddons_button .controlLeft (forceupdate_button )#line:4832
	removeaddons_button .controlDown (removeaddondata_all_button )#line:4833
	removeaddons_button .controlRight (removeaddondata_u_button )#line:4834
	removeaddondata_all_button .controlUp (removeaddons_button )#line:4836
	removeaddondata_all_button .controlLeft (fixaddonupdate_button )#line:4837
	removeaddondata_all_button .controlRight (removeaddondata_e_button )#line:4838
	removeaddondata_u_button .controlUp (whitelist_export_button )#line:4840
	removeaddondata_u_button .controlLeft (removeaddons_button )#line:4841
	removeaddondata_u_button .controlDown (removeaddondata_e_button )#line:4842
	removeaddondata_e_button .controlUp (removeaddondata_u_button )#line:4844
	removeaddondata_e_button .controlLeft (removeaddondata_all_button )#line:4845
def Installables ():#line:4847
	global AddonButton #line:4849
	global APKButton #line:4850
	global ROMButton #line:4851
	global EmuButton #line:4852
	global Bname #line:4853
	HIDEALL ()#line:4854
	listbgA .setVisible (True )#line:4856
	buildbgA .setVisible (True )#line:4857
	AddonButton =pyxbmct .Button ('[COLOR %s][B]Wizards[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =EXIT ,noFocusTexture =BUTTON )#line:4859
	window .placeControl (AddonButton ,12 ,9 ,7 ,8 )#line:4860
	window .connect (AddonButton ,lambda :AddonList ())#line:4861
	APKButton =pyxbmct .Button ('[COLOR %s][B]אפליקציות[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =EXIT ,noFocusTexture =BUTTON )#line:4863
	window .placeControl (APKButton ,12 ,17 ,7 ,8 )#line:4864
	window .connect (APKButton ,lambda :APKList ())#line:4865
	ROMButton =pyxbmct .Button ('[COLOR %s][B]עדכון מהיר[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =EXIT ,noFocusTexture =BUTTON )#line:4867
	window .placeControl (ROMButton ,12 ,25 ,7 ,8 )#line:4868
	window .connect (ROMButton ,lambda :buildWizard (ADDON .getSetting ('buildname'),'gui'))#line:4869
	EmuButton =pyxbmct .Button ('[COLOR %s][B]-[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =EXIT ,noFocusTexture =BUTTON )#line:4871
	window .placeControl (EmuButton ,12 ,33 ,7 ,8 )#line:4872
	window .connect (EmuButton ,lambda :EmuList ())#line:4873
	InstallablesButton .controlDown (AddonButton )#line:4875
	AddonButton .controlUp (InstallablesButton )#line:4876
	APKButton .controlUp (InstallablesButton )#line:4877
	ROMButton .controlUp (InstallablesButton )#line:4878
	EmuButton .controlUp (InstallablesButton )#line:4879
	AddonButton .controlRight (APKButton )#line:4881
	AddonButton .controlLeft (EmuButton )#line:4882
	APKButton .controlRight (ROMButton )#line:4884
	APKButton .controlLeft (AddonButton )#line:4885
	ROMButton .controlRight (EmuButton )#line:4887
	ROMButton .controlLeft (APKButton )#line:4888
	EmuButton .controlRight (AddonButton )#line:4890
	EmuButton .controlLeft (ROMButton )#line:4891
window .connectEventList ([pyxbmct .ACTION_MOVE_DOWN ,pyxbmct .ACTION_MOVE_UP ,pyxbmct .ACTION_MOUSE_WHEEL_DOWN ,pyxbmct .ACTION_MOUSE_WHEEL_UP ,pyxbmct .ACTION_MOUSE_MOVE ],list_update )#line:4900
global ver #line:4903
global fan #line:4904
global listbg #line:4905
global buildbg #line:4906
global maintbg #line:4907
global speedthumb #line:4908
global sysinfobg #line:4909
global netinfobg #line:4910
global splash #line:4911
global bakresbg #line:4912
global toolsbg #line:4913
global wizinfogb #line:4914
global listbgA #line:4915
global buildbgA #line:4916
global buildinfobg #line:4917
window .setGeometry (1280 ,720 ,100 ,50 )#line:4920
fan =pyxbmct .Image (MAINBG )#line:4921
window .placeControl (fan ,-10 ,-6 ,125 ,62 )#line:4922
wiz .FTGlog ('Window Opened')#line:4923
listbg =pyxbmct .Image (LISTBG )#line:4927
window .placeControl (listbg ,10 ,0 ,80 ,17 )#line:4928
buildbg =pyxbmct .Image (LISTBG )#line:4930
window .placeControl (buildbg ,10 ,16 ,80 ,35 )#line:4931
buildinfobg =pyxbmct .Image (LISTBG )#line:4933
window .placeControl (buildinfobg ,88 ,0 ,23 ,50 )#line:4934
listbgA =pyxbmct .Image (LISTBG )#line:4936
window .placeControl (listbgA ,20 ,0 ,80 ,17 )#line:4937
buildbgA =pyxbmct .Image (LISTBG )#line:4939
window .placeControl (buildbgA ,20 ,16 ,80 ,35 )#line:4940
maintbg =pyxbmct .Image (LISTBG )#line:4942
window .placeControl (maintbg ,70 ,19 ,40 ,32 )#line:4943
sysinfobg =pyxbmct .Image (LISTBG )#line:4945
window .placeControl (sysinfobg ,10 ,19 ,60 ,32 )#line:4946
netinfobg =pyxbmct .Image (LISTBG )#line:4948
window .placeControl (netinfobg ,10 ,0 ,60 ,20 )#line:4949
speedthumb =pyxbmct .Image (SpeedBG )#line:4951
window .placeControl (speedthumb ,70 ,0 ,40 ,20 )#line:4952
splash =pyxbmct .Image (SPLASH )#line:4954
window .placeControl (splash ,10 ,1 ,100 ,48 )#line:4955
bakresbg =pyxbmct .Image (LISTBG )#line:4957
window .placeControl (bakresbg ,10 ,1 ,100 ,48 )#line:4958
toolsbg =pyxbmct .Image (LISTBG )#line:4960
window .placeControl (toolsbg ,10 ,1 ,100 ,48 )#line:4961
wizinfogb =pyxbmct .Image (LISTBG )#line:4963
window .placeControl (wizinfogb ,-6 ,9 ,9 ,32 )#line:4964
wiz_title =pyxbmct .Label ('[COLOR %s][B]%s[/B][/COLOR]'%(uservar .WIZTITLE_COLOR ,uservar .WIZTITLE ))#line:4966
window .placeControl (wiz_title ,-5 ,11 ,7 ,20 )#line:4967
wiz_ver =pyxbmct .Label ('[COLOR %s]Version: [COLOR %s][B]%s[/B][/COLOR]'%(uservar .VERTITLE_COLOR ,uservar .VER_NUMBER_COLOR ,VERSION ))#line:4969
window .placeControl (wiz_ver ,-5 ,31 ,7 ,10 )#line:4970
no_txt =pyxbmct .Image (NOTXT )#line:4972
window .placeControl (no_txt ,23 ,8 ,80 ,35 )#line:4973
global MaintButton #line:4980
global BackResButton #line:4981
global ToolsButton #line:4982
global BuildsButton #line:4983
global Toolbox #line:4984
BuildsButton =pyxbmct .Button ('[COLOR %s][B]בילדים[/B][/COLOR]'%MAIN_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4987
window .placeControl (BuildsButton ,-2 ,1 ,13 ,8 )#line:4988
window .connect (BuildsButton ,lambda :BuildList ())#line:4989
MaintButton =pyxbmct .Button ('[COLOR %s][B]כלי מערכת[/B][/COLOR]'%MAIN_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4991
window .placeControl (MaintButton ,2 ,9 ,9 ,8 )#line:4992
window .connect (MaintButton ,lambda :Maint ())#line:4993
BackResButton =pyxbmct .Button ('[COLOR %s][B]גיבוי/שחזור[/B][/COLOR]'%MAIN_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4995
window .placeControl (BackResButton ,2 ,17 ,9 ,8 )#line:4996
window .connect (BackResButton ,lambda :BackRes ())#line:4997
ToolsButton =pyxbmct .Button ('[COLOR %s][B]כלים[/B][/COLOR]'%MAIN_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4999
window .placeControl (ToolsButton ,2 ,25 ,9 ,8 )#line:5000
window .connect (ToolsButton ,lambda :Tools ())#line:5001
InstallablesButton =pyxbmct .Button ('[COLOR %s][B]התקנות[/B][/COLOR]'%MAIN_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:5003
window .placeControl (InstallablesButton ,2 ,33 ,9 ,8 )#line:5004
window .connect (InstallablesButton ,lambda :Installables ())#line:5005
CloseButton =pyxbmct .Button ('[COLOR %s][B]סגירה[/B][/COLOR]'%MAIN_BUTTONS_TEXT ,focusTexture =EXIT ,noFocusTexture =BUTTON )#line:5007
window .placeControl (CloseButton ,-2 ,41 ,13 ,8 )#line:5008
window .connect (CloseButton ,window .close )#line:5009
BuildsButton .controlRight (MaintButton )#line:5011
BuildsButton .controlLeft (CloseButton )#line:5012
MaintButton .controlRight (BackResButton )#line:5014
MaintButton .controlLeft (BuildsButton )#line:5015
BackResButton .controlRight (ToolsButton )#line:5017
BackResButton .controlLeft (MaintButton )#line:5018
ToolsButton .controlRight (InstallablesButton )#line:5020
ToolsButton .controlLeft (BackResButton )#line:5021
InstallablesButton .controlRight (CloseButton )#line:5023
InstallablesButton .controlLeft (ToolsButton )#line:5024
CloseButton .controlRight (BuildsButton )#line:5026
CloseButton .controlLeft (InstallablesButton )#line:5027
def testnotify ():#line:5040
	OO0000OOOO00O0OO0 =wiz .workingURL (NOTIFICATION )#line:5041
	if OO0000OOOO00O0OO0 ==True :#line:5042
		try :#line:5043
			OOO00OOOO00O0O0O0 ,O00OO00OOO00OOOO0 =wiz .splitNotify (NOTIFICATION )#line:5044
			if OOO00OOOO00O0O0O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5045
			notify .notification (O00OO00OOO00OOOO0 ,True )#line:5046
		except Exception as OO0OO0OOO00OO0000 :#line:5047
			wiz .log ("Error on Notifications Window: %s"%str (OO0OO0OOO00OO0000 ),xbmc .LOGERROR )#line:5048
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5049
def servicemanual ():#line:5050
	OO000OO0OO0O0OOO0 =wiz .workingURL (NOTIFICATION2 )#line:5051
	if OO000OO0OO0O0OOO0 ==True :#line:5052
		try :#line:5053
			O0OO0O0O00000OOO0 ,OO000O000O0O00O0O =wiz .splitNotify (NOTIFICATION2 )#line:5054
			if O0OO0O0O00000OOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:5055
			notify .notification2 (OO000O000O0O00O0O ,True )#line:5056
		except Exception as O0OOO0OOOO000OO00 :#line:5057
			wiz .log ("Error on Notifications Window: %s"%str (O0OOO0OOOO000OO00 ),xbmc .LOGERROR )#line:5058
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:5059
def testupdate ():#line:5061
	if BUILDNAME =="":#line:5062
		notify .updateWindow ()#line:5063
	else :#line:5064
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:5065
def testfirst ():#line:5067
	notify .firstRun ()#line:5068
def testfirstRun ():#line:5070
	notify .firstRunSettings ()#line:5071
	################!!!!!NEVER DELETE!!!!############
window .connect (pyxbmct .ACTION_NAV_BACK ,window .close )#line:5079
window .setFocus (BuildsButton )#line:5081
HIDEALL ()#line:5084
splash .setVisible (True )#line:5085
logging.warning('mode:'+str(mode))
if AUTOUPDATE =='Yes' and mode==None:#line:243
    O0O0000O00OO0000O =wiz .textCache (WIZARDFILE )#line:244
    logging.warning('Ver:'+O0O0000O00OO0000O)
    
    if not O0O0000O00OO0000O ==False :#line:245
        OOO00OOO0O00OOOO0 =wiz .checkWizard ('version')#line:246
        
        if OOO00OOO0O00OOOO0 >VERSION :
            wiz .wizardUpdate ()
if mode =='index':index ()#line:5095
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:5096
elif mode =='builds':buildMenu ()#line:5097
elif mode =='viewbuild':viewBuild (name )#line:5098
elif mode =='buildinfo':buildInfo (name )#line:5099
elif mode =='buildpreview':buildVideo (name )#line:5100
elif mode =='install':buildWizard (name ,url )#line:5101
elif mode =='theme':buildWizard (name ,mode ,url )#line:5102
elif mode =='viewthirdparty':viewThirdList (name )#line:5103
elif mode =='installthird':thirdPartyInstall (name ,url )#line:5104
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:5105
elif mode =='maint':maintMenu (name )#line:5106
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:5107
elif mode =='unknownsources':skinSwitch .swapUS ()#line:5108
elif mode =='advancedsetting':advancedWindow (name )#line:5109
elif mode =='autoadvanced1':showAutoAdvanced1 ();wiz .refresh ()#line:5110
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:5111
elif mode =='asciicheck':wiz .asciiCheck ()#line:5112
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:5113
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:5114
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:5115
elif mode =='backupaddonpack':wiz .backUpOptions ('addon pack')#line:5116
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:5117
elif mode =='oldThumbs':wiz .oldThumbs ()#line:5118
elif mode =='clearbackup':wiz .cleanupBackup ()#line:5119
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:5120
elif mode =='currentsettings':viewAdvanced ()#line:5121
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:5122
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:5123
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:5124
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:5125
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:5126
elif mode =='cleararchive':clearArchive ();wiz .refresh ()#line:5127
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:5128
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:5129
elif mode =='freshstart':freshStart ()#line:5130
elif mode =='forceupdate':wiz .forceUpdate ()#line:5131
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:5132
elif mode =='forceclose':wiz .killxbmc ()#line:5133
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:5134
elif mode =='hidepassword':wiz .hidePassword ()#line:5135
elif mode =='unhidepassword':wiz .unhidePassword ()#line:5136
elif mode =='enableaddons':enableAddons ()#line:5137
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:5138
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:5139
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:5140
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:5141
elif mode =='uploadlog':uploadLog .Main ()#line:5142
elif mode =='viewlog':LogViewer ()#line:5143
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:5144
elif mode =='viewerrorlog':errorChecking ()#line:5145
elif mode =='viewerrorlast':errorChecking (last =True )#line:5146
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:5147
elif mode =='purgedb':purgeDb ()#line:5148
elif mode =='fixaddonupdate':fixUpdate ()#line:5149
elif mode =='removeaddons':removeAddonMenu ()#line:5150
elif mode =='removeaddon':removeAddon (name )#line:5151
elif mode =='removeaddondata':removeAddonDataMenu ()#line:5152
elif mode =='removedata':removeAddonData (name )#line:5153
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:5154
elif mode =='systeminfo':systemInfo ()#line:5155
elif mode =='restorezip':restoreit ('build')#line:5156
elif mode =='restoregui':restoreit ('gui')#line:5157
elif mode =='restoreaddon':restoreit ('addondata')#line:5158
elif mode =='restoreextzip':restoreextit ('build')#line:5159
elif mode =='restoreextgui':restoreextit ('gui')#line:5160
elif mode =='restoreextaddon':restoreextit ('addondata')#line:5161
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:5162
elif mode =='speedtest':speedTest ()#line:5163
elif mode =='speed':speed ();wiz .refresh ()#line:5164
elif mode =='clearspeedtest':clearSpeedTest ();wiz .refresh ()#line:5165
elif mode =='viewspeedtest':viewSpeedTest (name );wiz .refresh ()#line:5166
elif mode =='apk':apkMenu (name ,url )#line:5167
elif mode =='apkscrape':apkScraper (name )#line:5168
elif mode =='apkinstall':apkInstaller (name ,url )#line:5169
elif mode =='apkinstall1':apkInstaller1 (name ,url )#line:5170
elif mode =='rominstall':romInstaller (name ,url )#line:5171
elif mode =='youtube':youtubeMenu (name ,url )#line:5172
elif mode =='viewVideo':playVideo (url )#line:5173
elif mode =='addons':addonMenu (name ,url )#line:5174
elif mode =='addonpack':packInstaller (name ,url )#line:5175
elif mode =='skinpack':skinInstaller (name ,url )#line:5176
elif mode =='addoninstall':addonInstaller (name ,url )#line:5177
elif mode =='savedata':saveMenu ()#line:5178
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:5179
elif mode =='managedata':manageSaveData (name )#line:5180
elif mode =='whitelist':wiz .whiteList (name )#line:5181
elif mode =='trakt':traktMenu ()#line:5182
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:5183
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:5184
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:5185
elif mode =='cleartrakt':traktit .clearSaved (name )#line:5186
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:5187
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:5188
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:5189
elif mode =='realdebrid':realMenu ()#line:5190
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:5191
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:5192
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:5193
elif mode =='cleardebrid':debridit .clearSaved (name )#line:5194
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:5195
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:5196
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:5197
elif mode =='alluc':allucMenu ()#line:5198
elif mode =='savealluc':allucit .allucIt ('update',name )#line:5199
elif mode =='restorealluc':allucit .allucIt ('restore',name )#line:5200
elif mode =='addonalluc':allucit .allucIt ('clearaddon',name )#line:5201
elif mode =='clearalluc':allucit .clearSaved (name )#line:5202
elif mode =='authalluc':allucit .activateAlluc (name );wiz .refresh ()#line:5203
elif mode =='updatealluc':allucit .autoUpdate ('all')#line:5204
elif mode =='importalluc':allucit .importlist (name );wiz .refresh ()#line:5205
elif mode =='login':loginMenu ()#line:5206
elif mode =='savelogin':loginit .loginIt ('update',name )#line:5207
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:5208
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:5209
elif mode =='clearlogin':loginit .clearSaved (name )#line:5210
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:5211
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:5212
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:5213
elif mode =='contact':notify .contact (CONTACT )#line:5214
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:5215
elif mode =='forcetext':wiz .forceText ()#line:5216
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:5217
elif mode =='developer':developer ()#line:5218
elif mode =='converttext':wiz .convertText ()#line:5219
elif mode =='createqr':wiz .createQR ()#line:5220
elif mode =='testnotify':testnotify ()#line:5221
elif mode =='testupdate':testupdate ()#line:5222
elif mode =='testfirst':testfirst ()#line:5223
elif mode =='testfirstrun':testfirstRun ()#line:5224
elif mode =='backup':backup ()#line:5226
elif mode =='addon':addon ()#line:5227
elif mode =='misc':misc ()#line:5228
elif mode =='tweaks':tweaks ()#line:5229
elif mode =='net':net_tools ()#line:5230
elif mode =='viewIP':viewIP ()#line:5231
elif mode =='backup':backup ()#line:5232
elif mode =='apk1':apkMenu ()#line:5233
elif mode =='apkgame':APKGAME (url )#line:5234
elif mode =='select':APKSELECT2 (url )#line:5235
elif mode =='grab':APKGRAB (name ,url )#line:5236
elif mode =='rom':romMenu (url )#line:5237
elif mode =='apkscrape':APK ()#line:5238
elif mode =='apkshow':apkshowMenu (url )#line:5239
elif mode =='apkkodi':apkkodiMenu ()#line:5240
elif mode =='apkinstall':apkInstaller (name ,url ,"None")#line:5241
elif mode =='APPINSTALLER':APPINSTALL (name ,url ,description )#line:5242
elif mode =='ftgmod':ftgmod ()#line:5243
elif mode =='viewpack':viewpack ()#line:5244
elif mode =='addonpackwiz':addonpackwiz ()#line:5245
elif mode =='FavsMenu':FavsMenu ()#line:5246
elif mode =='savefav':wiz .BACKUPFAV ()#line:5247
elif mode =='restorefav':wiz .RESTOREFAV ()#line:5248
elif mode =='clearfav':wiz .DELFAV ()#line:5249
elif mode =='apkfiles':apkfiles ()#line:5250
elif mode =='retromenu':retromenu ()#line:5251
elif mode =='emumenu':emumenu ()#line:5252
elif mode =='rompackmenu':rompackmenu ()#line:5253
elif mode =='UNZIPROM':UNZIPROM ()#line:5254
elif mode =='ftgmod':ftgmod ()#line:5255
elif mode =='GetList':GetList (url )#line:5256
elif mode =='autoadvanced':notify .autoConfig2 ();wiz .refresh ()#line:5257
elif mode =='autoconfig':autoconfig ()#line:5258
elif mode =='sswap':skinSwitch .popUPmenu ()#line:5259
elif mode =='99':disply_hwr2 ()#line:5260
list_update ()#line:5263
window .connect (pyxbmct .ACTION_NAV_BACK ,window .close )#line:5264
window .doModal ()#line:5265
del window #line:5266
